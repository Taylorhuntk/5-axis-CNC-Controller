# File: cutting_tool_handler.py
from PyQt5.QtWidgets import QFileDialog
from stl import mesh
import trimesh
import numpy as np
from scipy.spatial.transform import Rotation as R

from OpenGL.GL import *
from opengl_utils import create_stl_display_lists
from PyQt5.QtWidgets import QHBoxLayout, QVBoxLayout, QLabel, QSlider, QLineEdit, QToolTip
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QCursor
from mesh_utils import MeshUtils as mesh_utils

class CuttingToolHandler:
    def __init__(self, gui):
        self.gui = gui
        self.helpers = gui.helpers
        self.cnc_properties_handler = gui.cnc_properties_handler
        self.stl_handler = gui.stl_handler
        self.raw_material_handler = gui.raw_material_handler
        self.planning_handler = None
        self.mesh_utils = None
        self.contour_utils = None
        self.param_dict = None
        self.cutting_tool = {
            'material_translation': [0.0, -5.0, 10.0],  # For XYZ + Normal
            'cnc_translation': [0.0, -5.0, 10.0],      # For Stepper (XYZAB)
            'rotation': [0.0, 0.0, 1.0],  # Normal vector for XYZ + Normal mode
            'ab_rotation': [0.0, 0.0],  # A and B angles for Stepper (XYZAB)
            'dimensions': [1.0, 5.0, 1.0],
            'type': 'Cylinder',
            'render_mode': 'wireframe',
            'stl_model': None,
            'display_list': None,
            'wireframe_list': None
        }
        self._testing = False  # Testing flag for coordinate conversion methods

    def update_normal(self, axis, value):
        """Update the normal vector component and adjust others to maintain magnitude of 1."""
        # Clamp values, Z is limited to 0 to 1
        if axis == 'z':
            value = max(min(value, 1.0), 0.0)
        else:
            value = max(min(value, 1.0), -1.0)
        # Store old values to check if we are moving away from 1 or -1
        old_x = self.cutting_tool['rotation'][0]
        old_y = self.cutting_tool['rotation'][1]
        old_z = self.cutting_tool['rotation'][2]

        # Determine if the update is coming from an entry box or slider
        from_entry = hasattr(self.gui, 'tool_rx_entry') and self.gui.tool_rx_entry.hasFocus() or \
                     hasattr(self.gui, 'tool_ry_entry') and self.gui.tool_ry_entry.hasFocus() or \
                     hasattr(self.gui, 'tool_rz_entry') and self.gui.tool_rz_entry.hasFocus()

        if from_entry:
            if axis == 'x':
                remaining = np.sqrt(1.0 - old_z**2)  # Check against Z constraint for XY magnitude
                self.cutting_tool['rotation'][0] = value
                if abs(value) > remaining:  # If entered value breaks Z constraint
                    self.cutting_tool['rotation'][1] = 0.0  # Set Y to zero
                    self.cutting_tool['rotation'][2] = np.sqrt(max(0.0, 1.0 - value**2)) if abs(value) <= 1.0 else 0.0  # Reduce Z
                else:  # If within Z constraint, behave like slider (adjust Y, keep Z)
                    remaining_after_x = np.sqrt(max(0.0, 1.0 - value**2 - old_z**2))
                    sign = 1 if old_y >= 0 else -1
                    self.cutting_tool['rotation'][1] = sign * remaining_after_x
            elif axis == 'y':
                remaining = np.sqrt(1.0 - old_z**2)  # Check against Z constraint for XY magnitude
                self.cutting_tool['rotation'][1] = value
                if abs(value) > remaining:  # If entered value breaks Z constraint
                    self.cutting_tool['rotation'][0] = 0.0  # Set X to zero
                    self.cutting_tool['rotation'][2] = np.sqrt(max(0.0, 1.0 - value**2)) if abs(value) <= 1.0 else 0.0  # Reduce Z
                else:  # If within Z constraint, behave like slider (adjust X, keep Z)
                    remaining_after_y = np.sqrt(max(0.0, 1.0 - value**2 - old_z**2))
                    sign = 1 if old_x >= 0 else -1
                    self.cutting_tool['rotation'][0] = sign * remaining_after_y
            else:  # z
                self.cutting_tool['rotation'][2] = value
                remaining = np.sqrt(max(0.0, 1.0 - value**2))
                if abs(value) >= 1.0:
                    self.cutting_tool['rotation'][0] = 0.0
                    self.cutting_tool['rotation'][1] = 0.0
                else:
                    old_mag_xy = np.sqrt(old_x**2 + old_y**2) if old_x != 0 or old_y != 0 else 0.0
                    if old_mag_xy < 1e-10:
                        self.cutting_tool['rotation'][0] = remaining / np.sqrt(2)
                        self.cutting_tool['rotation'][1] = remaining / np.sqrt(2)
                    else:
                        x_scale = old_x / old_mag_xy if old_mag_xy > 0 else 0.0
                        y_scale = old_y / old_mag_xy if old_mag_xy > 0 else 0.0
                        self.cutting_tool['rotation'][0] = x_scale * remaining
                        self.cutting_tool['rotation'][1] = y_scale * remaining
        else:
            if axis == 'x':
                remaining = np.sqrt(1.0 - old_z**2)  # Keep Z constant for slider movement
                # Clamp the X value to the allowed range based on remaining magnitude
                value = max(min(value, remaining), -remaining)
                self.cutting_tool['rotation'][0] = value
                if abs(value) > remaining:
                    self.cutting_tool['rotation'][1] = 0.0  # Set Y to zero
                    self.cutting_tool['rotation'][2] = np.sqrt(1.0 - value**2) if abs(value) <= 1.0 else 0.0  # Reduce Z
                elif abs(value) >= remaining:
                    self.cutting_tool['rotation'][1] = 0.0
                else:
                    old_mag_y = abs(old_y) if old_y != 0 else 0.0
                    if abs(old_x) >= remaining - 1e-10:  # Moving away from max on x
                        sign = -1 if value < 0 else 1
                        self.cutting_tool['rotation'][1] = sign * np.sqrt(remaining**2 - value**2)
                    elif old_mag_y < 1e-10:  # If Y was near zero
                        sign = -1 if value < 0 else 1
                        self.cutting_tool['rotation'][1] = sign * np.sqrt(remaining**2 - value**2)
                    else:  # Adjust Y proportionally
                        sign = 1 if old_y >= 0 else -1
                        self.cutting_tool['rotation'][1] = sign * np.sqrt(remaining**2 - value**2)
            elif axis == 'y':
                remaining = np.sqrt(1.0 - old_z**2)  # Keep Z constant for slider movement
                # Clamp the Y value to the allowed range based on remaining magnitude
                value = max(min(value, remaining), -remaining)
                self.cutting_tool['rotation'][1] = value
                if abs(value) > remaining:
                    self.cutting_tool['rotation'][0] = 0.0  # Set X to zero
                    self.cutting_tool['rotation'][2] = np.sqrt(1.0 - value**2) if abs(value) <= 1.0 else 0.0  # Reduce Z
                elif abs(value) >= remaining:
                    self.cutting_tool['rotation'][0] = 0.0
                else:
                    old_mag_x = abs(old_x) if old_x != 0 else 0.0
                    if abs(old_y) >= remaining - 1e-10:  # Moving away from max on y
                        sign = -1 if value < 0 else 1
                        self.cutting_tool['rotation'][0] = sign * np.sqrt(remaining**2 - value**2)
                    elif old_mag_x < 1e-10:  # If X was near zero
                        sign = -1 if value < 0 else 1
                        self.cutting_tool['rotation'][0] = sign * np.sqrt(remaining**2 - value**2)
                    else:  # Adjust X proportionally
                        sign = 1 if old_x >= 0 else -1
                        self.cutting_tool['rotation'][0] = sign * np.sqrt(remaining**2 - value**2)
            else:  # z
                self.cutting_tool['rotation'][2] = value
                remaining = np.sqrt(1.0 - value**2)
                if abs(value) >= 1.0:
                    self.cutting_tool['rotation'][0] = 0.0
                    self.cutting_tool['rotation'][1] = 0.0
                else:
                    old_mag_xy = np.sqrt(old_x**2 + old_y**2) if old_x != 0 or old_y != 0 else 0.0
                    if old_mag_xy < 1e-10:  # If other components were near zero
                        self.cutting_tool['rotation'][0] = remaining / np.sqrt(2)
                        self.cutting_tool['rotation'][1] = remaining / np.sqrt(2)
                    else:  # Maintain proportionality of X and Y
                        scale = remaining / old_mag_xy if old_mag_xy > 0 else 1.0
                        self.cutting_tool['rotation'][0] = old_x * scale
                        self.cutting_tool['rotation'][1] = old_y * scale
        
        # Normalize the vector to ensure it remains a unit vector
        normal = np.array(self.cutting_tool['rotation'])
        magnitude = np.linalg.norm(normal)
        if magnitude > 0:
            self.cutting_tool['rotation'] = (normal / magnitude).tolist()
        
        # Update sliders and entries to reflect the new values
        self.gui.tool_rx_slider.blockSignals(True)
        self.gui.tool_ry_slider.blockSignals(True)
        self.gui.tool_rz_slider.blockSignals(True)
        self.gui.tool_rx_slider.setValue(int(self.cutting_tool['rotation'][0] * 1000000))
        self.gui.tool_ry_slider.setValue(int(self.cutting_tool['rotation'][1] * 1000000))
        self.gui.tool_rz_slider.setValue(int(self.cutting_tool['rotation'][2] * 1000000))
        self.gui.tool_rx_slider.blockSignals(False)
        self.gui.tool_ry_slider.blockSignals(False)
        self.gui.tool_rz_slider.blockSignals(False)
        self.gui.tool_rx_entry.setText(f"{self.cutting_tool['rotation'][0]:.6f}")
        self.gui.tool_ry_entry.setText(f"{self.cutting_tool['rotation'][1]:.6f}")
        self.gui.tool_rz_entry.setText(f"{self.cutting_tool['rotation'][2]:.6f}")

    def update_xy_slider_ranges(self, remaining):
        """Dynamically update the X and Y slider ranges based on the remaining magnitude."""
        max_val = int(round(remaining * 1000000))
        min_val = -max_val
        self.gui.tool_rx_slider.setRange(min_val, max_val)
        self.gui.tool_ry_slider.setRange(min_val, max_val)

    def load_tool_stl(self):
        file_name, _ = QFileDialog.getOpenFileName(self.gui, "Open Tool STL File", "", "STL Files (*.stl)")
        if file_name:
            stl_model = mesh.Mesh.from_file(file_name)
            display_list, wireframe_list = create_stl_display_lists(stl_model)
            self.cutting_tool['stl_model'] = stl_model
            self.cutting_tool['display_list'] = display_list
            self.cutting_tool['wireframe_list'] = wireframe_list
            self.gui.file_info.append(f"Loaded Tool: {file_name}\nVertices: {len(stl_model.vectors)}\nTriangles: {len(stl_model.vectors) // 3}")
            self.update_tool_ui()
            self.gui.stl_viewer.update()

    def update_tool_ui(self):
        if self.gui.tool_stl_button.isChecked():
            self.gui.load_tool_stl_button.show()
            self.gui.tool_type_combo.hide()
            self.gui.tool_diameter.hide()
            self.gui.tool_length.hide()
            self.gui.tool_cone_length.hide()
            self.gui.tool_cone_length_label.hide()
            for i in range(self.gui.tool_form.rowCount()):
                label_item = self.gui.tool_form.itemAt(i, self.gui.tool_form.LabelRole)
                if label_item:
                    label_widget = label_item.widget()
                    if label_widget:
                        label_widget.hide()
        else:
            self.gui.load_tool_stl_button.hide()
            self.gui.tool_type_combo.show()
            self.gui.tool_diameter.show()
            self.gui.tool_length.show()
            if self.gui.tool_type_combo.currentText() == 'Pointed Cylinder':
                self.gui.tool_cone_length.show()
                self.gui.tool_cone_length_label.show()
            else:
                self.gui.tool_cone_length.hide()
                self.gui.tool_cone_length_label.hide()
            for i in range(self.gui.tool_form.rowCount()):
                label_item = self.gui.tool_form.itemAt(i, self.gui.tool_form.LabelRole)
                if label_item:
                    label_widget = label_item.widget()
                    if label_widget:
                        if i == 3 and self.gui.tool_type_combo.currentText() != 'Pointed Cylinder':
                            label_widget.hide()
                        else:
                            label_widget.show()
            # Clear STL model and regenerate shape display lists when switching to shape mode
            if self.cutting_tool['stl_model']:
                self.cutting_tool['stl_model'] = None
                if self.cutting_tool['display_list']:
                    glDeleteLists(self.cutting_tool['display_list'], 1)
                    self.cutting_tool['display_list'] = None
                if self.cutting_tool['wireframe_list']:
                    glDeleteLists(self.cutting_tool['wireframe_list'], 1)
                    self.cutting_tool['wireframe_list'] = None
                self.create_tool_display_lists()
        if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
            self.gui.stl_viewer.update()

    def update_tool_type(self, tool_type):
        self.cutting_tool['type'] = tool_type
        if tool_type == 'Cylinder':
            self.gui.tool_cone_length.hide()
            self.gui.tool_cone_length_label.hide()
        else:
            self.gui.tool_cone_length.show()
            self.gui.tool_cone_length_label.show()
        self.create_tool_display_lists()
        self.gui.stl_viewer.update()

    def update_tool_dimensions(self):
        diameter = self.helpers.convert_to_cm(self.gui.tool_diameter.value(), self.gui.current_unit)
        length = self.helpers.convert_to_cm(self.gui.tool_length.value(), self.gui.current_unit)
        cone_length = self.helpers.convert_to_cm(self.gui.tool_cone_length.value(), self.gui.current_unit)
        self.cutting_tool['dimensions'] = [diameter, length, cone_length]
        self.create_tool_display_lists()
        self.gui.stl_viewer.update()

    def update_tool_render_mode(self):
        self.cutting_tool['render_mode'] = 'wireframe' if self.gui.tool_wireframe_button.isChecked() else 'solid'
        self.gui.stl_viewer.update()

    def create_tool_display_lists(self):
        if self.cutting_tool['stl_model']:
            return
        if self.cutting_tool['display_list']:
            glDeleteLists(self.cutting_tool['display_list'], 1)
        if self.cutting_tool['wireframe_list']:
            glDeleteLists(self.cutting_tool['wireframe_list'], 1)
        
        diameter, length, cone_length = self.cutting_tool['dimensions']
        radius = diameter / 2.0
        segments = 24
        
        self.cutting_tool['display_list'] = glGenLists(1)
        glNewList(self.cutting_tool['display_list'], GL_COMPILE)
        glColor3f(0.2, 0.2, 0.8)  # Changed to blue
        
        if self.cutting_tool['type'] == 'Cylinder':
            glBegin(GL_QUAD_STRIP)
            for i in range(segments + 1):
                angle = 2 * np.pi * i / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glNormal3f(x / radius, y / radius, 0.0)
                glVertex3f(x, y, 0.0)
                glVertex3f(x, y, length)
            glEnd()
            glBegin(GL_TRIANGLE_FAN)
            glNormal3f(0.0, 0.0, -1.0)
            glVertex3f(0.0, 0.0, 0.0)
            for i in range(segments + 1):
                angle = 2 * np.pi * i / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glVertex3f(x, y, 0.0)
            glEnd()
            glBegin(GL_TRIANGLE_FAN)
            glNormal3f(0.0, 0.0, 1.0)
            glVertex3f(0.0, 0.0, length)
            for i in range(segments + 1):
                angle = 2 * np.pi * (segments - i) / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glVertex3f(x, y, length)
            glEnd()
        else:
            body_length = length - cone_length
            glBegin(GL_QUAD_STRIP)
            for i in range(segments + 1):
                angle = 2 * np.pi * i / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glNormal3f(x / radius, y / radius, 0.0)
                glVertex3f(x, y, cone_length)
                glVertex3f(x, y, length)
            glEnd()
            glBegin(GL_TRIANGLE_FAN)
            glNormal3f(0.0, 0.0, 1.0)
            glVertex3f(0.0, 0.0, length)
            for i in range(segments + 1):
                angle = 2 * np.pi * (segments - i) / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glVertex3f(x, y, length)
            glEnd()
            glBegin(GL_TRIANGLE_FAN)
            glNormal3f(0.0, 0.0, -1.0)
            glVertex3f(0.0, 0.0, 0.0)
            for i in range(segments + 1):
                angle = 2 * np.pi * i / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glVertex3f(x, y, cone_length)
            glEnd()
        glEndList()
        
        self.cutting_tool['wireframe_list'] = glGenLists(1)
        glNewList(self.cutting_tool['wireframe_list'], GL_COMPILE)
        glColor3f(0.2, 0.2, 0.8)  # Changed to blue
        glLineWidth(1.5)
        
        if self.cutting_tool['type'] == 'Cylinder':
            glBegin(GL_LINE_LOOP)
            for i in range(segments):
                angle = 2 * np.pi * i / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glVertex3f(x, y, 0.0)
            glEnd()
            glBegin(GL_LINE_LOOP)
            for i in range(segments):
                angle = 2 * np.pi * i / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glVertex3f(x, y, length)
            glEnd()
            for i in range(segments // 4):
                angle = 2 * np.pi * i * 4 / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glBegin(GL_LINES)
                glVertex3f(x, y, 0.0)
                glVertex3f(x, y, length)
                glEnd()
        else:
            body_length = length - cone_length
            glBegin(GL_LINE_LOOP)
            for i in range(segments):
                angle = 2 * np.pi * i / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glVertex3f(x, y, length)
            glEnd()
            glBegin(GL_LINE_LOOP)
            for i in range(segments):
                angle = 2 * np.pi * i / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glVertex3f(x, y, cone_length)
            glEnd()
            for i in range(segments // 4):
                angle = 2 * np.pi * i * 4 / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glBegin(GL_LINES)
                glVertex3f(x, y, cone_length)
                glVertex3f(x, y, length)
                glEnd()
            for i in range(segments // 4):
                angle = 2 * np.pi * i * 4 / segments
                x = radius * np.cos(angle)
                y = radius * np.sin(angle)
                glBegin(GL_LINES)
                glVertex3f(x, y, cone_length)
                glVertex3f(0.0, 0.0, 0.0)
                glEnd()
        glEndList()

    def update_tool_sliders(self):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.cutting_tool:
            current_system = self.gui.coord_system_combo.currentText()
            unit = self.gui.current_unit
            
            if current_system == 'XYZ + Normal':
                x_val = self.helpers.convert_from_cm(self.cutting_tool['material_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool['material_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool['material_translation'][2], unit)
            else:  # Stepper (XYZAB)
                x_val = self.helpers.convert_from_cm(self.cutting_tool['cnc_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool['cnc_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool['cnc_translation'][2], unit)
                
            self.gui.tool_x_slider.blockSignals(True)
            self.gui.tool_y_slider.blockSignals(True)
            self.gui.tool_z_slider.blockSignals(True)
            clamped_x = max(self.gui.tool_x_slider.minimum(), min(self.gui.tool_x_slider.maximum(), x_val*scaling_factor))
            clamped_y = max(self.gui.tool_y_slider.minimum(), min(self.gui.tool_y_slider.maximum(), y_val*scaling_factor))
            clamped_z = max(self.gui.tool_z_slider.minimum(), min(self.gui.tool_z_slider.maximum(), z_val*scaling_factor))
            self.gui.tool_x_slider.setValue(int(clamped_x))
            self.gui.tool_y_slider.setValue(int(clamped_y))
            self.gui.tool_z_slider.setValue(int(clamped_z))
            self.gui.tool_x_slider.blockSignals(False)
            self.gui.tool_y_slider.blockSignals(False)
            self.gui.tool_z_slider.blockSignals(False)
            self.gui.tool_x_entry.setText(f"{x_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{x_val:.3f}" if self.gui.current_unit == 'MM' else f"{x_val:.1f}")
            self.gui.tool_y_entry.setText(f"{y_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{y_val:.3f}" if self.gui.current_unit == 'MM' else f"{y_val:.1f}")
            self.gui.tool_z_entry.setText(f"{z_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{z_val:.3f}" if self.gui.current_unit == 'MM' else f"{z_val:.1f}")
            
            if current_system == 'XYZ + Normal':
                rx_val = self.cutting_tool['rotation'][0]
                ry_val = self.cutting_tool['rotation'][1]
                rz_val = self.cutting_tool['rotation'][2]
                self.gui.tool_rx_slider.blockSignals(True)
                self.gui.tool_ry_slider.blockSignals(True)
                self.gui.tool_rz_slider.blockSignals(True)
                self.gui.tool_rx_slider.setValue(int(rx_val * 1000000))
                self.gui.tool_ry_slider.setValue(int(ry_val * 1000000))
                self.gui.tool_rz_slider.setValue(int(rz_val * 1000000))
                self.gui.tool_rx_slider.blockSignals(False)
                self.gui.tool_ry_slider.blockSignals(False)
                self.gui.tool_rz_slider.blockSignals(False)
                self.gui.tool_rx_entry.setText(f"{rx_val:.6f}")
                self.gui.tool_ry_entry.setText(f"{ry_val:.6f}")
                self.gui.tool_rz_entry.setText(f"{rz_val:.6f}")
            else:  # Stepper (XYZAB)
                a_val = self.cutting_tool['ab_rotation'][0]
                b_val = self.cutting_tool['ab_rotation'][1]
                if self.gui.rotation_unit == 'DEG':
                    self.gui.tool_rx_slider.blockSignals(True)
                    self.gui.tool_ry_slider.blockSignals(True)
                    clamped_a = max(self.gui.tool_rx_slider.minimum(), min(self.gui.tool_rx_slider.maximum(), a_val * 1000.0))
                    clamped_b = max(self.gui.tool_ry_slider.minimum(), min(self.gui.tool_ry_slider.maximum(), b_val * 1000.0))
                    self.gui.tool_rx_slider.setValue(int(clamped_a))
                    self.gui.tool_ry_slider.setValue(int(clamped_b))
                    self.gui.tool_rx_slider.blockSignals(False)
                    self.gui.tool_ry_slider.blockSignals(False)
                    self.gui.tool_rx_entry.setText(f"{a_val:.3f}")
                    self.gui.tool_ry_entry.setText(f"{b_val:.3f}")
                else:  # RAD
                    a_rad = np.radians(a_val)
                    b_rad = np.radians(b_val)
                    self.gui.tool_rx_slider.blockSignals(True)
                    self.gui.tool_ry_slider.blockSignals(True)
                    clamped_a_rad = max(self.gui.tool_rx_slider.minimum(), min(self.gui.tool_rx_slider.maximum(), a_rad * 1000000.0))
                    clamped_b_rad = max(self.gui.tool_ry_slider.minimum(), min(self.gui.tool_ry_slider.maximum(), b_rad * 1000000.0))
                    self.gui.tool_rx_slider.setValue(int(clamped_a_rad))
                    self.gui.tool_ry_slider.setValue(int(clamped_b_rad))
                    self.gui.tool_rx_slider.blockSignals(False)
                    self.gui.tool_ry_slider.blockSignals(False)
                    self.gui.tool_rx_entry.setText(f"{a_rad:.6f}")
                    self.gui.tool_ry_entry.setText(f"{b_rad:.6f}")

    def inflate_tool_sliders(self):
        """Inflate the tool sliders to their maximum size."""
        self.gui.tool_x_slider.setRange(-1000000000, 1000000000)
        self.gui.tool_y_slider.setRange(-1000000000, 1000000000)
        self.gui.tool_z_slider.setRange(-1000000000, 1000000000)
        self.gui.tool_rx_slider.setRange(-1000000000, 1000000000)
        self.gui.tool_ry_slider.setRange(-1000000000, 1000000000)
        self.gui.tool_rz_slider.setRange(-1000000000, 1000000000)

    def update_tool_sliders_visibility(self, system):

        self.inflate_tool_sliders()
        self.update_tool_sliders()
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        self.gui.tool_x_slider.setVisible(True)
        self.gui.tool_y_slider.setVisible(True)
        self.gui.tool_z_slider.setVisible(True)
        self.gui.tool_x_entry.setVisible(True)
        self.gui.tool_y_entry.setVisible(True)
        self.gui.tool_z_entry.setVisible(True)
        

        if system == 'XYZ + Normal':
            self.gui.tool_rx_slider.setVisible(True)
            self.gui.tool_ry_slider.setVisible(True)
            self.gui.tool_rz_slider.setVisible(True)
            self.gui.tool_rx_entry.setVisible(True)
            self.gui.tool_ry_entry.setVisible(True)
            self.gui.tool_rz_entry.setVisible(True)
            self.gui.tool_rx_label.setText('Nx')
            self.gui.tool_ry_label.setText('Ny')
            self.gui.tool_rz_label.setText('Nz')
            self.gui.tool_rx_label.setVisible(True)
            self.gui.tool_ry_label.setVisible(True)
            self.gui.tool_rz_label.setVisible(True)

        else:  # Stepper (XYZAB)
            self.gui.tool_rx_slider.setVisible(True)
            self.gui.tool_ry_slider.setVisible(True)
            self.gui.tool_rz_slider.setVisible(False)
            self.gui.tool_rx_entry.setVisible(True)
            self.gui.tool_ry_entry.setVisible(True)
            self.gui.tool_rz_entry.setVisible(False)
            self.gui.tool_rx_label.setText('A')
            self.gui.tool_ry_label.setText('B')
            self.gui.tool_rx_label.setVisible(True)
            self.gui.tool_ry_label.setVisible(True)
            self.gui.tool_rz_label.setVisible(False)
        self.gui.set_final_slider_ranges(self.gui.current_unit)    
        self.gui.set_final_rotation_ranges(self.gui.rotation_unit)
        self.update_tool_sliders()
        # Convert coordinates when switching between systems to preserve orientation and position
        
        if system == 'XYZ + Normal':
            # Convert from XYZAB to XYZ + Normal
            a_deg = self.cutting_tool['ab_rotation'][0]
            b_deg = self.cutting_tool['ab_rotation'][1]
            x = self.cutting_tool['cnc_translation'][0]
            y = self.cutting_tool['cnc_translation'][1]
            z = self.cutting_tool['cnc_translation'][2]
            self.cnc_to_material(x, y, z, a_deg, b_deg)
           
        else:
            # Convert from XYZ + Normal to XYZAB
            nx = self.cutting_tool['rotation'][0]
            ny = self.cutting_tool['rotation'][1]
            nz = self.cutting_tool['rotation'][2]
            x = self.cutting_tool['material_translation'][0]
            y = self.cutting_tool['material_translation'][1]
            z = self.cutting_tool['material_translation'][2]
            b_deg = self.cutting_tool['ab_rotation'][1]  # Fallback B value
            elbowUp = self.cutting_tool['ab_rotation'][0]>0.0  # Fallback A value
            self.material_to_cnc(x, y, z, nx, ny, nz, b_deg, True)
            
        self.update_tool_sliders()
        
    def add_sliders(self, layout):
        slider_layout = QHBoxLayout()
        layout.addLayout(slider_layout)
        translation_layout = QVBoxLayout()
        slider_layout.addLayout(translation_layout)
        translation_label = QLabel('Translation')
        translation_label.setAlignment(Qt.AlignCenter)
        translation_layout.addWidget(translation_label)
        translation_sliders_layout = QHBoxLayout()
        translation_layout.addLayout(translation_sliders_layout)
        
        x_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(x_translation_layout)
        self.gui.tool_x_slider = QSlider(Qt.Vertical)
        self.gui.tool_x_slider.setRange(-300000, 300000)
        self.gui.tool_x_slider.setSingleStep(1)
        self.gui.tool_x_slider.setPageStep(1000)
        self.gui.tool_x_slider.setTickInterval(1000)
        self.gui.tool_x_slider.valueChanged.connect(self.update_tool_x_translation)
        x_translation_layout.addWidget(QLabel('X'))
        x_translation_layout.addWidget(self.gui.tool_x_slider)
        self.gui.tool_x_entry = QLineEdit()
        self.gui.tool_x_entry.setFixedWidth(100)
        self.gui.tool_x_entry.setPlaceholderText('0.0')
        self.gui.tool_x_entry.setAlignment(Qt.AlignCenter)
        self.gui.tool_x_entry.returnPressed.connect(self.update_tool_x_translation_from_entry)
        x_translation_layout.addWidget(self.gui.tool_x_entry)
        
        y_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(y_translation_layout)
        self.gui.tool_y_slider = QSlider(Qt.Vertical)
        self.gui.tool_y_slider.setRange(-300000, 300000)
        self.gui.tool_y_slider.setSingleStep(1)
        self.gui.tool_y_slider.setPageStep(1000)
        self.gui.tool_y_slider.setTickInterval(1000)
        self.gui.tool_y_slider.valueChanged.connect(self.update_tool_y_translation)
        y_translation_layout.addWidget(QLabel('Y'))
        y_translation_layout.addWidget(self.gui.tool_y_slider)
        self.gui.tool_y_entry = QLineEdit()
        self.gui.tool_y_entry.setFixedWidth(100)
        self.gui.tool_y_entry.setPlaceholderText('0.0')
        self.gui.tool_y_entry.setAlignment(Qt.AlignCenter)
        self.gui.tool_y_entry.returnPressed.connect(self.update_tool_y_translation_from_entry)
        y_translation_layout.addWidget(self.gui.tool_y_entry)
        
        z_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(z_translation_layout)
        self.gui.tool_z_slider = QSlider(Qt.Vertical)
        self.gui.tool_z_slider.setRange(-300000, 300000)  # Allow negative Z values for XYZ-Normal frame
        self.gui.tool_z_slider.setSingleStep(1)
        self.gui.tool_z_slider.setPageStep(1000)
        self.gui.tool_z_slider.setTickInterval(1000)
        self.gui.tool_z_slider.valueChanged.connect(self.update_tool_z_translation)
        z_translation_layout.addWidget(QLabel('Z'))
        z_translation_layout.addWidget(self.gui.tool_z_slider)
        self.gui.tool_z_entry = QLineEdit()
        self.gui.tool_z_entry.setFixedWidth(100)
        self.gui.tool_z_entry.setPlaceholderText('0.0')
        self.gui.tool_z_entry.setAlignment(Qt.AlignCenter)
        self.gui.tool_z_entry.returnPressed.connect(self.update_tool_z_translation_from_entry)
        z_translation_layout.addWidget(self.gui.tool_z_entry)
        
        rotation_layout = QVBoxLayout()
        slider_layout.addLayout(rotation_layout)
        rotation_label = QLabel('Rotation')
        rotation_label.setAlignment(Qt.AlignCenter)
        rotation_layout.addWidget(rotation_label)
        rotation_sliders_layout = QHBoxLayout()
        rotation_layout.addLayout(rotation_sliders_layout)
        
        x_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(x_rotation_layout)
        self.gui.tool_rx_slider = QSlider(Qt.Vertical)
        self.gui.tool_rx_slider.setRange(-1000000, 1000000)  # Fixed range for -1 to 1 with high precision for XYZ + Normal
        self.gui.tool_rx_slider.setSingleStep(1)
        self.gui.tool_rx_slider.setPageStep(1000)
        self.gui.tool_rx_slider.setTickInterval(1000)
        self.gui.tool_rx_slider.valueChanged.connect(self.update_tool_rx_rotation)
        self.gui.tool_rx_label = QLabel('X')
        x_rotation_layout.addWidget(self.gui.tool_rx_label)
        x_rotation_layout.addWidget(self.gui.tool_rx_slider)
        self.gui.tool_rx_entry = QLineEdit()
        self.gui.tool_rx_entry.setFixedWidth(80)
        self.gui.tool_rx_entry.setPlaceholderText('0.0')
        self.gui.tool_rx_entry.setAlignment(Qt.AlignCenter)
        self.gui.tool_rx_entry.returnPressed.connect(self.update_tool_rx_rotation_from_entry)
        x_rotation_layout.addWidget(self.gui.tool_rx_entry)
        
        y_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(y_rotation_layout)
        self.gui.tool_ry_slider = QSlider(Qt.Vertical)
        self.gui.tool_ry_slider.setRange(-1000000, 1000000)  # Fixed range for -1 to 1 with high precision for XYZ + Normal
        self.gui.tool_ry_slider.setSingleStep(1)
        self.gui.tool_ry_slider.setPageStep(1000)
        self.gui.tool_ry_slider.setTickInterval(1000)
        self.gui.tool_ry_slider.valueChanged.connect(self.update_tool_ry_rotation)
        self.gui.tool_ry_label = QLabel('Y')
        y_rotation_layout.addWidget(self.gui.tool_ry_label)
        y_rotation_layout.addWidget(self.gui.tool_ry_slider)
        self.gui.tool_ry_entry = QLineEdit()
        self.gui.tool_ry_entry.setFixedWidth(80)
        self.gui.tool_ry_entry.setPlaceholderText('0.0')
        self.gui.tool_ry_entry.setAlignment(Qt.AlignCenter)
        self.gui.tool_ry_entry.returnPressed.connect(self.update_tool_ry_rotation_from_entry)
        y_rotation_layout.addWidget(self.gui.tool_ry_entry)
        
        z_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(z_rotation_layout)
        self.gui.tool_rz_slider = QSlider(Qt.Vertical)
        self.gui.tool_rz_slider.setRange(0, 1000000)  # Fixed range for 0 to 1 with high precision for XYZ + Normal
        self.gui.tool_rz_slider.setSingleStep(1)
        self.gui.tool_rz_slider.setPageStep(1000)
        self.gui.tool_rz_slider.setTickInterval(1000)
        self.gui.tool_rz_slider.valueChanged.connect(self.update_tool_rz_rotation)
        self.gui.tool_rz_label = QLabel('Z')
        z_rotation_layout.addWidget(self.gui.tool_rz_label)
        z_rotation_layout.addWidget(self.gui.tool_rz_slider)
        self.gui.tool_rz_entry = QLineEdit()
        self.gui.tool_rz_entry.setFixedWidth(80)
        self.gui.tool_rz_entry.setPlaceholderText('0.0')
        self.gui.tool_rz_entry.setAlignment(Qt.AlignCenter)
        self.gui.tool_rz_entry.returnPressed.connect(self.update_tool_rz_rotation_from_entry)
        z_rotation_layout.addWidget(self.gui.tool_rz_entry)
        self.update_tool_sliders()

    def update_tool_x_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed():  # Check if mouse is pressed
            value = np.round(value/scaling_factor)*scaling_factor
        if self.cutting_tool:
            if not self.gui.tool_x_slider.signalsBlocked():
                current_system = self.gui.coord_system_combo.currentText()
                if current_system == 'XYZ + Normal':
                    x, y, z = self.cutting_tool['material_translation']
                    nx, ny, nz = self.cutting_tool['rotation']
                    a_deg = self.cutting_tool['ab_rotation'][0]  # Fallback A value
                    b_deg = self.cutting_tool['ab_rotation'][1]  # Fallback B value
                    test = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                    if not self.is_within_limits(test, y, z, nx, ny, nz):
                        self.update_tool_sliders()
                        return
                    self.cutting_tool['material_translation'][0] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                else:  # Stepper (XYZAB)
                    self.cutting_tool['cnc_translation'][0] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                self.gui.tool_x_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}")
                if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                    self.gui.stl_viewer.update()

    def update_tool_y_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed():  value = np.round(value/scaling_factor)*scaling_factor
        if self.cutting_tool:
            if not self.gui.tool_y_slider.signalsBlocked():
                current_system = self.gui.coord_system_combo.currentText()
                if current_system == 'XYZ + Normal':
                    x, y, z = self.cutting_tool['material_translation']
                    nx, ny, nz = self.cutting_tool['rotation']
                    test = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                    if not self.is_within_limits(x, test, z, nx, ny, nz):
                        self.update_tool_sliders()
                        return
                    self.cutting_tool['material_translation'][1] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                else:  # Stepper (XYZAB)
                    self.cutting_tool['cnc_translation'][1] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                self.gui.tool_y_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}")
                if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                    self.gui.stl_viewer.update()

    def update_tool_z_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed(): value = np.round(value/scaling_factor)*scaling_factor
        if self.cutting_tool:
            if not self.gui.tool_z_slider.signalsBlocked():
                current_system = self.gui.coord_system_combo.currentText()
                if current_system == 'XYZ + Normal':
                    x, y, z = self.cutting_tool['material_translation']
                    nx, ny, nz = self.cutting_tool['rotation']
                    test = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                    delta = value/scaling_factor - z
                    if not self.is_within_limits(x, y, test, nx, ny, nz):
                        self.update_tool_sliders()
                        return
                    self.cutting_tool['material_translation'][2] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                    
                else:  # Stepper (XYZAB)
                    self.cutting_tool['cnc_translation'][2] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                self.gui.tool_z_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}")
                if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                    self.gui.stl_viewer.update()

    def update_tool_rx_rotation(self, value):
        
        if self.cutting_tool:
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                if self.gui.is_mouse_pressed():  value = np.round(value/1000.0)*1000.0
                if self.gui.rotation_unit == 'DEG':
                    self.cutting_tool['ab_rotation'][0] = value / 1000.0
                    self.gui.tool_rx_entry.setText(f"{value / 1000.0:.3f}")
                else:
                    self.cutting_tool['ab_rotation'][0] = np.degrees(value / 1000000.0)
                    self.gui.tool_rx_entry.setText(f"{value / 1000000.0:.3f}")
            elif current_system == 'XYZ + Normal':
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                normal_value = float(value) / 1000000.0
                if not self.is_within_limits(x, y, z, normal_value, ny, nz):
                    self.update_tool_sliders()
                    return
                old_z = self.cutting_tool['rotation'][2]
                if abs(old_z) >= 0.99999999:
                    # Use current cursor position for tooltip
                    cursor_pos = QCursor.pos()
                    QToolTip.showText(cursor_pos, 
                                      "You must set the Z axis first to adjust X or Y.", 
                                      self.gui.tool_rx_slider)
                    # Reset slider value to 0 to prevent movement
                    self.gui.tool_rx_slider.blockSignals(True)
                    self.gui.tool_rx_slider.setValue(0)
                    self.gui.tool_rx_slider.blockSignals(False)
                    return  # Prevent further update if Z is near 1
                
                self.update_normal('x', normal_value)
                # Text box is updated in update_normal with clamped value
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def update_tool_ry_rotation(self, value):
        
        if self.cutting_tool:
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                if self.gui.is_mouse_pressed():  value = np.round(value/1000.0)*1000.0
                if self.gui.rotation_unit == 'DEG':
                    self.cutting_tool['ab_rotation'][1] = value / 1000.0
                    self.gui.tool_ry_entry.setText(f"{value / 1000.0:.3f}")
                else:
                    self.cutting_tool['ab_rotation'][1] = np.degrees(value / 1000000.0)
                    self.gui.tool_ry_entry.setText(f"{value / 1000000.0:.3f}")
            elif current_system == 'XYZ + Normal':
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                normal_value = float(value) / 1000000.0
                if not self.is_within_limits(x, y, z, nx, normal_value, nz):
                    self.update_tool_sliders()
                    return
                old_z = self.cutting_tool['rotation'][2]
                if abs(old_z) >= 0.99999999:
                    # Use current cursor position for tooltip
                    cursor_pos = QCursor.pos()
                    QToolTip.showText(cursor_pos, 
                                      "You must reduce the Z axis first to adjust X or Y,\nor enter a value in the entry box.", 
                                      self.gui.tool_ry_slider)
                    # Reset slider value to 0 to prevent movement
                    self.gui.tool_ry_slider.blockSignals(True)
                    self.gui.tool_ry_slider.setValue(0)
                    self.gui.tool_ry_slider.blockSignals(False)
                    return  # Prevent further update if Z is near 1
                
                self.update_normal('y', normal_value)
                # Text box is updated in update_normal with clamped value
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def update_tool_rz_rotation(self, value):
      
        if self.cutting_tool:
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'XYZ + Normal':
                normal_value = float(value) / 1000000.0
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']

                if not self.is_within_limits(x, y, z, nx, ny, normal_value):
                    self.update_tool_sliders()
                    return
                self.update_normal('z', normal_value)
                self.gui.tool_rz_entry.setText(f"{normal_value:.6f}")
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def update_tool_x_translation_from_entry(self):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        try:
            value = float(self.gui.tool_x_entry.text())
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                if not self.cnc_coords_in_limits(self.helpers.convert_to_cm(value, self.gui.current_unit), self.cutting_tool['cnc_translation'][1], self.cutting_tool['cnc_translation'][2], self.cutting_tool['ab_rotation'][0], self.cutting_tool['ab_rotation'][1]):
                    self.update_tool_sliders()
                    return
            if current_system == 'XYZ + Normal':
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                a_deg = self.cutting_tool['ab_rotation'][0]  # Fallback A value
                b_deg = self.cutting_tool['ab_rotation'][1]  # Fallback B value
                if not self.is_within_limits(value, y, z, nx, ny, nz):
                    self.update_tool_sliders()
                    return
                self.cutting_tool['material_translation'][0] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            else:  # Stepper (XYZAB)
                self.cutting_tool['cnc_translation'][0] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.tool_x_slider.blockSignals(True)
            self.gui.tool_x_slider.setValue(int(round(max(self.gui.tool_x_slider.minimum(), min(self.gui.tool_x_slider.maximum(), value * scaling_factor)))))
            self.gui.tool_x_slider.blockSignals(False)
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for tool X translation")

    def update_tool_y_translation_from_entry(self):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        try:
            value = float(self.gui.tool_y_entry.text())
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                if not self.cnc_coords_in_limits(self.cutting_tool['cnc_translation'][0], self.helpers.convert_to_cm(value, self.gui.current_unit), self.cutting_tool['cnc_translation'][2], self.cutting_tool['ab_rotation'][0], self.cutting_tool['ab_rotation'][1]):
                    self.update_tool_sliders()
                    return
            if current_system == 'XYZ + Normal':
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                a_deg = self.cutting_tool['ab_rotation'][0]  # Fallback A value
                b_deg = self.cutting_tool['ab_rotation'][1]  # Fallback B value
                if not self.is_within_limits(x, value, z, nx, ny, nz):
                    self.update_tool_sliders()
                    return
                self.cutting_tool['material_translation'][1] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            else:  # Stepper (XYZAB)
                self.cutting_tool['cnc_translation'][1] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.tool_y_slider.blockSignals(True)
            self.gui.tool_y_slider.setValue(int(round(max(self.gui.tool_y_slider.minimum(), min(self.gui.tool_y_slider.maximum(), value* scaling_factor)))))
            self.gui.tool_y_slider.blockSignals(False)
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for tool Y translation")

    def update_tool_z_translation_from_entry(self):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        try:
            value = float(self.gui.tool_z_entry.text())
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                if not self.cnc_coords_in_limits(self.cutting_tool['cnc_translation'][0], self.cutting_tool['cnc_translation'][1], self.helpers.convert_to_cm(value, self.gui.current_unit), self.cutting_tool['ab_rotation'][0], self.cutting_tool['ab_rotation'][1]):
                    self.update_tool_sliders()
                    return
            elif current_system == 'XYZ + Normal':
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                if not self.is_within_limits(x, y, value, nx, ny, nz):
                    self.update_tool_sliders()
                    return
                # Clamp Z value based on current unit's range
                min_val = self.gui.tool_z_slider.minimum()
                max_val = self.gui.tool_z_slider.maximum()
                value = max(min_val, min(max_val, value))
                self.gui.tool_z_entry.setText(f"{value:.4f}" if self.gui.current_unit == 'IN' else f"{value:.2f}")

            if current_system == 'XYZ + Normal':
                self.cutting_tool['material_translation'][2] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            else:  # Stepper (XYZAB)
                self.cutting_tool['cnc_translation'][2] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.tool_z_slider.blockSignals(True)
            self.gui.tool_z_slider.setValue(int(round(value* scaling_factor)))
            self.gui.tool_z_slider.blockSignals(False)
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for tool Z translation")

    def update_tool_rx_rotation_from_entry(self):
        try:
            value = float(self.gui.tool_rx_entry.text())
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                # check units and convert to degrees if needed
                if self.gui.rotation_unit == 'RAD':
                    value = np.degrees(value)
                    if value > 360.0:
                        value = value - 360.0
                    elif value < 0.0:   
                        value = value + 360.0
                # check if value is within limits
                if not self.cnc_coords_in_limits(self.cutting_tool['cnc_translation'][0], self.cutting_tool['cnc_translation'][1], self.cutting_tool['cnc_translation'][2], value, self.cutting_tool['ab_rotation'][1]):
                    self.update_tool_sliders()
                    return
               
                self.cutting_tool['ab_rotation'][0] = value
                self.gui.tool_rx_slider.setValue(int(round(value * 1000.0)))
                self.gui.tool_rx_entry.setText(f"{value:.3f}")
                
            elif current_system == 'XYZ + Normal':
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                if not self.is_within_limits(value, y, z, nx, ny, nz):
                    self.update_tool_sliders()
                    return
                self.update_normal('x', value)
                # Text box is updated in update_normal with clamped value
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for tool X rotation")

    def update_tool_ry_rotation_from_entry(self):
        try:
            value = float(self.gui.tool_ry_entry.text())
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                # check units and convert to degrees if needed
                if self.gui.rotation_unit == 'RAD':
                    value = np.degrees(value)
                    if value > 360.0:
                        value = value - 360.0
                    elif value < 0.0:   
                        value = value + 360.0
                if not self.cnc_coords_in_limits(self.cutting_tool['cnc_translation'][0], self.cutting_tool['cnc_translation'][1], self.cutting_tool['cnc_translation'][2], self.cutting_tool['ab_rotation'][0],  value):
                    self.update_tool_sliders()
                    return
                self.cutting_tool['ab_rotation'][1] = value
                self.gui.tool_ry_slider.setValue(int(round(value * 1000.0)))
                self.gui.tool_ry_entry.setText(f"{value:.3f}")

            elif current_system == 'XYZ + Normal':
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                if not self.is_within_limits(x, value, z, nx, ny, nz):
                    self.update_tool_sliders()
                    return
                self.update_normal('y', value)
                # Text box is updated in update_normal with clamped value
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for tool Y rotation")

    def update_tool_rz_rotation_from_entry(self):
        try:
            value = float(self.gui.tool_rz_entry.text())
            current_system = self.gui.coord_system_combo.currentText()
            if current_system == 'XYZ + Normal':
                x, y, z = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                if not self.is_within_limits(x, value, z, nx, ny, nz):
                    self.update_tool_sliders()
                    return
                self.update_normal('z', value)
                self.gui.tool_rz_slider.blockSignals(True)
                self.gui.tool_rz_slider.setValue(int(round(value * 1000000)))
                self.gui.tool_rz_slider.blockSignals(False)
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for tool Z rotation")

    def is_within_limits(self, x, y, z, nx, ny, nz, b_deg=None, elbow_up=None):

        if z < self.gui.cnc_properties_handler.build_offsets[2]:
            return False
        if b_deg is None:
            b_deg = self.cutting_tool['ab_rotation'][1]  # Fallback B value
        if elbow_up is None:
            elbow_up = self.cutting_tool['ab_rotation'][0] >= 0.0
        if self._testing:
            cnc_coords = self.material_to_cnc(x, y, z, nx, ny, nz, b_deg, elbow_up)
            #cnc_coords = np.round(cnc_coords, 4)
        else:
            self._testing = True
            cnc_coords = self.material_to_cnc(x, y, z, nx, ny, nz, b_deg, elbow_up)
            self_testing = False
        x,y,z,a,b = np.round(cnc_coords['x'],4), np.round(cnc_coords['y'],4), np.round(cnc_coords['z'],4), np.round(cnc_coords['a_deg'],3),np.round(cnc_coords['b_deg'],4)
        #tool tip - XYZAB coordinates at the mouse position
        if not hasattr(self, '_testing') or not self._testing:
            try:
                from PyQt5.QtCore import QThread
                if QThread.currentThread() is QThread.currentThread().parent():  # Check if in main thread
                    cursor_pos = QCursor.pos()
                    QToolTip.showText(cursor_pos, 
                                      "XYZAB: "+ f"{x:0.6f}" + ", " + f"{y:0.6f}" + ", " + f"{z:0.6f}" + ", " + f"{a:0.6f}" + ", " + f"{b:0.6f}")
            except Exception:
                pass
            
        limits = self.gui.cnc_properties_handler.limits
        if (cnc_coords['x'] < limits['x_min'] or cnc_coords['x'] > limits['x_max'] or
            cnc_coords['y'] < limits['y_min'] or cnc_coords['y'] > limits['y_max'] or
            cnc_coords['z'] < limits['z_min'] or cnc_coords['z'] > limits['z_max'] or
            cnc_coords['a_deg'] < limits['a_min'] or cnc_coords['a_deg'] > limits['a_max'] or
            cnc_coords['b_deg'] < limits['b_min'] or cnc_coords['b_deg'] > limits['b_max']):

            # tool tip - Z value is out of range
            if not hasattr(self, '_testing') or not self._testing:
                try:
                    from PyQt5.QtCore import QThread
                    if QThread.currentThread() is QThread.currentThread().parent():  # Check if in main thread
                        cursor_pos = QCursor.pos()
                        QToolTip.showText(cursor_pos, 
                                          "The coordinates are outside the mechanical limits.\nStep with arrow keys or scrollbar\nor enter exact value to get closer.\nXYZAB: "+ f"{x:0.6f}" + ", " + f"{y:0.6f}" + ", " + f"{z:0.6f}" + ", " + f"{a:0.6f}" + ", " + f"{b:0.6f}")
                except Exception:
                    pass
            
            return False
        else:
            return True
        
    def cnc_coords_in_limits(self, x, y, z, a_deg, b_deg):
        limits = self.gui.cnc_properties_handler.limits
        if not self._testing:
            self._testing = True  # Set testing mode to True for collision check
            mat_coords = self.cnc_to_material(x,y,z,a_deg,b_deg)
            self._testing = False  # Reset testing mode to False after collision check
        else:
            mat_coords = self.cnc_to_material(x,y,z,a_deg,b_deg)

        if (x < limits['x_min'] or x > limits['x_max'] or
            y < limits['y_min'] or y > limits['y_max'] or
            z < limits['z_min'] or z > limits['z_max'] or
            a_deg < limits['a_min'] or a_deg > limits['a_max'] or
            b_deg < limits['b_min'] or b_deg > limits['b_max'] or
            mat_coords['z'] < self.gui.cnc_properties_handler.build_offsets[2]):
            # Skip tooltip display if not in the main thread or during testing/planning
            if not hasattr(self, '_testing') or not self._testing:
                try:
                    from PyQt5.QtCore import QThread
                    if QThread.currentThread() is QThread.currentThread().parent():  # Check if in main thread
                        cursor_pos = QCursor.pos()
                        QToolTip.showText(cursor_pos, "The coordinates are outside the mechanical limits.")
                except Exception:
                    pass  # Silently ignore if tooltip cannot be shown
            return False
        return True
       
    def in_limits(self, x, y, z, a, b, nz=None, b_deg=None, elbow_up=None):
        
        if nz is None:
            return self.cnc_coords_in_limits(x, y, z, a, b)
        else:   
            return self.is_within_limits(x, y, z, a, b, nz, b_deg, elbow_up)

    def get_transformed_cutting_tool_mesh(self):
        # Create or get tool mesh with full transformations based on coordinate system
        current_system = self.gui.coord_system_combo.currentText()
        if self.cutting_tool.get('stl_model'):
            stl_model = self.cutting_tool['stl_model']
            vertices = stl_model.vectors.reshape(-1, 3)
            faces = np.arange(len(stl_model.vectors) * 3).reshape(len(stl_model.vectors), 3)
            tool_mesh = trimesh.Trimesh(vertices=vertices, faces=faces, process=True)
            if not tool_mesh.is_watertight:
                tool_mesh.fill_holes()
                print("Repaired tool mesh to make it watertight")
            centroid = np.mean(vertices, axis=0)
        else:
            diameter, length, cone_length = self.cutting_tool['dimensions']
            radius = diameter / 2.0
            if self.cutting_tool['type'] == 'Cylinder':
                tool_mesh = trimesh.creation.cylinder(radius=radius, height=length)
                tool_mesh.apply_translation([0, 0, length / 2])
            else:
                rot_matrix = trimesh.transformations.rotation_matrix(np.pi, [1, 0, 0])

                # Create a transformation matrix (rotation + translation if needed)
                xform_matrix = trimesh.transformations.concatenate_matrices(
                    rot_matrix,
                    trimesh.transformations.translation_matrix([0, 0, 0])  # No translation needed in this case
                )
                cone = trimesh.creation.cone(radius=radius, height=cone_length, transform=xform_matrix)
                cylinder = trimesh.creation.cylinder(radius=radius, height=length - cone_length)
                cone.apply_translation([0, 0, cone_length])
                cylinder.apply_translation([0, 0, cone_length + (length - cone_length)/2])
                tool_mesh = cone + cylinder
            
        if current_system == 'XYZ + Normal':
                translation = self.cutting_tool['material_translation']
                nx, ny, nz = self.cutting_tool['rotation']
                a_deg, b_deg = self.cutting_tool['ab_rotation']
                elbowUp = a_deg >= 0.0
                if abs(nz) < 0.999999:
                    if not self._testing:
                        self._testing = True  # Set testing mode to True for collision check
                        self.material_to_cnc(translation[0], translation[1], translation[2], nx, ny, nz, b_deg, elbowUp)
                        self._testing = False  # Reset testing mode to False after collision check
                    else:
                        self.material_to_cnc(translation[0], translation[1], translation[2], nx, ny, nz, b_deg, elbowUp)
                    yaw = self.cutting_tool['ab_rotation'][1]
                    pitch = self.cutting_tool['ab_rotation'][0]
                else:
                    yaw = 0.0
                    pitch = 0.0
                full_transform = np.eye(4)
                translation_matrix = np.eye(4)
                translation_matrix[:3, 3] = translation
                full_transform = np.dot(full_transform, translation_matrix)
                rotation_matrix_b = R.from_euler('z', -yaw, degrees=True).as_matrix()
                rotation_matrix_a = R.from_euler('x', -pitch, degrees=True).as_matrix()
                rotation_matrix = np.dot(rotation_matrix_b, rotation_matrix_a)  # Swapped to apply B first, then A
                rotation_matrix_4x4 = np.eye(4)
                rotation_matrix_4x4[:3, :3] = rotation_matrix
                full_transform = np.dot(full_transform, rotation_matrix_4x4)
                tool_mesh.apply_transform(full_transform)
        else:
            translation = self.cutting_tool['cnc_translation']
            a_deg = self.cutting_tool['ab_rotation'][0]
            b_deg = self.cutting_tool['ab_rotation'][1]
            full_transform = np.eye(4)
            rotation_matrix_b = R.from_euler('z', -b_deg, degrees=True).as_matrix()
            rotation_matrix_a = R.from_euler('x', -a_deg, degrees=True).as_matrix()
            rotation_matrix = np.dot(rotation_matrix_b, rotation_matrix_a)  # Swapped to apply B first, then A
            rotation_matrix_4x4 = np.eye(4)
            rotation_matrix_4x4[:3, :3] = rotation_matrix
            full_transform = np.dot(full_transform, rotation_matrix_4x4)
            translation_matrix = np.eye(4)
            translation_matrix[:3, 3] = translation
            full_transform = np.dot(full_transform, translation_matrix)
            tool_mesh.apply_transform(full_transform)  
        return tool_mesh, full_transform
    
    def get_test_cutting_tool_mesh(self, system, x, y, z, a_or_nx, b_or_ny, nz=None, b_deg=None, elbow_up=None):
        # Create or get tool mesh based on current tool definition
        if self.cutting_tool.get('stl_model'):
            stl_model = self.cutting_tool['stl_model']
            vertices = stl_model.vectors.reshape(-1, 3)
            faces = np.arange(len(stl_model.vectors) * 3).reshape(len(stl_model.vectors), 3)
            tool_mesh = trimesh.Trimesh(vertices=vertices, faces=faces, process=True)
            if not tool_mesh.is_watertight:
                tool_mesh.fill_holes()
        else:
            diameter, length, cone_length = self.cutting_tool['dimensions']
            radius = diameter / 2.0
            if self.cutting_tool['type'] == 'Cylinder':
                tool_mesh = trimesh.creation.cylinder(radius=radius, height=length)
                tool_mesh.apply_translation([0, 0, length / 2])
            else:
                rot_matrix = trimesh.transformations.rotation_matrix(np.pi, [1, 0, 0])
                cone = trimesh.creation.cone(radius=radius, height=cone_length, transform=rot_matrix)
                cone.apply_translation([0, 0, cone_length])
                cylinder = trimesh.creation.cylinder(radius=radius, height=length - cone_length)
                cylinder.apply_translation([0, 0, cone_length + (length - cone_length)/2])
                tool_mesh = cone + cylinder

        # Apply transformations based on the input coordinate system
        if system == 'XYZ + Normal':
            # Convert material coordinates to CNC for consistency in transformation
            if b_deg is None or elbow_up is None:
                raise ValueError("b_deg and elbow_up must be provided for XYZ + Normal system")
            if not self._testing:
                self._testing = True  # Set testing mode to True for material to CNC conversion
                cnc_coords = self.material_to_cnc(x, y, z, a_or_nx, b_or_ny, nz, b_deg, elbow_up)
                #cnc_coords = np.round(cnc_coords, 4)

                self._testing = False  # Reset testing mode
            else:
                cnc_coords = self.material_to_cnc(x, y, z, a_or_nx, b_or_ny, nz, b_deg, elbow_up)
            translation = [cnc_coords['x'], cnc_coords['y'], cnc_coords['z']]
            a_deg = cnc_coords['a_deg']
            b_deg = cnc_coords['b_deg']
        else:  # Stepper (XYZAB)
            translation = [x, y, z]
            a_deg = a_or_nx
            b_deg = b_or_ny

        # Apply transformations to tool mesh (same as in check_tool_keepout_intersection)
        full_transform = np.eye(4)
        rotation_matrix_b = R.from_euler('z', -b_deg, degrees=True).as_matrix()
        rotation_matrix_a = R.from_euler('x', -a_deg, degrees=True).as_matrix()
        rotation_matrix = np.dot(rotation_matrix_b, rotation_matrix_a)  # Apply B first, then A
        rotation_matrix_4x4 = np.eye(4)
        rotation_matrix_4x4[:3, :3] = rotation_matrix
        full_transform = np.dot(full_transform, rotation_matrix_4x4)
        translation_matrix = np.eye(4)
        translation_matrix[:3, 3] = translation
        full_transform = np.dot(full_transform, translation_matrix)
        tool_mesh.apply_transform(full_transform)
        return tool_mesh, full_transform

    def material_to_cnc(self, mat_x, mat_y, mat_z, u_x, u_y, u_z, b_deg, elbow_up):
        """
        Convert material frame coordinates (XYZ + Normal) to CNC frame (XYZAB in degrees).
        This matches the firmware's materialToCNC function.
        Returns a dictionary with CNC frame values: {'x', 'y', 'z', 'a_deg', 'b_deg'}.
        """
        #if not hasattr(self, '_testing') or not self._testing:
            #print(f"Material to CNC: Material X={mat_x:.2f}, Y={mat_y:.2f}, Z={mat_z:.2f}, Normal X={u_x:.2f}, Y={u_y:.2f}, Z={u_z:.2f}, Fallback B={b_deg:.2f} deg, Elbow Up={elbow_up}")
        
        # Get pan and tilt angles from unit vector
        a_rad, b_rad = self.get_pan_tilt(u_x, u_y, u_z, elbow_up)
        if a_rad == 0:
            b_rad = np.radians(b_deg)
        
        # Compute transformation matrix for material to CNC
        matrix_b = np.zeros((3, 3))
        matrix_b = self.get_material_to_cnc_matrix(a_rad, b_rad, matrix_b)
        local = np.array([mat_x, mat_y, mat_z])
        cnc_coords = np.dot(matrix_b, local)
        
        b_deg_normalized = np.round(np.degrees(b_rad) % 360,3)
        
        # Update CNC coordinates in cutting tool handler, but only if not in a test context
        if not hasattr(self, '_testing') or not self._testing:
            #print(f"Material to CNC: CNC X={cnc_coords[0]:.2f}, Y={cnc_coords[1]:.2f}, Z={cnc_coords[2]:.2f}, A={np.degrees(a_rad):.2f} deg, B={b_deg_normalized:.2f} deg")
            self.cutting_tool['cnc_translation'] = [np.round(cnc_coords[0],4), np.round(cnc_coords[1],4), np.round(cnc_coords[2],4)]
            self.cutting_tool['ab_rotation'] = [np.round(np.degrees(a_rad),3), np.round(b_deg_normalized,3)]
            # Inflate ranges before updating sliders to prevent clamping
            if self.gui.coord_system_combo.currentText() == 'Stepper (XYZAB)':
                self.gui.inflate_tool_rotation_ranges()
                self.gui.update_tool_sliders_for_system('Stepper (XYZAB)')
                self.gui.set_final_rotation_ranges(self.gui.rotation_unit)
        
        return {
            'x': np.round(cnc_coords[0],4),
            'y': np.round(cnc_coords[1],4),
            'z': np.round(cnc_coords[2],4),
            'a_deg': np.round(np.degrees(a_rad),3),
            'b_deg': np.round(b_deg_normalized, 3)
        }

    def cnc_to_material(self, cnc_x, cnc_y, cnc_z, cnc_a_deg, cnc_b_deg):
        """
        Convert CNC frame coordinates (XYZAB in degrees) to material frame (XYZ + Normal).
        Returns a dictionary with material frame values: {'x', 'y', 'z', 'u_x', 'u_y', 'u_z', 'b'}.
        """
        if not hasattr(self, '_testing') or not self._testing:
            print(f"CNC to Material: CNC X={cnc_x:.2f}, Y={cnc_y:.2f}, Z={cnc_z:.2f}, A={cnc_a_deg:.2f} deg, B={cnc_b_deg:.2f} deg")
        
        a_rad = np.radians(cnc_a_deg)
        b_rad = np.radians(cnc_b_deg)
        # Get rotation matrix for unit vector transformation (tool direction)
        matrix_r = np.zeros((3, 3))
        self.get_rotation_matrix(a_rad, b_rad, matrix_r)
        
        # Transform unit vector (tool direction [0,0,1] to match STL normal orientation)
        u = np.array([0, 0, 1])  # Positive Z to match STL normal convention
        rotated_unit_vector = np.dot(matrix_r, u)
            
        # Get inverse rotation matrix for translation transformation
        matrix_a = np.zeros((3, 3))
        self.get_inverse_rotation_matrix(a_rad, b_rad, matrix_a)
        
        # Transform translation (local to material)
        local = np.array([cnc_x, cnc_y, cnc_z])
        material = np.dot(matrix_a, local)
        
        # Update material translation and rotation centrally, but only if not in a test context
        if not hasattr(self, '_testing') or not self._testing:
            #print(f"CNC to Material: Material X={material[0]:.2f}, Y={material[1]:.2f}, Z={material[2]:.2f}, Normal X={rotated_unit_vector[0]:.2f}, Y={rotated_unit_vector[1]:.2f}, Z={rotated_unit_vector[2]:.2f}")
            self.cutting_tool['material_translation'] = [material[0], material[1], material[2]]
            nx, ny, nz = rotated_unit_vector[0], -rotated_unit_vector[1], rotated_unit_vector[2]
            self.cutting_tool['rotation'] = [nx, ny, nz]
            # Inflate ranges before updating sliders to prevent clamping
            self.gui.inflate_tool_rotation_ranges()
            self.gui.update_tool_sliders_for_system('XYZ + Normal')
            self.gui.set_final_rotation_ranges(self.gui.rotation_unit)
       
        return {
            'x': material[0],
            'y': material[1],
            'z': material[2],
            'u_x': rotated_unit_vector[0],
            'u_y': -rotated_unit_vector[1],
            'u_z': rotated_unit_vector[2],
            'b': cnc_b_deg  # Store B for potential use when a_rad is 0
        }  
    
    def get_rotation_matrix(self, a_rad, b_rad, rotation_matrix):
        """
        Compute the rotation matrix for CNC to Material transformation of unit vector.
        Matches firmware's getRotationMatrix function.
        Modifies the provided rotation_matrix (3x3 numpy array) in place.
        """
        cos_b = np.cos(b_rad)
        sin_b = np.sin(b_rad)
        cos_a = np.cos(a_rad)
        sin_a = np.sin(a_rad)
        
        rotation_matrix[0, 0] = cos_b
        rotation_matrix[0, 1] = -sin_b * cos_a
        rotation_matrix[0, 2] = sin_b * sin_a
        rotation_matrix[1, 0] = sin_b
        rotation_matrix[1, 1] = cos_b * cos_a
        rotation_matrix[1, 2] = -cos_b * sin_a
        rotation_matrix[2, 0] = 0
        rotation_matrix[2, 1] = sin_a
        rotation_matrix[2, 2] = cos_a

    def get_inverse_rotation_matrix(self, a_rad, b_rad, rotation_matrix):
        """
        Compute the inverse rotation matrix for CNC to Material transformation of translation.
        Matches firmware's getInverseRotationMatrix function.
        Modifies the provided rotation_matrix (3x3 numpy array) in place.
        """
        cos_b = np.cos(b_rad)
        sin_b = np.sin(b_rad)
        cos_a = np.cos(a_rad)
        sin_a = np.sin(a_rad)
        
        rotation_matrix[0, 0] = cos_b
        rotation_matrix[0, 1] = sin_b * cos_a
        rotation_matrix[0, 2] = sin_b * sin_a
        rotation_matrix[1, 0] = -sin_b
        rotation_matrix[1, 1] = cos_b * cos_a
        rotation_matrix[1, 2] = cos_b * sin_a
        rotation_matrix[2, 0] = 0
        rotation_matrix[2, 1] = -sin_a
        rotation_matrix[2, 2] = cos_a

    def get_material_to_cnc_matrix(self, a_rad, b_rad, rotation_matrix=np.eye(3)):
        """
        Compute the rotation matrix for Material to CNC transformation.
        Matches firmware's getMaterialToCNCMatrix function.
        Modifies the provided rotation_matrix (3x3 numpy array) in place.
        """
        cos_b = np.cos(b_rad)
        sin_b = np.sin(b_rad)
        cos_a = np.cos(a_rad)
        sin_a = np.sin(a_rad)
        
        rotation_matrix[0, 0] = cos_b
        rotation_matrix[0, 1] = -sin_b
        rotation_matrix[0, 2] = 0
        rotation_matrix[1, 0] = sin_b * cos_a
        rotation_matrix[1, 1] = cos_b * cos_a
        rotation_matrix[1, 2] = -sin_a
        rotation_matrix[2, 0] = sin_b * sin_a
        rotation_matrix[2, 1] = cos_b * sin_a
        rotation_matrix[2, 2] = cos_a

        return rotation_matrix

    def get_pan_tilt(self, u_x, u_y, u_z, elbow_up, original_b_deg=None):
        """
        Convert a unit vector (normal) to pan and tilt angles (A and B in radians).
        Adapted from firmware's getPanTilt function.
        Returns angles as a tuple (a_rad, b_rad).
        """
        a_rad = np.acos(u_z)
        if not elbow_up:
            a_rad = -a_rad  # Elbow down: negative tilt
        
        sin_a = np.sin(a_rad)  # Use absolute value since sign is handled by a
        if sin_a != 0:
            if elbow_up:
                b_rad = np.arctan2(u_x, u_y)
            else:
                b_rad = np.arctan2(-u_x, -u_y)  # Flip signs for negative a
            if b_rad < 0:
                b_rad += 2 * np.pi  # Normalize to [0, 360°]
        else:
            b_rad = 0  # Undefined when a = 0°, default to 0
        return (a_rad, b_rad)

    def check_tool_keepout_intersection(self):
        self.gui.intersection_occurred = False  # Reset flag
        if self.cutting_tool:
            try:
                #print("CHECK KEEPOUT: getting cutting tool mesh")
                tool_mesh = self.get_transformed_cutting_tool_mesh()[0] 
                tool_bounds = tool_mesh.bounds
                for idx, keepout in enumerate(self.cnc_properties_handler.keepout_zones):
                    keepout_mesh = self.cnc_properties_handler.get_transformed_keepout_mesh(keepout)[0]
                    keepout_bounds = keepout_mesh.bounds
                    if not (tool_bounds[1][0] < keepout_bounds[0][0] or tool_bounds[0][0] > keepout_bounds[1][0] or
                            tool_bounds[1][1] < keepout_bounds[0][1] or tool_bounds[0][1] > keepout_bounds[1][1] or
                            tool_bounds[1][2] < keepout_bounds[0][2] or tool_bounds[0][2] > keepout_bounds[1][2]):
                        #print("Checking for intersection with keepout mesh,")
                        intersection = tool_mesh.intersection(keepout_mesh)
                        if intersection.volume > 0:
                            self.gui.intersection_occurred = True
                            return
                for idx, stl in enumerate(self.stl_handler.stl_models):
                    scale = stl['scale']
                    stl_mesh = self.stl_handler.get_transformed_stl_mesh(stl)[0]
                    stl_bounds = np.array(stl_mesh.bounds)*scale
                    if not (tool_bounds[1][0] < stl_bounds[0][0] or tool_bounds[0][0] > stl_bounds[1][0] or
                            tool_bounds[1][1] < stl_bounds[0][1] or tool_bounds[0][1] > stl_bounds[1][1] or
                            tool_bounds[1][2] < stl_bounds[0][2] or tool_bounds[0][2] > stl_bounds[1][2]):
                        #print("Checking for intersection with STL mesh")
                        intersection = tool_mesh.intersection(stl_mesh)
                        if intersection.volume > 0:
                            self.gui.intersection_occurred = True
                            return
            except Exception as e:
                print(f"Error in intersection check: {e}")

    def check_tool_collision(self, system, x, y, z, a_or_nx, b_or_ny, nz=None, b_deg=None, elbow_up=None, threshold=0.0):
        """
        Check if the tool at the specified position and orientation collides with keepout zones or STL objects.
        Accepts either CNC (XYZAB) or Material (XYZ+Normal) coordinates based on the 'system' parameter.
        Does not update the current tool position or render it, suitable for testing hypothetical positions.
        Returns True if a collision is detected, False otherwise.

        Parameters:
        - system (str): Either 'Stepper (XYZAB)' for CNC coordinates or 'XYZ + Normal' for material coordinates.
        - x, y, z (float): Position coordinates in the specified system.
        - a_or_nx (float): A angle in degrees (for XYZAB) or Normal X component (for XYZ+Normal).
        - b_or_ny (float): B angle in degrees (for XYZAB) or Normal Y component (for XYZ+Normal).
        - nz (float, optional): Normal Z component (for XYZ+Normal only, ignored for XYZAB).
        - b_deg (float, optional): Fallback B angle in degrees for material to CNC conversion (for XYZ+Normal only).
        - elbow_up (bool, optional): Elbow up flag for material to CNC conversion (for XYZ+Normal only).
        """
        collision_detected = False
        try:
            tool_mesh = self.get_test_cutting_tool_mesh(system, x, y, z, a_or_nx, b_or_ny, nz, b_deg, elbow_up)[0]
            tool_bounds = np.round(tool_mesh.bounds,4)

            # Check intersections with keepout zones
            for keepout in self.cnc_properties_handler.keepout_zones:
                keepout_mesh = self.cnc_properties_handler.get_transformed_keepout_mesh(keepout)[0]
                keepout_bounds = np.round(keepout_mesh.bounds,4)
                if not (tool_bounds[1][0] <= keepout_bounds[0][0] or tool_bounds[0][0] >= keepout_bounds[1][0] or
                        tool_bounds[1][1] <= keepout_bounds[0][1] or tool_bounds[0][1] >= keepout_bounds[1][1] or
                        tool_bounds[1][2] <= keepout_bounds[0][2] or tool_bounds[0][2] >= keepout_bounds[1][2]):
                    intersection = tool_mesh.intersection(keepout_mesh)
                    if intersection.volume > threshold:
                        collision_detected = True
                        return collision_detected

            # Check intersections with STL objects
            for stl in self.stl_handler.stl_models:
                
                stl_mesh = self.stl_handler.get_transformed_stl_mesh(stl)[0]
                stl_bounds = np.round(stl_mesh.bounds,4)
                if not (tool_bounds[1][0] <= stl_bounds[0][0] or tool_bounds[0][0] >= stl_bounds[1][0] or
                        tool_bounds[1][1] <= stl_bounds[0][1] or tool_bounds[0][1] >= stl_bounds[1][1] or
                        tool_bounds[1][2] <= stl_bounds[0][2] or tool_bounds[0][2] >= stl_bounds[1][2]):
                    intersection = tool_mesh.intersection(stl_mesh)
                    intersection_volume = intersection.volume
                    if intersection_volume > threshold:
                        collision_detected = True
                        return collision_detected
                    
        except Exception as e:
            print(f"Error in collision check: {e}")
            collision_detected = False  # Assume collision on error to be safe

        return collision_detected

    def test_cnc_to_material_round_trip(self):
        """
        Test round-trip conversion from CNC to Material and back to CNC.
        Prints the original CNC coordinates, the converted Material coordinates, and the final CNC coordinates after conversion back.
        """
        
        # Define test ranges for A and B angles (in degrees)
        a_range = range(-90, 91, 22)  # A from -90 to 90 degrees, step by 22.5 degrees
        b_range = range(0, 360, 22)   # B from 0 to 360 degrees, step by 22.5 degrees
        initial_cnc = {'x': 0.0, 'y': -5.0, 'z': 10.0}  # Initial XYZ position in CNC frame

        # Set testing flag to prevent state updates during conversions
        self._testing = True
        for a_deg in a_range:
            for b_deg in b_range:
                elbow_up = a_deg >= 0
                # Original CNC coordinates
                cnc_coords = {'x': initial_cnc['x'], 'y': initial_cnc['y'], 'z': initial_cnc['z'], 'a_deg': a_deg, 'b_deg': b_deg}
                
                # Convert CNC to Material
                mat_coords = self.cnc_to_material(cnc_coords['x'], cnc_coords['y'], cnc_coords['z'], cnc_coords['a_deg'], cnc_coords['b_deg'])
                
                # Convert Material back to CNC
                cnc_coords_back = self.material_to_cnc(
                    mat_coords['x'], mat_coords['y'], mat_coords['z'],
                    mat_coords['u_x'], mat_coords['u_y'], mat_coords['u_z'],
                    mat_coords['b'], elbow_up
                )
                #cnc_coords_back = np.round(cnc_coords_back, 4)
                
                # If the CNC coordinates don't match, Print results
                if abs(cnc_coords['x'] - cnc_coords_back['x']) > 0.01 or abs(cnc_coords['y'] - cnc_coords_back['y']) > 0.01 or abs(cnc_coords['z'] - cnc_coords_back['z']) > 0.01 or abs(cnc_coords['a_deg'] - cnc_coords_back['a_deg']) > 0.01 or abs(cnc_coords['b_deg'] - cnc_coords_back['b_deg']) > 0.01:
                    print("Roundtrip CNC to Material and back failed:")
                    print(f"CNC: X={cnc_coords['x']:.2f}, Y={cnc_coords['y']:.2f}, Z={cnc_coords['z']:.2f}, A={cnc_coords['a_deg']:.2f}, B={cnc_coords['b_deg']:.2f}")
                    print(f" -> Material: X={mat_coords['x']:.2f}, Y={mat_coords['y']:.2f}, Z={mat_coords['z']:.2f}, Nx={mat_coords['u_x']:.2f}, Ny={mat_coords['u_y']:.2f}, Nz={mat_coords['u_z']:.2f}")
                    print(f" -> CNC Back: X={cnc_coords_back['x']:.2f}, Y={cnc_coords_back['y']:.2f}, Z={cnc_coords_back['z']:.2f}, A={cnc_coords_back['a_deg']:.2f}, B={cnc_coords_back['b_deg']:.2f}")
                    print("---")
        self._testing = False

    def test_material_to_cnc_round_trip(self):
        """
        Test round-trip conversion from Material to CNC and back to Material.
        Prints the original Material coordinates, the converted CNC coordinates, and the final Material coordinates after conversion back.
        """
        # Define test ranges for normal vector components (simulating various orientations)
        nx_range = [-1.0, -0.5, 0.0, 0.5, 1.0]
        ny_range = [-1.0, -0.5, 0.0, 0.5, 1.0]
        initial_mat = {'x': 0.0, 'y': -5.0, 'z': 10.0}  # Initial XYZ position in Material frame
        elbow_up = True  # Test with elbow up configuration

        # Set testing flag to prevent state updates during conversions
        self._testing = True
        for nx in nx_range:
            for ny in ny_range:
                # Compute nz to ensure unit vector (assuming z must be non-negative for valid orientation)
                nz_squared = 1.0 - nx**2 - ny**2
                if nz_squared < 0:
                    continue  # Skip invalid combinations where magnitude would exceed 1
                nz = np.sqrt(nz_squared)
                
                # Original Material coordinates
                mat_coords = {'x': initial_mat['x'], 'y': initial_mat['y'], 'z': initial_mat['z'], 'u_x': nx, 'u_y': ny, 'u_z': nz}
                
                # Convert Material to CNC
                b_deg = 0.0  # Default B angle for fallback if A is 0
                cnc_coords = self.material_to_cnc(
                    mat_coords['x'], mat_coords['y'], mat_coords['z'],
                    mat_coords['u_x'], mat_coords['u_y'], mat_coords['u_z'],
                    b_deg, elbow_up
                )
                #cnc_coords = np.round(cnc_coords, 4)
                
                # Convert CNC back to Material
                mat_coords_back = self.cnc_to_material(
                    cnc_coords['x'], cnc_coords['y'], cnc_coords['z'],
                    cnc_coords['a_deg'], cnc_coords['b_deg']
                )
                
                # Print results
                if abs(mat_coords['x'] - mat_coords_back['x']) > 0.01 or abs(mat_coords['y'] - mat_coords_back['y']) > 0.01 or abs(mat_coords['z'] - mat_coords_back['z']) > 0.01 or abs(mat_coords['u_x'] - mat_coords_back['u_x']) > 0.01 or abs(mat_coords['u_y'] - mat_coords_back['u_y']) > 0.01 or abs(mat_coords['u_z'] - mat_coords_back['u_z']) > 0.01:
                    print("Material to CNC Round Trip Conversion failed:")
                    print(f"Material: X={mat_coords['x']:.2f}, Y={mat_coords['y']:.2f}, Z={mat_coords['z']:.2f}, Nx={mat_coords['u_x']:.2f}, Ny={mat_coords['u_y']:.2f}, Nz={mat_coords['u_z']:.2f}")
                    print(f" -> CNC: X={cnc_coords['x']:.2f}, Y={cnc_coords['y']:.2f}, Z={cnc_coords['z']:.2f}, A={cnc_coords['a_deg']:.2f}, B={cnc_coords['b_deg']:.2f}")
                    print(f" -> Material Back: X={mat_coords_back['x']:.2f}, Y={mat_coords_back['y']:.2f}, Z={mat_coords_back['z']:.2f}, Nx={mat_coords_back['u_x']:.2f}, Ny={mat_coords_back['u_y']:.2f}, Nz={mat_coords_back['u_z']:.2f}")
                    print("---")
        self._testing = False

    def check_tool_inside_raw_material(self, system=None, x=None, y=None, z=None, a_or_nx=None, b_or_ny=None, nz=None, b_deg=None, elbow_up=None, raw_mesh=None):

        if not self.gui.raw_material_handler.raw_material or not self.gui.cutting_tool_handler.cutting_tool:
            return False
        
        if system is None:
            tool_mesh, _ = self.get_transformed_cutting_tool_mesh()
        else:
            tool_mesh, _ = self.get_test_cutting_tool_mesh(system, x, y, z, a_or_nx, b_or_ny, nz, b_deg, elbow_up)
        raw_material_mesh = None
        if raw_mesh is None:
            raw_material_mesh, _ = self.gui.raw_material_handler.get_transformed_raw_material_mesh()
        else:
            raw_material_mesh = raw_mesh
        tool_bounds = tool_mesh.bounds
        raw_bounds = raw_material_mesh.bounds
            
        # Quick bounding box check
        if (tool_bounds[1][0] < raw_bounds[0][0] or tool_bounds[0][0] > raw_bounds[1][0] or
            tool_bounds[1][1] < raw_bounds[0][1] or tool_bounds[0][1] > raw_bounds[1][1] or
            tool_bounds[1][2] < raw_bounds[0][2] or tool_bounds[0][2] > raw_bounds[1][2]):
            return False
        try:  
            # Perform intersection check
            intersection = trimesh.boolean.intersection([raw_material_mesh, tool_mesh])
            return intersection.volume > 0
        except Exception as e:
            print(f"Error in raw material intersection check: {e}")
            return False

    def is_valid_cut(self, system, x, y, z, a, b, nz=None, b_deg=None, elbow_up=True, raw_mesh=None, threshold=0.0):
        """
        Check if a contour contains raw material.
        Args:
            system (str): Coordinate system ('XYZAB' or 'XYZn').
            x (float): X coordinate.
            y (float): Y coordinate.
            z (float): Z coordinate.
            a (float): A rotation angle.
            b (float): B rotation angle.
            nz (float, optional): Normal vector Z component. Defaults to None.
            b_deg (float, optional): B rotation angle in degrees. Defaults to None.
            elbowUp (bool, optional): Elbow up flag. Defaults to True.
        Returns:
            bool: True if the contour contains raw material, False otherwise.
        """
        if raw_mesh is None:
            raw_mesh = self.param_dict['material_space_meshes']['raw_mesh']
        if self.planning_handler is None:
            print("IS VALID: planning_handler is None, returning False")
            return False
        if system not in ['XYZAB', 'XYZ + Normal']:
            return False
        collision = False
        raw = False
        limits = False
        #print(f"IS VALID: retrieving to be cut mesh")
        self._testing = True
        if system == 'XYZAB':
            limits = self.in_limits(x, y, z, a, b)
            if limits:
                collision = self.check_tool_collision(
                    'XYZAB', x, y, z, a, b, threshold=threshold)
                if not collision:
                    raw = self.check_tool_inside_raw_material(
                        'XYZAB', x, y, z, a, b, raw_mesh=raw_mesh
                    )
        elif system == 'XYZ + Normal':
            limits = self.in_limits(x, y, z, a, b, nz=nz, b_deg=b_deg, elbow_up=elbow_up)
            if limits:
                collision = self.check_tool_collision(
                    'XYZ + Normal', x, y, z, a, b, nz, b_deg, elbow_up, threshold=threshold)
                if not collision:
                    raw = self.check_tool_inside_raw_material(
                        'XYZ + Normal', x, y, z, a, b, nz=nz, b_deg=b_deg, elbow_up=elbow_up, raw_mesh=raw_mesh
                    )
                    
        self._testing = False
        if collision or (not raw) or (not limits):
            #if collision:
                #self.planning_handler.found_stl = True
            #print(f"IS VALID: Invalid cut - Limits: {limits}, Collision: {collision}, Raw: {raw}, point ({x}, {y}, {z}) {system}")
            return False
        
        if self.mesh_utils.has_to_be_cut_mesh:
            to_be_cut = self.mesh_utils.get_to_be_cut_mesh()
            tool_mesh = self.get_test_cutting_tool_mesh(system, x, y, z, a, b, nz, b_deg, elbow_up)[0]
            intersection = to_be_cut.intersection(tool_mesh)
            intersection_is_valid = self.mesh_utils.mesh_is_valid(intersection)[0]
            if not intersection_is_valid:

                return False

        return True

    def set_param_dict(self, param_dict):
        """
        Set the planning handler for the cutting tool handler.
        Args:
            planning_handler (object): The planning handler object.
        """
        self.param_dict = param_dict
        self.planning_handler = param_dict['handlers']['planning_handler']
        self.mesh_utils = param_dict['utils']['mesh_utils']
        self.contour_utils = param_dict['utils']['contour_utils']
        


