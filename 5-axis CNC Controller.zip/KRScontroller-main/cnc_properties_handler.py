# File: cnc_properties_handler.py
from PyQt5.QtWidgets import QFileDialog, QHBoxLayout, QVBoxLayout, QLabel, QSlider, QLineEdit, QDoubleSpinBox, QFormLayout
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QComboBox
from stl import mesh
import trimesh
from scipy.spatial.transform import Rotation as R
import numpy as np
from OpenGL.GL import *
from opengl_utils import create_stl_display_lists

class CNCPropertiesHandler:
    def __init__(self, gui):
        self.gui = gui
        self.helpers = gui.helpers
        self.keepout_zones = []
        self.selected_index = -1
        self.limits = {
            'x_min': -30.0, 'x_max': 30.0,
            'y_min': -30.0, 'y_max': 30.0,
            'z_min': 0.0, 'z_max': 30.0,
            'a_min': -90.0, 'a_max': 90.0,
            'b_min': 0.0, 'b_max': 360.0
        }
        self.build_offsets = [0.0, 0.0, 0.0]

    def update_limits(self):

        self.limits['x_min'] = self.helpers.convert_to_cm(self.gui.x_min_limit.value(), self.gui.current_unit)
        self.limits['x_max'] = self.helpers.convert_to_cm(self.gui.x_max_limit.value(), self.gui.current_unit)
        self.limits['y_min'] = self.helpers.convert_to_cm(self.gui.y_min_limit.value(), self.gui.current_unit)
        self.limits['y_max'] = self.helpers.convert_to_cm(self.gui.y_max_limit.value(), self.gui.current_unit)
        self.limits['z_min'] = self.helpers.convert_to_cm(self.gui.z_min_limit.value(), self.gui.current_unit)
        self.limits['z_max'] = self.helpers.convert_to_cm(self.gui.z_max_limit.value(), self.gui.current_unit)
        if self.gui.rotation_unit == 'DEG':
            self.limits['a_min'] = self.gui.a_min_limit.value()
            self.limits['a_max'] = self.gui.a_max_limit.value()
            self.limits['b_min'] = self.gui.b_min_limit.value()
            self.limits['b_max'] = self.gui.b_max_limit.value()
        else:
            self.limits['a_min'] = np.degrees(self.gui.a_min_limit.value())
            self.limits['a_max'] = np.degrees(self.gui.a_max_limit.value())
            self.limits['b_min'] = np.degrees(self.gui.b_min_limit.value())
            self.limits['b_max'] = np.degrees(self.gui.b_max_limit.value())
        
    def update_build_offsets(self):
        self.build_offsets[0] = self.helpers.convert_to_cm(self.gui.build_x_offset.value(), self.gui.current_unit)
        self.build_offsets[1] = self.helpers.convert_to_cm(self.gui.build_y_offset.value(), self.gui.current_unit)
        self.build_offsets[2] = self.helpers.convert_to_cm(self.gui.build_z_offset.value(), self.gui.current_unit)
        self.gui.stl_viewer.update()

    def update_limits_display(self, unit):
        self.gui.x_min_limit.blockSignals(True)
        self.gui.x_max_limit.blockSignals(True)
        self.gui.y_min_limit.blockSignals(True)
        self.gui.y_max_limit.blockSignals(True)
        self.gui.z_min_limit.blockSignals(True)
        self.gui.z_max_limit.blockSignals(True)
        self.gui.x_min_limit.setValue(self.helpers.convert_from_cm(self.limits['x_min'], unit))
        self.gui.x_max_limit.setValue(self.helpers.convert_from_cm(self.limits['x_max'], unit))
        self.gui.y_min_limit.setValue(self.helpers.convert_from_cm(self.limits['y_min'], unit))
        self.gui.y_max_limit.setValue(self.helpers.convert_from_cm(self.limits['y_max'], unit))
        self.gui.z_min_limit.setValue(self.helpers.convert_from_cm(self.limits['z_min'], unit))
        self.gui.z_max_limit.setValue(self.helpers.convert_from_cm(self.limits['z_max'], unit))
        if self.gui.rotation_unit == 'DEG':
            self.gui.b_min_limit.setValue(self.limits['b_min'])
            self.gui.b_max_limit.setValue(self.limits['b_max'])
        else:
            self.gui.b_min_limit.setValue(np.radians(self.limits['b_min']))
            self.gui.b_max_limit.setValue(np.radians(self.limits['b_max']))
        self.gui.x_min_limit.blockSignals(False)
        self.gui.x_max_limit.blockSignals(False)
        self.gui.y_min_limit.blockSignals(False)
        self.gui.y_max_limit.blockSignals(False)
        self.gui.z_min_limit.blockSignals(False)
        self.gui.z_max_limit.blockSignals(False)

    def update_build_offsets_display(self, unit):
        self.gui.build_x_offset.setValue(self.helpers.convert_from_cm(self.build_offsets[0], unit))
        self.gui.build_y_offset.setValue(self.helpers.convert_from_cm(self.build_offsets[1], unit))
        self.gui.build_z_offset.setValue(self.helpers.convert_from_cm(self.build_offsets[2], unit))

    def load_keepout_stl(self):
        file_name, _ = QFileDialog.getOpenFileName(self.gui, "Open Keepout STL File", "", "STL Files (*.stl)")
        if file_name:
            stl_model = mesh.Mesh.from_file(file_name)
            centroid = np.mean(stl_model.vectors, axis=(0, 1))
            translation = [-centroid[0], -centroid[1], -centroid[2]]
            _, wireframe_list = create_stl_display_lists(stl_model)
            
            self.keepout_zones.append({
                'type': 'stl',
                'name' : file_name.split('/')[-1],
                'model': stl_model,
                'translation': translation,
                'rotation': [0.0, 0.0, 0.0],
                'quaternion': [1.0, 0.0, 0.0, 0.0],
                'scale': 1.0,
                'file_name': file_name,
                'centroid': centroid,
                'wireframe_list': wireframe_list
            })
            self.gui.keepout_list.addItem(file_name.split('/')[-1])
            self.gui.keepout_list.setCurrentRow(len(self.keepout_zones) - 1)
            self.selected_index = len(self.keepout_zones) - 1
            self.update_keepout_sliders()
            self.gui.center_view()  # Automatically center the view on the new Keepout STL
            self.gui.stl_viewer.update()

    def new_keepout_shape(self):
        keepout_id = len(self.keepout_zones) + 1
        self.keepout_zones.append({
            'type': 'shape',
            'translation': [0.0, 0.0, 0.0],
            'rotation': [0.0, 0.0, 0.0],
            'quaternion': [1.0, 0.0, 0.0, 0.0],
            'dimensions': [5.0, 5.0, 5.0],  # Length, Width, Height in cm
            'scale': 1.0,
            'file_name': f"Keepout Shape {keepout_id}",
            'wireframe_list': self.create_keepout_shape_wireframe(5.0, 5.0, 5.0)
        })
        self.gui.keepout_list.addItem(f"Keepout Shape {keepout_id}")
        self.gui.keepout_list.setCurrentRow(len(self.keepout_zones) - 1)
        self.selected_index = len(self.keepout_zones) - 1
        self.update_keepout_sliders()
        self.gui.center_view()  # Automatically center the view on the new Keepout shape
        self.gui.stl_viewer.update()

    def create_keepout_shape_wireframe(self, length, width, height):
        wireframe_list = glGenLists(1)
        glNewList(wireframe_list, GL_COMPILE)
        glBegin(GL_LINES)
        # Bottom face
        glVertex3f(-length/2, -width/2, -height/2)
        glVertex3f(length/2, -width/2, -height/2)
        glVertex3f(length/2, -width/2, -height/2)
        glVertex3f(length/2, width/2, -height/2)
        glVertex3f(length/2, width/2, -height/2)
        glVertex3f(-length/2, width/2, -height/2)
        glVertex3f(-length/2, width/2, -height/2)
        glVertex3f(-length/2, -width/2, -height/2)
        # Top face
        glVertex3f(-length/2, -width/2, height/2)
        glVertex3f(length/2, -width/2, height/2)
        glVertex3f(length/2, -width/2, height/2)
        glVertex3f(length/2, width/2, height/2)
        glVertex3f(length/2, width/2, height/2)
        glVertex3f(-length/2, width/2, height/2)
        glVertex3f(-length/2, width/2, height/2)
        glVertex3f(-length/2, -width/2, height/2)
        # Connecting edges
        glVertex3f(-length/2, -width/2, -height/2)
        glVertex3f(-length/2, -width/2, height/2)
        glVertex3f(length/2, -width/2, -height/2)
        glVertex3f(length/2, -width/2, height/2)
        glVertex3f(length/2, width/2, -height/2)
        glVertex3f(length/2, width/2, height/2)
        glVertex3f(-length/2, width/2, -height/2)
        glVertex3f(-length/2, width/2, height/2)
        glEnd()
        glEndList()
        return wireframe_list

    def delete_selected_keepout(self):
        if self.selected_index >= 0:
            keepout = self.keepout_zones[self.selected_index]
            if 'wireframe_list' in keepout:
                glDeleteLists(keepout['wireframe_list'], 1)
            del self.keepout_zones[self.selected_index]
            self.gui.keepout_list.takeItem(self.selected_index)
            self.selected_index = -1
            self.update_keepout_sliders()
            self.gui.stl_viewer.update()

    def select_keepout(self, item):
        current_row = self.gui.keepout_list.row(item)
        if self.selected_index == current_row:
            # Deselect if the clicked item is already selected
            self.selected_index = -1
            self.gui.last_selected_keepout_index = -1
            self.gui.keepout_list.clearSelection()    
            self.gui.stl_viewer.update()
        else:
            # Select the new item
            self.selected_index = current_row
            # Store the last selected Keepout index
            self.gui.last_selected_keepout_index = self.selected_index
            # Deselect any selected STL when a keepout is selected
            self.gui.stl_handler.selected_index = -1
            self.gui.stl_list.clearSelection()
            self.update_keepout_sliders()
            self.gui.center_view()  # Automatically center the view on the selected Keepout
            self.gui.stl_viewer.update()

    def add_sliders(self, layout):
        slider_layout = QHBoxLayout()
        layout.addLayout(slider_layout)
        
        translation_layout = QVBoxLayout()
        slider_layout.addLayout(translation_layout)
        translation_label = QLabel('Translation')
        translation_label.setAlignment(Qt.AlignCenter)
        translation_layout.addWidget(translation_label)
        translation_sliders_layout = QHBoxLayout()
        translation_layout.addLayout(translation_sliders_layout)
        
        x_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(x_translation_layout)
        self.keepout_x_slider = QSlider(Qt.Vertical)
        self.keepout_x_slider.setRange(-300000, 300000)
        self.keepout_x_slider.valueChanged.connect(self.update_keepout_x_translation)
        x_translation_layout.addWidget(QLabel('X'))
        x_translation_layout.addWidget(self.keepout_x_slider)
        self.keepout_x_entry = QLineEdit()
        self.keepout_x_entry.setFixedWidth(100)
        self.keepout_x_entry.setPlaceholderText('0.0')
        self.keepout_x_entry.setAlignment(Qt.AlignCenter)
        self.keepout_x_entry.returnPressed.connect(self.update_keepout_x_translation_from_entry)
        x_translation_layout.addWidget(self.keepout_x_entry)
        
        y_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(y_translation_layout)
        self.keepout_y_slider = QSlider(Qt.Vertical)
        self.keepout_y_slider.setRange(-300000, 300000)
        self.keepout_y_slider.valueChanged.connect(self.update_keepout_y_translation)
        y_translation_layout.addWidget(QLabel('Y'))
        y_translation_layout.addWidget(self.keepout_y_slider)
        self.keepout_y_entry = QLineEdit()
        self.keepout_y_entry.setFixedWidth(100)
        self.keepout_y_entry.setPlaceholderText('0.0')
        self.keepout_y_entry.setAlignment(Qt.AlignCenter)
        self.keepout_y_entry.returnPressed.connect(self.update_keepout_y_translation_from_entry)
        y_translation_layout.addWidget(self.keepout_y_entry)
        
        z_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(z_translation_layout)
        self.keepout_z_slider = QSlider(Qt.Vertical)
        self.keepout_z_slider.setRange(-300000, 300000)
        self.keepout_z_slider.valueChanged.connect(self.update_keepout_z_translation)
        z_translation_layout.addWidget(QLabel('Z'))
        z_translation_layout.addWidget(self.keepout_z_slider)
        self.keepout_z_entry = QLineEdit()
        self.keepout_z_entry.setFixedWidth(100)
        self.keepout_z_entry.setPlaceholderText('0.0')
        self.keepout_z_entry.setAlignment(Qt.AlignCenter)
        self.keepout_z_entry.returnPressed.connect(self.update_keepout_z_translation_from_entry)
        z_translation_layout.addWidget(self.keepout_z_entry)
        
        scale_layout = QVBoxLayout()
        slider_layout.addLayout(scale_layout)
        scale_label = QLabel('Scale')
        scale_label.setAlignment(Qt.AlignCenter)
        scale_layout.addWidget(scale_label)
        self.keepout_scale_slider = QSlider(Qt.Vertical)
        self.keepout_scale_slider.setRange(100, 5000)  # 0.1 to 5.0 scaled by 1000
        self.keepout_scale_slider.setValue(1000)  # Default scale 1.0
        self.keepout_scale_slider.valueChanged.connect(self.update_keepout_scale)
        scale_layout.addWidget(self.keepout_scale_slider)
        self.keepout_scale_entry = QLineEdit()
        self.keepout_scale_entry.setFixedWidth(100)
        self.keepout_scale_entry.setPlaceholderText('1.0')
        self.keepout_scale_entry.setAlignment(Qt.AlignCenter)
        self.keepout_scale_entry.returnPressed.connect(self.update_keepout_scale_from_entry)
        scale_layout.addWidget(self.keepout_scale_entry)
        
        rotation_layout = QVBoxLayout()
        slider_layout.addLayout(rotation_layout)
        rotation_label = QLabel('Rotation')
        rotation_label.setAlignment(Qt.AlignCenter)
        rotation_layout.addWidget(rotation_label)
        
        self.rotation_type_combo = QComboBox()
        self.rotation_type_combo.addItems(['Euler', 'Quaternion'])
        self.rotation_type_combo.currentTextChanged.connect(self.change_keepout_rotation_type)
        rotation_layout.addWidget(self.rotation_type_combo)
        
        rotation_sliders_layout = QHBoxLayout()
        rotation_layout.addLayout(rotation_sliders_layout)
        
        x_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(x_rotation_layout)
        self.keepout_rx_slider = QSlider(Qt.Vertical)
        self.keepout_rx_slider.setRange(-180000, 180000)
        self.keepout_rx_slider.valueChanged.connect(self.update_keepout_rx_rotation)
        x_rotation_layout.addWidget(QLabel('X'))
        x_rotation_layout.addWidget(self.keepout_rx_slider)
        self.keepout_rx_entry = QLineEdit()
        self.keepout_rx_entry.setFixedWidth(100)
        self.keepout_rx_entry.setPlaceholderText('0.0')
        self.keepout_rx_entry.setAlignment(Qt.AlignCenter)
        self.keepout_rx_entry.returnPressed.connect(self.update_keepout_rx_rotation_from_entry)
        x_rotation_layout.addWidget(self.keepout_rx_entry)
        
        y_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(y_rotation_layout)
        self.keepout_ry_slider = QSlider(Qt.Vertical)
        self.keepout_ry_slider.setRange(-180000, 180000)
        self.keepout_ry_slider.valueChanged.connect(self.update_keepout_ry_rotation)
        y_rotation_layout.addWidget(QLabel('Y'))
        y_rotation_layout.addWidget(self.keepout_ry_slider)
        self.keepout_ry_entry = QLineEdit()
        self.keepout_ry_entry.setFixedWidth(100)
        self.keepout_ry_entry.setPlaceholderText('0.0')
        self.keepout_ry_entry.setAlignment(Qt.AlignCenter)
        self.keepout_ry_entry.returnPressed.connect(self.update_keepout_ry_rotation_from_entry)
        y_rotation_layout.addWidget(self.keepout_ry_entry)
        
        z_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(z_rotation_layout)
        self.keepout_rz_slider = QSlider(Qt.Vertical)
        self.keepout_rz_slider.setRange(-180000, 180000)
        self.keepout_rz_slider.valueChanged.connect(self.update_keepout_rz_rotation)
        z_rotation_layout.addWidget(QLabel('Z'))
        z_rotation_layout.addWidget(self.keepout_rz_slider)
        self.keepout_rz_entry = QLineEdit()
        self.keepout_rz_entry.setFixedWidth(100)
        self.keepout_rz_entry.setPlaceholderText('0.0')
        self.keepout_rz_entry.setAlignment(Qt.AlignCenter)
        self.keepout_rz_entry.returnPressed.connect(self.update_keepout_rz_rotation_from_entry)
        z_rotation_layout.addWidget(self.keepout_rz_entry)
        
        dimensions_layout = QVBoxLayout()
        slider_layout.addLayout(dimensions_layout)
        dimensions_label = QLabel('Dimensions')
        dimensions_label.setAlignment(Qt.AlignCenter)
        dimensions_layout.addWidget(dimensions_label)
        dimensions_form = QFormLayout()
        self.keepout_length = QDoubleSpinBox()
        self.keepout_width = QDoubleSpinBox()
        self.keepout_height = QDoubleSpinBox()
        for spinbox in [self.keepout_length, self.keepout_width, self.keepout_height]:
            spinbox.setRange(-1e18, 1e18)  # Set wide range to remove limits
            spinbox.setSuffix(' cm')
            spinbox.setValue(5.0)
            spinbox.valueChanged.connect(self.update_keepout_dimensions)
            spinbox.setVisible(False)
        dimensions_form.addRow('Length:', self.keepout_length)
        dimensions_form.addRow('Width:', self.keepout_width)
        dimensions_form.addRow('Height:', self.keepout_height)
        dimensions_layout.addLayout(dimensions_form)

    def update_keepout_sliders(self):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.selected_index >= 0:
            keepout = self.keepout_zones[self.selected_index]
            x_val = self.helpers.convert_from_cm(keepout['translation'][0], self.gui.current_unit)
            y_val = self.helpers.convert_from_cm(keepout['translation'][1], self.gui.current_unit)
            z_val = self.helpers.convert_from_cm(keepout['translation'][2], self.gui.current_unit)
            self.keepout_x_slider.blockSignals(True)
            self.keepout_y_slider.blockSignals(True)
            self.keepout_z_slider.blockSignals(True)
            clamped_x = max(self.keepout_x_slider.minimum(), min(self.keepout_x_slider.maximum(), x_val*scaling_factor))
            clamped_y = max(self.keepout_y_slider.minimum(), min(self.keepout_y_slider.maximum(), y_val*scaling_factor))
            clamped_z = max(self.keepout_z_slider.minimum(), min(self.keepout_z_slider.maximum(), z_val*scaling_factor))
            self.keepout_x_slider.setValue(int(round(clamped_x)))
            self.keepout_y_slider.setValue(int(round(clamped_y)))
            self.keepout_z_slider.setValue(int(round(clamped_z)))
            self.keepout_x_slider.blockSignals(False)
            self.keepout_y_slider.blockSignals(False)
            self.keepout_z_slider.blockSignals(False)
            self.keepout_x_entry.setText(f"{x_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{x_val:.3f}" if self.gui.current_unit == 'MM' else f"{x_val:.1f}")
            self.keepout_y_entry.setText(f"{y_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{y_val:.3f}" if self.gui.current_unit == 'MM' else f"{y_val:.1f}")
            self.keepout_z_entry.setText(f"{z_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{z_val:.3f}" if self.gui.current_unit == 'MM' else f"{z_val:.1f}")
            
            scale_value = keepout.get('scale', 1.0)
            self.keepout_scale_slider.blockSignals(True)
            self.keepout_scale_slider.setValue(int(round(scale_value * 1000)))
            self.keepout_scale_slider.blockSignals(False)
            self.keepout_scale_entry.setText(f"{scale_value:.2f}")
            
            if self.gui.rotation_unit == 'DEG':
                rx_val = keepout['rotation'][0]
                ry_val = keepout['rotation'][1]
                rz_val = keepout['rotation'][2]
                self.keepout_rx_slider.setRange(-180000, 180000)
                self.keepout_ry_slider.setRange(-180000, 180000)
                self.keepout_rz_slider.setRange(-180000, 180000)
                self.keepout_rx_slider.setValue(int(round(rx_val*1000)))
                self.keepout_ry_slider.setValue(int(round(ry_val*1000)))
                self.keepout_rz_slider.setValue(int(round(rz_val*1000)))
                self.keepout_rx_entry.setText(f"{rx_val:.6f}")
                self.keepout_ry_entry.setText(f"{ry_val:.6f}")
                self.keepout_rz_entry.setText(f"{rz_val:.6f}")
            else:
                rx_rad = np.radians(keepout['rotation'][0])
                ry_rad = np.radians(keepout['rotation'][1])
                rz_rad = np.radians(keepout['rotation'][2])
                self.keepout_rx_slider.setRange(int(round(-np.pi*1000000)), int(round(np.pi*1000000)))
                self.keepout_ry_slider.setRange(int(round(-np.pi*1000000)), int(round(np.pi*1000000)))
                self.keepout_rz_slider.setRange(int(round(-np.pi*1000000)), int(round(np.pi*1000000)))
                self.keepout_rx_slider.setValue(int(round(rx_rad * 1000000)))
                self.keepout_ry_slider.setValue(int(round(ry_rad * 1000000)))
                self.keepout_rz_slider.setValue(int(round(rz_rad * 1000000)))
                self.keepout_rx_entry.setText(f"{rx_rad:.6f}")
                self.keepout_ry_entry.setText(f"{ry_rad:.6f}")
                self.keepout_rz_entry.setText(f"{rz_rad:.6f}")
            
            if keepout['type'] == 'shape':
                self.keepout_length.setVisible(True)
                self.keepout_width.setVisible(True)
                self.keepout_height.setVisible(True)
                length = self.helpers.convert_from_cm(keepout['dimensions'][0], self.gui.current_unit)
                width = self.helpers.convert_from_cm(keepout['dimensions'][1], self.gui.current_unit)
                height = self.helpers.convert_from_cm(keepout['dimensions'][2], self.gui.current_unit)
                self.keepout_length.blockSignals(True)
                self.keepout_width.blockSignals(True)
                self.keepout_height.blockSignals(True)
                self.keepout_length.setValue(length)
                self.keepout_width.setValue(width)
                self.keepout_height.setValue(height)
                self.keepout_length.blockSignals(False)
                self.keepout_width.blockSignals(False)
                self.keepout_height.blockSignals(False)
            else:
                self.keepout_length.setVisible(False)
                self.keepout_width.setVisible(False)
                self.keepout_height.setVisible(False)

    def update_keepout_x_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed():
            value = np.round(value/scaling_factor)*scaling_factor
        if self.selected_index >= 0:
            if not self.keepout_x_slider.signalsBlocked():
                self.keepout_zones[self.selected_index]['translation'][0] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                self.keepout_x_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}")
            self.gui.stl_viewer.update()

    def update_keepout_y_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed():
            value = np.round(value/scaling_factor)*scaling_factor
        if self.selected_index >= 0:
            if not self.keepout_y_slider.signalsBlocked():
                self.keepout_zones[self.selected_index]['translation'][1] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                self.keepout_y_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}")
                self.gui.stl_viewer.update()

    def update_keepout_z_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed():
            value = np.round(value/scaling_factor)*scaling_factor
        if self.selected_index >= 0:
            if not self.keepout_z_slider.signalsBlocked():
                self.keepout_zones[self.selected_index]['translation'][2] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                self.keepout_z_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}")
                self.gui.stl_viewer.update()

    def update_keepout_x_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.keepout_x_entry.text())
            self.keepout_zones[self.selected_index]['translation'][0] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.keepout_x_slider.blockSignals(True)
            self.keepout_x_slider.setValue(int(round(max(self.keepout_x_slider.minimum(), min(self.keepout_x_slider.maximum(), value*scaling_factor)))))
            self.keepout_x_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Keepout X translation")

    def update_keepout_y_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.keepout_y_entry.text())
            self.keepout_zones[self.selected_index]['translation'][1] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.keepout_y_slider.blockSignals(True)
            self.keepout_y_slider.setValue(int(round(max(self.keepout_y_slider.minimum(), min(self.keepout_y_slider.maximum(), value*scaling_factor)))))
            self.keepout_y_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Keepout Y translation")

    def update_keepout_z_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.keepout_z_entry.text())
            self.keepout_zones[self.selected_index]['translation'][2] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.keepout_z_slider.blockSignals(True)
            self.keepout_z_slider.setValue(int(round(max(self.keepout_z_slider.minimum(), min(self.keepout_z_slider.maximum(), value*scaling_factor)))))
            self.keepout_z_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Keepout Z translation")

    def update_keepout_rx_rotation(self, value):
        if self.gui.is_mouse_pressed():
            value = np.round(value/1000.0)*1000.0
        if self.selected_index >= 0:
            if self.gui.rotation_unit == 'DEG':
                self.update_keepout_rotation('x', value/1000.0)
                self.keepout_rx_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_keepout_rotation('x', np.degrees(value / 1000000.0))
                self.keepout_rx_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_keepout_ry_rotation(self, value):
        if self.gui.is_mouse_pressed():
            value = np.round(value/1000.0)*1000.0
        if self.selected_index >= 0:
            if self.gui.rotation_unit == 'DEG':
                self.update_keepout_rotation('y', value/1000.0)
                self.keepout_ry_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_keepout_rotation('y', np.degrees(value / 1000000.0))
                self.keepout_ry_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_keepout_rz_rotation(self, value):
        if self.gui.is_mouse_pressed():
            value = np.round(value/1000.0)*1000.0
        if self.selected_index >= 0:
            if self.gui.rotation_unit == 'DEG':
                self.update_keepout_rotation('z', value/1000.0)
                self.keepout_rz_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_keepout_rotation('z', np.degrees(value / 1000000.0))
                self.keepout_rz_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_keepout_rx_rotation_from_entry(self):
        try:
            value = float(self.keepout_rx_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_keepout_rotation('x', value)
                self.keepout_rx_slider.blockSignals(True)
                clamped_value = max(self.keepout_rx_slider.minimum(), min(self.keepout_rx_slider.maximum(), value*1000))
                self.keepout_rx_slider.setValue(int(round(clamped_value)))
                self.keepout_rx_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_keepout_rotation('x', deg_value)
                self.keepout_rx_slider.blockSignals(True)
                clamped_value = max(self.keepout_rx_slider.minimum(), min(self.keepout_rx_slider.maximum(), value*1000000))
                self.keepout_rx_slider.setValue(int(round(clamped_value)))
                self.keepout_rx_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Keepout X rotation")

    def update_keepout_ry_rotation_from_entry(self):
        try:
            value = float(self.keepout_ry_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_keepout_rotation('y', value)
                self.keepout_ry_slider.blockSignals(True)
                clamped_value = max(self.keepout_ry_slider.minimum(), min(self.keepout_ry_slider.maximum(), value*1000))
                self.keepout_ry_slider.setValue(int(round(clamped_value)))
                self.keepout_ry_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_keepout_rotation('y', deg_value)
                self.keepout_ry_slider.blockSignals(True)
                clamped_value = max(self.keepout_ry_slider.minimum(), min(self.keepout_ry_slider.maximum(), value*1000000))
                self.keepout_ry_slider.setValue(int(round(clamped_value)))
                self.keepout_ry_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Keepout Y rotation")

    def update_keepout_rz_rotation_from_entry(self):
        try:
            value = float(self.keepout_rz_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_keepout_rotation('z', value)
                self.keepout_rz_slider.blockSignals(True)
                clamped_value = max(self.keepout_rz_slider.minimum(), min(self.keepout_rz_slider.maximum(), value*1000))
                self.keepout_rz_slider.setValue(int(round(clamped_value)))
                self.keepout_rz_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_keepout_rotation('z', deg_value)
                self.keepout_rz_slider.blockSignals(True)
                clamped_value = max(self.keepout_rz_slider.minimum(), min(self.keepout_rz_slider.maximum(), value*1000000))
                self.keepout_rz_slider.setValue(int(round(clamped_value)))
                self.keepout_rz_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Keepout Z rotation")

    def update_keepout_rotation(self, axis, value):
        if self.selected_index >= 0 and self.keepout_zones:
            keepout = self.keepout_zones[self.selected_index]
            if axis == 'x':
                current_value = keepout['rotation'][0]
                keepout['rotation'][0] = value
            elif axis == 'y':
                current_value = keepout['rotation'][1]
                keepout['rotation'][1] = value
            elif axis == 'z':
                current_value = keepout['rotation'][2]
                keepout['rotation'][2] = value
            else:
                return
            
            delta_value = value - current_value
            if axis == 'x':
                delta_quat = self.helpers.quaternion_from_euler(delta_value, 0, 0)
            elif axis == 'y':
                delta_quat = self.helpers.quaternion_from_euler(0, delta_value, 0)
            elif axis == 'z':
                delta_quat = self.helpers.quaternion_from_euler(0, 0, delta_value)
            
            current_quat = keepout['quaternion']
            keepout['quaternion'] = self.quaternion_multiply(current_quat, delta_quat)
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def update_keepout_scale(self, value):
        if self.selected_index >= 0:
            scale_value = value / 1000.0  # Assuming value is from slider scaled by 1000
            self.keepout_zones[self.selected_index]['scale'] = scale_value
            self.keepout_scale_entry.setText(f"{scale_value:.2f}")
            if self.keepout_zones[self.selected_index]['type'] == 'shape':
                dimensions = self.keepout_zones[self.selected_index]['dimensions']  # Use base dimensions
                if 'wireframe_list' in self.keepout_zones[self.selected_index]:
                    glDeleteLists(self.keepout_zones[self.selected_index]['wireframe_list'], 1)
                self.keepout_zones[self.selected_index]['wireframe_list'] = self.create_keepout_shape_wireframe(*dimensions)  # Pass base dimensions
                # Update text fields with new scaled dimensions
                scaled_dimensions = [dim * scale_value for dim in dimensions]
                length = self.helpers.convert_from_cm(scaled_dimensions[0], self.gui.current_unit)
                width = self.helpers.convert_from_cm(scaled_dimensions[1], self.gui.current_unit)
                height = self.helpers.convert_from_cm(scaled_dimensions[2], self.gui.current_unit)
                self.keepout_length.blockSignals(True)
                self.keepout_width.blockSignals(True)
                self.keepout_height.blockSignals(True)
                self.keepout_length.setValue(length)
                self.keepout_width.setValue(width)
                self.keepout_height.setValue(height)
                self.keepout_length.blockSignals(False)
                self.keepout_width.blockSignals(False)
                self.keepout_height.blockSignals(False)
                self.update_keepout_dimensions_display(self.gui.current_unit)  # Ensure dimensions are fully updated
            self.gui.stl_viewer.update()

    def update_keepout_scale_from_entry(self):
        try:
            value = float(self.keepout_scale_entry.text())
            if 0.1 <= value <= 5.0:
                self.keepout_zones[self.selected_index]['scale'] = value
                self.keepout_scale_slider.blockSignals(True)
                self.keepout_scale_slider.setValue(int(round(value * 1000)))
                self.keepout_scale_slider.blockSignals(False)
                if self.keepout_zones[self.selected_index]['type'] == 'shape':
                    dimensions = self.keepout_zones[self.selected_index]['dimensions']  # Use base dimensions
                    if 'wireframe_list' in self.keepout_zones[self.selected_index]:
                        glDeleteLists(self.keepout_zones[self.selected_index]['wireframe_list'], 1)
                    self.keepout_zones[self.selected_index]['wireframe_list'] = self.create_keepout_shape_wireframe(*dimensions)  # Pass base dimensions
                    scaled_dimensions = [dim * value for dim in dimensions]
                    length = self.helpers.convert_from_cm(scaled_dimensions[0], self.gui.current_unit)
                    width = self.helpers.convert_from_cm(scaled_dimensions[1], self.gui.current_unit)
                    height = self.helpers.convert_from_cm(scaled_dimensions[2], self.gui.current_unit)
                    self.keepout_length.blockSignals(True)
                    self.keepout_width.blockSignals(True)
                    self.keepout_height.blockSignals(True)
                    self.keepout_length.setValue(length)
                    self.keepout_width.setValue(width)
                    self.keepout_height.setValue(height)
                    self.keepout_length.blockSignals(False)
                    self.keepout_width.blockSignals(False)
                    self.keepout_height.blockSignals(False)
                    self.update_keepout_dimensions_display(self.gui.current_unit)  # Ensure dimensions are fully updated
                self.gui.stl_viewer.update()
            else:
                print("Scale value must be between 0.1 and 5.0")
        except ValueError:
            print("Invalid input for keepout scale")

    def update_keepout_dimensions(self):
        if self.selected_index >= 0 and self.keepout_zones[self.selected_index]['type'] == 'shape':
            length = self.helpers.convert_to_cm(self.keepout_length.value(), self.gui.current_unit)
            width = self.helpers.convert_to_cm(self.keepout_width.value(), self.gui.current_unit)
            height = self.helpers.convert_to_cm(self.keepout_height.value(), self.gui.current_unit)
            self.keepout_zones[self.selected_index]['dimensions'] = [length, width, height]
            scale = self.keepout_zones[self.selected_index]['scale']
            scaled_dimensions = [dim * scale for dim in [length, width, height]]
            if 'wireframe_list' in self.keepout_zones[self.selected_index]:
                glDeleteLists(self.keepout_zones[self.selected_index]['wireframe_list'], 1)
            self.keepout_zones[self.selected_index]['wireframe_list'] = self.create_keepout_shape_wireframe(*scaled_dimensions)
            self.gui.stl_viewer.update()

    def update_keepout_dimensions_display(self, unit):
        if self.selected_index >= 0 and self.keepout_zones[self.selected_index]['type'] == 'shape':
            keepout = self.keepout_zones[self.selected_index]
            scale = keepout.get('scale', 1.0)  # Ensure scale is applied
            scaled_dimensions = [dim * scale for dim in keepout['dimensions']]  # Scale dimensions first
            length = self.helpers.convert_from_cm(scaled_dimensions[0], unit)
            width = self.helpers.convert_from_cm(scaled_dimensions[1], unit)
            height = self.helpers.convert_from_cm(scaled_dimensions[2], unit)
            precision = 1 if unit == 'MIL' else 4 if unit in ['IN', 'CM'] else 3 if unit == 'MM' else 2
            suffix = self.gui.get_unit_suffix(unit)
            self.keepout_length.setDecimals(precision)
            self.keepout_width.setDecimals(precision)
            self.keepout_height.setDecimals(precision)
            self.keepout_length.setSuffix(suffix)
            self.keepout_width.setSuffix(suffix)
            self.keepout_height.setSuffix(suffix)
            self.keepout_length.blockSignals(True)
            self.keepout_width.blockSignals(True)
            self.keepout_height.blockSignals(True)
            self.keepout_length.setValue(length)
            self.keepout_width.setValue(width)
            self.keepout_height.setValue(height)
            self.keepout_length.blockSignals(False)
            self.keepout_width.blockSignals(False)
            self.keepout_height.blockSignals(False)

    def change_keepout_rotation_type(self, mode):
        if self.selected_index >= 0 and self.keepout_zones:
            keepout = self.keepout_zones[self.selected_index]
            if mode == 'Euler':
                # Convert current quaternion to Euler and update sliders
                keepout['rotation'] = self.helpers.euler_from_quaternion(keepout['quaternion'])
                self.update_keepout_sliders()
            elif mode == 'Quaternion':
                # Convert current Euler angles to quaternion to maintain orientation
                keepout['quaternion'] = self.helpers.quaternion_from_euler(keepout['rotation'][0], keepout['rotation'][1], keepout['rotation'][2])
            self.gui.stl_viewer.update()

    def get_transformed_keepout_mesh(self, keepout):
        keepout_mesh = None
        if keepout['type'] == 'stl':
            keepout_model = keepout['model']
            keepout_vertices = keepout_model.vectors.reshape(-1, 3)
            keepout_faces = np.arange(len(keepout_model.vectors) * 3).reshape(len(keepout_model.vectors), 3)
            keepout_mesh = trimesh.Trimesh(vertices=keepout_vertices, faces=keepout_faces, process=True)
            if not keepout_mesh.is_watertight:
                keepout_mesh.fill_holes()
            centroid = keepout['centroid']
            full_transform = np.eye(4)
            centroid_matrix = np.eye(4)
            centroid_matrix[:3, 3] = centroid
            full_transform = np.dot(full_transform, centroid_matrix)
            translation_matrix = np.eye(4)
            translation_matrix[:3, 3] = keepout['translation']
            full_transform = np.dot(full_transform, translation_matrix)
            rotation_type = self.rotation_type_combo.currentText()
            if rotation_type == 'Euler':
                angles = keepout['rotation']
                rotation_matrix = R.from_euler('xyz', angles, degrees=True).as_matrix()
            else:
                q = keepout['quaternion']
                rotation = R.from_quat(q, scalar_first=True)
                rotation_matrix = rotation.as_matrix()
            rotation_matrix_4x4 = np.eye(4)
            rotation_matrix_4x4[:3, :3] = rotation_matrix
            full_transform = np.dot(full_transform, rotation_matrix_4x4)
            inv_centroid_matrix = np.eye(4)
            inv_centroid_matrix[:3, 3] = -centroid
            full_transform = np.dot(full_transform, inv_centroid_matrix)
            if 'scale' in keepout:
                scale_matrix = np.eye(4)
                scale_matrix[0, 0] = keepout['scale']
                scale_matrix[1, 1] = keepout['scale']
                scale_matrix[2, 2] = keepout['scale']
                full_transform = np.dot(full_transform, scale_matrix)
            keepout_mesh.apply_transform(full_transform)
        elif keepout.get('type') == 'shape':
            dimensions = keepout['dimensions']
            keepout_mesh = trimesh.creation.box(extents=dimensions)
            full_transform = np.eye(4)
            if 'scale' in keepout:
                scale_matrix = np.eye(4)
                scale_matrix[0, 0] = keepout['scale']
                scale_matrix[1, 1] = keepout['scale']
                scale_matrix[2, 2] = keepout['scale']
                full_transform = np.dot(full_transform, scale_matrix)
            translation_matrix = np.eye(4)
            translation_matrix[:3, 3] = keepout['translation']
            full_transform = np.dot(full_transform, translation_matrix)
            rotation_type = self.cnc_properties_handler.rotation_type_combo.currentText()
            if rotation_type == 'Euler':
                angles = keepout['rotation']
                if self.gui.rotation_unit == 'RAD':
                    angles = np.degrees(angles)
                rotation_matrix = R.from_euler('xyz', angles, degrees=True).as_matrix()
            else:
                q = keepout['quaternion']
                rotation_matrix = R.from_quat(q, scalar_first=True).as_matrix()
                
            rotation_matrix_4x4 = np.eye(4)
            rotation_matrix_4x4[:3, :3] = rotation_matrix
            full_transform = np.dot(full_transform, rotation_matrix_4x4)
            keepout_mesh.apply_transform(full_transform)
        return keepout_mesh, full_transform