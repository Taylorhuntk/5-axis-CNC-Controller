# File: stl_handler.py
from PyQt5.QtWidgets import QFileDialog
from stl import mesh
import trimesh
import copy
import numpy as np
from scipy.spatial.transform import Rotation as R
from opengl_utils import create_stl_display_lists
from PyQt5.QtWidgets import QHBoxLayout, QVBoxLayout, QLabel, QSlider, QLineEdit
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QComboBox

class STLHandler:
    def __init__(self, gui):
        self.gui = gui
        self.stl_models = []
        self.selected_index = -1
        self.render_modes = []
        self.helpers = gui.helpers  # Assuming helpers is an instance of the Helpers class

    def load_stl(self):
        file_name, _ = QFileDialog.getOpenFileName(self.gui, "Open STL File", "", "STL Files (*.stl)")
        if file_name:
            try:
                stl_model = mesh.Mesh.from_file(file_name)
                if len(stl_model.vectors) == 0:
                    raise ValueError("Loaded STL file has no vectors (empty mesh).")
                print(f"Loaded STL file: {file_name} with {len(stl_model.vectors)} vectors")  # Debug: Verify loading
                
                
                display_list, wireframe_list = create_stl_display_lists(stl_model)
                stl_vertices = stl_model.vectors.reshape(-1, 3)
                stl_faces = np.arange(len(stl_model.vectors) * 3).reshape(len(stl_model.vectors), 3)
                stl_mesh = trimesh.Trimesh(vertices=stl_vertices, faces=stl_faces, process=True)
                centroid = stl_mesh.centroid
                translation = -centroid.copy()
                self.stl_models.append({
                    'type': 'stl',
                    'mesh': stl_mesh.copy(),
                    'model': stl_model,
                    'name' : [file_name.split('/')[-1]],  # Store the file name for display
                    'translation': translation.copy(),
                    'rotation': [0.0, 0.0, 0.0],  # Euler angles for UI display
                    'quaternion': [1.0, 0.0, 0.0, 0.0],  # Identity quaternion (no rotation)
                    'file_name': file_name,
                    'centroid': centroid.copy(),
                    'display_list': display_list,
                    'wireframe_list': wireframe_list,
                    'scale': 1.0,  # Initialize scale to 1.0
                    'unit': 'CM',  # Default unit to MM
                })
                self.render_modes.append('solid')  # Initialize as solid to match UI default
                self.gui.stl_list.addItem(file_name.split('/')[-1])
                self.gui.stl_list.setCurrentRow(len(self.stl_models) - 1)
                self.selected_index = len(self.stl_models) - 1
                self.snap_to_build_plate()
                self.gui.file_info.append(f"Loaded: {file_name}\nVertices: {len(stl_model.vectors)}\nTriangles: {len(stl_model.vectors) // 3}")
                self.gui.center_view()  # Automatically center the view on the loaded STL
                self.gui.stl_viewer.update()
            except Exception as e:
                print(f"Error loading STL file: {e}")  # Debug: Log loading errors

    def select_stl(self, item):
        current_row = self.gui.stl_list.row(item)
        if self.selected_index == current_row:
            # Deselect if the clicked item is already selected
            self.selected_index = -1
            self.gui.last_selected_stl_index = -1
            self.gui.stl_list.clearSelection()
            # Deselect any selected keepout when an STL is deselected
            self.gui.stl_viewer.update()
        else:
            # Select the new item
            self.selected_index = current_row
            # Store the last selected STL index
            self.gui.last_selected_stl_index = self.selected_index
            # Deselect any selected keepout when an STL is selected
            self.gui.cnc_properties_handler.selected_index = -1
            self.gui.keepout_list.clearSelection()
            self.update_sliders()
            current_mode = self.render_modes[self.selected_index]
            if current_mode == "wireframe":
                self.gui.stl_wireframe_button.setChecked(True)
            else:
                self.gui.stl_solid_button.setChecked(True)
                # Update the unit selector to reflect the selected STL's unit
            current_unit = self.stl_models[self.selected_index].get('unit', 'MM')
            self.gui.stl_unit_combo.setCurrentText(current_unit)
            self.gui.center_view()  # Automatically center the view on the selected STL
            self.gui.stl_viewer.update()

    def delete_selected_object(self):
        if self.selected_index >= 0:
            from OpenGL.GL import glDeleteLists
            stl = self.stl_models[self.selected_index]
            glDeleteLists(stl['display_list'], 1)
            glDeleteLists(stl['wireframe_list'], 1)
            del self.stl_models[self.selected_index]
            self.gui.stl_list.takeItem(self.selected_index)
            self.selected_index = -1
            self.gui.file_info.clear()
            self.gui.stl_viewer.update()

    def change_render_mode(self, checked):
        if self.selected_index >= 0:
            self.render_modes[self.selected_index] = "wireframe" if self.gui.stl_wireframe_button.isChecked() else "solid"
            self.gui.stl_viewer.update()

    def snap_to_build_plate(self, second_pass=False):
        if self.selected_index >= 0:
            stl = self.stl_models[self.selected_index]
            if self.rotation_type_combo.currentText() == 'Euler':
                stl['quaternion'] = self.helpers.quaternion_from_euler(stl['rotation'][0], stl['rotation'][1], stl['rotation'][2])
            stl_mesh = self.get_transformed_stl_mesh(stl)[0]
            lowest_z = np.min([v[2] for v in stl_mesh.vertices])
            # Adjust the translation so that the lowest point is at z=build_z_offset (build_offsets are in CM)
            stl['translation'][2] = stl['translation'][2]-lowest_z + self.gui.cnc_properties_handler.build_offsets[2]
            #make sure the quaternion angle is up to date
            
            self.gui.update_sliders()
            self.gui.stl_viewer.update()
            
            #if not second_pass:
                #self.snap_to_build_plate(second_pass=True)

    def zero_stl_position(self):
        if self.selected_index >= 0:
            self.stl_models[self.selected_index]['translation'] = [0.0, 0.0, 0.0]
            self.gui.update_sliders()
            self.gui.stl_viewer.update()

    def align_stl_axes(self):
        if self.selected_index >= 0:
            self.stl_models[self.selected_index]['rotation'] = [0.0, 0.0, 0.0]
            self.stl_models[self.selected_index]['quaternion'] = [1.0, 0.0, 0.0, 0.0]  # Identity quaternion (no rotation)
            self.gui.update_sliders()
            self.gui.stl_viewer.update()

    def update_stl_rotation(self, axis, value):
        """Update rotation around a specific local axis using incremental rotation."""
        if self.selected_index >= 0 and self.stl_models:
            stl = self.stl_models[self.selected_index]
            # Get the current Euler angle for the specified axis without wrapping
            if axis == 'x':
                current_value = stl['rotation'][0]
                stl['rotation'][0] = value
            elif axis == 'y':
                current_value = stl['rotation'][1]
                stl['rotation'][1] = value
            elif axis == 'z':
                current_value = stl['rotation'][2]
                stl['rotation'][2] = value
            else:
                return
            
            # Calculate the delta rotation (difference between new and old value)
            delta_value = value - current_value
            
            # Create a quaternion for the delta rotation around the specified local axis
            if axis == 'x':
                delta_quat = self.helpers.quaternion_from_euler(delta_value, 0, 0)
            elif axis == 'y':
                delta_quat = self.helpers.quaternion_from_euler(0, delta_value, 0)
            elif axis == 'z':
                delta_quat = self.helpers.quaternion_from_euler(0, 0, delta_value)
            
            # Get the current quaternion
            current_quat = stl['quaternion']
            
            # Apply the delta rotation to the current quaternion (local axis rotation)
            stl['quaternion'] = self.helpers.quaternion_multiply(current_quat, delta_quat)
            
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def add_sliders(self, layout):
        slider_layout = QHBoxLayout()
        layout.addLayout(slider_layout)
        
        translation_layout = QVBoxLayout()
        slider_layout.addLayout(translation_layout)
        translation_label = QLabel('Translation')
        translation_label.setAlignment(Qt.AlignCenter)
        translation_layout.addWidget(translation_label)
        translation_sliders_layout = QHBoxLayout()
        translation_layout.addLayout(translation_sliders_layout)
        
        x_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(x_translation_layout)
        self.gui.x_slider = QSlider(Qt.Vertical)
        self.gui.x_slider.setRange(-150000, 150000)
        self.gui.x_slider.valueChanged.connect(self.update_x_translation)
        x_translation_layout.addWidget(QLabel('X'))
        x_translation_layout.addWidget(self.gui.x_slider)
        self.gui.x_entry = QLineEdit()
        self.gui.x_entry.setFixedWidth(100)
        self.gui.x_entry.setPlaceholderText('0.0')
        self.gui.x_entry.setAlignment(Qt.AlignCenter)
        self.gui.x_entry.returnPressed.connect(self.update_x_translation_from_entry)
        x_translation_layout.addWidget(self.gui.x_entry)
        
        y_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(y_translation_layout)
        self.gui.y_slider = QSlider(Qt.Vertical)
        self.gui.y_slider.setRange(-300000, 300000)
        self.gui.y_slider.valueChanged.connect(self.update_y_translation)
        y_translation_layout.addWidget(QLabel('Y'))
        y_translation_layout.addWidget(self.gui.y_slider)
        self.gui.y_entry = QLineEdit()
        self.gui.y_entry.setFixedWidth(100)
        self.gui.y_entry.setPlaceholderText('0.0')
        self.gui.y_entry.setAlignment(Qt.AlignCenter)
        self.gui.y_entry.returnPressed.connect(self.update_y_translation_from_entry)
        y_translation_layout.addWidget(self.gui.y_entry)
        
        z_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(z_translation_layout)
        self.gui.z_slider = QSlider(Qt.Vertical)
        self.gui.z_slider.setRange(-200000, 200000)
        self.gui.z_slider.valueChanged.connect(self.update_z_translation)
        z_translation_layout.addWidget(QLabel('Z'))
        z_translation_layout.addWidget(self.gui.z_slider)
        self.gui.z_entry = QLineEdit()
        self.gui.z_entry.setFixedWidth(100)
        self.gui.z_entry.setPlaceholderText('0.0')
        self.gui.z_entry.setAlignment(Qt.AlignCenter)
        self.gui.z_entry.returnPressed.connect(self.update_z_translation_from_entry)
        z_translation_layout.addWidget(self.gui.z_entry)
        
        scale_layout = QVBoxLayout()
        slider_layout.addLayout(scale_layout)
        scale_label = QLabel('Scale')
        scale_label.setAlignment(Qt.AlignCenter)
        scale_layout.addWidget(scale_label)
        self.gui.scale_slider = QSlider(Qt.Vertical)
        self.gui.scale_slider.setRange(10, 100000)  # 0.1 to 5.0 scaled by 1000
        self.gui.scale_slider.setValue(1000)  # Default scale 1.0
        self.gui.scale_slider.valueChanged.connect(self.update_scale)
        scale_layout.addWidget(self.gui.scale_slider)
        self.gui.scale_entry = QLineEdit()
        self.gui.scale_entry.setFixedWidth(100)
        self.gui.scale_entry.setPlaceholderText('1.0')
        self.gui.scale_entry.setAlignment(Qt.AlignCenter)
        self.gui.scale_entry.returnPressed.connect(self.update_scale_from_entry)
        scale_layout.addWidget(self.gui.scale_entry)
        
        rotation_layout = QVBoxLayout()
        slider_layout.addLayout(rotation_layout)
        rotation_label = QLabel('Rotation')
        rotation_label.setAlignment(Qt.AlignCenter)
        rotation_layout.addWidget(rotation_label)
        
        self.rotation_type_combo = QComboBox()
        self.rotation_type_combo.addItems(['Euler', 'Quaternion'])
        self.rotation_type_combo.currentTextChanged.connect(self.change_rotation_type)
        rotation_layout.addWidget(self.rotation_type_combo)
        
        rotation_sliders_layout = QHBoxLayout()
        rotation_layout.addLayout(rotation_sliders_layout)
        
        x_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(x_rotation_layout)
        self.gui.rx_slider = QSlider(Qt.Vertical)
        self.gui.rx_slider.setRange(-180000, 180000)
        self.gui.rx_slider.valueChanged.connect(self.update_rx_rotation)
        x_rotation_layout.addWidget(QLabel('X'))
        x_rotation_layout.addWidget(self.gui.rx_slider)
        self.gui.rx_entry = QLineEdit()
        self.gui.rx_entry.setFixedWidth(100)
        self.gui.rx_entry.setPlaceholderText('0.0')
        self.gui.rx_entry.setAlignment(Qt.AlignCenter)
        self.gui.rx_entry.returnPressed.connect(self.update_rx_rotation_from_entry)
        x_rotation_layout.addWidget(self.gui.rx_entry)
        
        y_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(y_rotation_layout)
        self.gui.ry_slider = QSlider(Qt.Vertical)
        self.gui.ry_slider.setRange(-180000, 180000)
        self.gui.ry_slider.valueChanged.connect(self.update_ry_rotation)
        y_rotation_layout.addWidget(QLabel('Y'))
        y_rotation_layout.addWidget(self.gui.ry_slider)
        self.gui.ry_entry = QLineEdit()
        self.gui.ry_entry.setFixedWidth(100)
        self.gui.ry_entry.setPlaceholderText('0.0')
        self.gui.ry_entry.setAlignment(Qt.AlignCenter)
        self.gui.ry_entry.returnPressed.connect(self.update_ry_rotation_from_entry)
        y_rotation_layout.addWidget(self.gui.ry_entry)
        
        z_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(z_rotation_layout)
        self.gui.rz_slider = QSlider(Qt.Vertical)
        self.gui.rz_slider.setRange(-180000, 180000)
        self.gui.rz_slider.valueChanged.connect(self.update_rz_rotation)
        z_rotation_layout.addWidget(QLabel('Z'))
        z_rotation_layout.addWidget(self.gui.rz_slider)
        self.gui.rz_entry = QLineEdit()
        self.gui.rz_entry.setFixedWidth(100)
        self.gui.rz_entry.setPlaceholderText('0.0')
        self.gui.rz_entry.setAlignment(Qt.AlignCenter)
        self.gui.rz_entry.returnPressed.connect(self.update_rz_rotation_from_entry)
        z_rotation_layout.addWidget(self.gui.rz_entry)

    def update_sliders(self):
        if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM':
            scaling_factor = 10000
        elif self.gui.current_unit == 'MM':
            scaling_factor = 1000
        elif self.gui.current_unit == 'MIL':
            scaling_factor = 10
        if self.selected_index >= 0:
            stl = self.stl_models[self.selected_index]
            x_val = self.helpers.convert_from_cm(stl['translation'][0], self.gui.current_unit)
            y_val = self.helpers.convert_from_cm(stl['translation'][1], self.gui.current_unit)
            z_val = self.helpers.convert_from_cm(stl['translation'][2], self.gui.current_unit)
            self.gui.x_slider.blockSignals(True)
            self.gui.y_slider.blockSignals(True)
            self.gui.z_slider.blockSignals(True)
            clamped_x = max(self.gui.x_slider.minimum(), min(self.gui.x_slider.maximum(), x_val*scaling_factor))
            clamped_y = max(self.gui.y_slider.minimum(), min(self.gui.y_slider.maximum(), y_val*scaling_factor))
            clamped_z = max(self.gui.z_slider.minimum(), min(self.gui.z_slider.maximum(), z_val*scaling_factor))
            self.gui.x_slider.setValue(int(round(clamped_x)))
            self.gui.y_slider.setValue(int(round(clamped_y)))
            self.gui.z_slider.setValue(int(round(clamped_z)))
            self.gui.x_slider.blockSignals(False)
            self.gui.y_slider.blockSignals(False)
            self.gui.z_slider.blockSignals(False)
            self.gui.x_entry.setText(f"{x_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{x_val:.3f}" if self.gui.current_unit == 'MM' else f"{x_val:.0f}")
            self.gui.y_entry.setText(f"{y_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{y_val:.3f}" if self.gui.current_unit == 'MM' else f"{y_val:.0f}")
            self.gui.z_entry.setText(f"{z_val:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{z_val:.3f}" if self.gui.current_unit == 'MM' else f"{z_val:.0f}")
            
            # Update scale slider
            scale_value = stl.get('scale', 1.0)  # Default to 1.0 if not set
            self.gui.scale_slider.blockSignals(True)
            self.gui.scale_slider.setValue(int(round(scale_value * 1000)))  # Scale to slider range
            self.gui.scale_slider.blockSignals(False)
            self.gui.scale_entry.setText(f"{scale_value:.2f}")
            
            if self.gui.rotation_unit == 'DEG':
                if 'quaternion' in stl:
                    stl['rotation'] = self.helpers.euler_from_quaternion(stl['quaternion'])
                rx_deg = stl['rotation'][0]
                ry_deg = stl['rotation'][1]
                rz_deg = stl['rotation'][2]
                self.gui.rx_slider.setRange(-180000, 180000)
                self.gui.ry_slider.setRange(-180000, 180000)
                self.gui.rz_slider.setRange(-180000, 180000)
                self.gui.rx_slider.setValue(int(round(rx_deg*1000)))
                self.gui.ry_slider.setValue(int(round(ry_deg*1000)))
                self.gui.rz_slider.setValue(int(round(rz_deg*1000)))
                self.gui.rx_entry.setText(f"{rx_deg:.6f}")
                self.gui.ry_entry.setText(f"{ry_deg:.6f}")
                self.gui.rz_entry.setText(f"{rz_deg:.6f}")
            else:
                if 'quaternion' in stl:
                    stl['rotation'] = self.helpers.euler_from_quaternion(stl['quaternion'])
                rx_rad = np.radians(stl['rotation'][0])
                ry_rad = np.radians(stl['rotation'][1])
                rz_rad = np.radians(stl['rotation'][2])
                self.gui.rx_slider.setRange(int(round(-np.pi*1000000)), int(round(np.pi*1000000)))
                self.gui.ry_slider.setRange(int(round(-np.pi*1000000)), int(round(np.pi*1000000)))
                self.gui.rz_slider.setRange(int(round(-np.pi*1000000)), int(round(np.pi*1000000)))
                self.gui.rx_slider.setValue(int(round(rx_rad * 1000000)))
                self.gui.ry_slider.setValue(int(round(ry_rad * 1000000)))
                self.gui.rz_slider.setValue(int(round(rz_rad * 1000000)))
                self.gui.rx_entry.setText(f"{rx_rad:.6f}")
                self.gui.ry_entry.setText(f"{ry_rad:.6f}")
                self.gui.rz_entry.setText(f"{rz_rad:.6f}")

    def update_x_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed(): value = np.round(value/scaling_factor)*scaling_factor
        if self.selected_index >= 0:
            if not self.gui.x_slider.signalsBlocked():
                self.stl_models[self.selected_index]['translation'][0] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                self.gui.x_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}") 
            self.gui.stl_viewer.update()

    def update_y_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed(): value = np.round(value/scaling_factor)*scaling_factor
        if self.selected_index >= 0:
            if not self.gui.y_slider.signalsBlocked():
                self.stl_models[self.selected_index]['translation'][1] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                self.gui.y_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}") 
                self.gui.stl_viewer.update()

    def update_z_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed(): value = np.round(value/scaling_factor)*scaling_factor
        if self.selected_index >= 0:
            if not self.gui.z_slider.signalsBlocked():
                self.stl_models[self.selected_index]['translation'][2] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                z_val = value
                self.gui.z_entry.setText(f"{value/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{value/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{value/scaling_factor:.1f}") 
                self.gui.stl_viewer.update()

    def update_x_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.gui.x_entry.text())
            self.stl_models[self.selected_index]['translation'][0] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.x_slider.blockSignals(True)
            self.gui.x_slider.setValue(int(round(max(self.gui.x_slider.minimum(), min(self.gui.x_slider.maximum(), value*scaling_factor)))))
            self.gui.x_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for X translation")

    def update_y_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.gui.y_entry.text())
            self.stl_models[self.selected_index]['translation'][1] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.y_slider.blockSignals(True)
            self.gui.y_slider.setValue(int(round(max(self.gui.y_slider.minimum(), min(self.gui.y_slider.maximum(), value*scaling_factor)))))
            self.gui.y_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Y translation")

    def update_z_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.gui.z_entry.text())
            self.stl_models[self.selected_index]['translation'][2] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.z_slider.blockSignals(True)
            self.gui.z_slider.setValue(int(round(max(self.gui.z_slider.minimum(), min(self.gui.z_slider.maximum(), value*scaling_factor)))))
            self.gui.z_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Z translation")

    def update_rx_rotation(self, value):
        if self.gui.is_mouse_pressed(): value = np.round(value/1000.0)*1000.0  # Round to nearest degree
        
        if self.selected_index >= 0:
            if self.gui.rotation_unit == 'DEG':
                self.update_stl_rotation('x', value/1000.0)
                self.gui.rx_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_stl_rotation('x', np.degrees(value / 1000000.0))
                self.gui.rx_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_ry_rotation(self, value):
        if self.gui.is_mouse_pressed(): value = np.round(value/1000.0)*1000.0  # Round to nearest degree
        if self.selected_index >= 0:
            if self.gui.rotation_unit == 'DEG':
                self.update_stl_rotation('y', value/1000.0)
                self.gui.ry_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_stl_rotation('y', np.degrees(value / 1000000.0))
                self.gui.ry_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_rz_rotation(self, value):
        if self.gui.is_mouse_pressed(): value = np.round(value/1000.0)*1000.0  # Round to nearest degree
        if self.selected_index >= 0:
            if self.gui.rotation_unit == 'DEG':
                self.update_stl_rotation('z', value/1000.0)
                self.gui.rz_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_stl_rotation('z', np.degrees(value / 1000000.0))
                self.gui.rz_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_rx_rotation_from_entry(self):
        try:
            value = float(self.gui.rx_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_stl_rotation('x', value)
                self.gui.rx_slider.blockSignals(True)
                clamped_value = max(self.gui.rx_slider.minimum(), min(self.gui.rx_slider.maximum(), value*1000))
                self.gui.rx_slider.setValue(int(round(clamped_value)))
                self.gui.rx_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_stl_rotation('x', deg_value)
                self.gui.rx_slider.blockSignals(True)
                clamped_value = max(self.gui.rx_slider.minimum(), min(self.gui.rx_slider.maximum(), value*1000000))
                self.gui.rx_slider.setValue(int(round(clamped_value)))
                self.gui.rx_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for X rotation")

    def update_ry_rotation_from_entry(self):
        try:
            value = float(self.gui.ry_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_stl_rotation('y', value)
                self.gui.ry_slider.blockSignals(True)
                clamped_value = max(self.gui.ry_slider.minimum(), min(self.gui.ry_slider.maximum(), value*1000))
                self.gui.ry_slider.setValue(int(round(clamped_value)))
                self.gui.ry_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_stl_rotation('y', deg_value)
                self.gui.ry_slider.blockSignals(True)
                clamped_value = max(self.gui.ry_slider.minimum(), min(self.gui.ry_slider.maximum(), value*1000000))
                self.gui.ry_slider.setValue(int(round(clamped_value)))
                self.gui.ry_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Y rotation")

    def update_rz_rotation_from_entry(self):
        try:
            value = float(self.gui.rz_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_stl_rotation('z', value)
                self.gui.rz_slider.blockSignals(True)
                clamped_value = max(self.gui.rz_slider.minimum(), min(self.gui.rz_slider.maximum(), value*1000))
                self.gui.rz_slider.setValue(int(round(clamped_value)))
                self.gui.rz_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_stl_rotation('z', deg_value)
                self.gui.rz_slider.blockSignals(True)
                clamped_value = max(self.gui.rz_slider.minimum(), min(self.gui.rz_slider.maximum(), value*1000000))
                self.gui.rz_slider.setValue(int(round(clamped_value)))
                self.gui.rz_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for Z rotation")

    def change_rotation_type(self, mode):
        if self.selected_index >= 0:
            stl = self.stl_models[self.selected_index]
            if mode == 'Euler':
                # Convert current quaternion to Euler and update sliders
                stl['rotation'] = self.helpers.euler_from_quaternion(stl['quaternion'])
                self.gui.update_sliders()  # Updates sliders to reflect current orientation
            elif mode == 'Quaternion':
                # Convert current Euler angles to quaternion to maintain orientation
                stl['quaternion'] = self.helpers.quaternion_from_euler(stl['rotation'][0], stl['rotation'][1], stl['rotation'][2])
            self.gui.stl_viewer.update()

    def update_scale(self, value):
        if self.selected_index >= 0:
            scale_value = value / 1000.0  # Scale from 0.1 to 5.0
            self.stl_models[self.selected_index]['scale'] = scale_value
            self.gui.scale_entry.setText(f"{scale_value:.2f}")
            self.gui.stl_viewer.update()

    def update_scale_from_entry(self):
        try:
            value = float(self.gui.scale_entry.text())
            if 0.01 <= value <= 100.0:  # Assuming scale range based on slider
                self.stl_models[self.selected_index]['scale'] = value
                self.gui.scale_slider.blockSignals(True)
                self.gui.scale_slider.setValue(int(round(value * 1000)))  # Scale back to slider range
                self.gui.scale_slider.blockSignals(False)
                self.gui.stl_viewer.update()
            else:
                print("Scale value must be between 0.1 and 20.0")
        except ValueError:
            print("Invalid input for scale")

    def get_transformed_stl_mesh(self, stl):
        stl_mesh = stl['mesh'].copy()
        
        centroid = np.array(stl['centroid'])
        full_transform = np.eye(4)
        centroid_matrix = np.eye(4)
        centroid_matrix[:3, 3] = centroid
        full_transform = np.dot(full_transform, centroid_matrix)
        translation_matrix = np.eye(4)
        translation_matrix[:3, 3] = stl['translation']
        full_transform = np.dot(full_transform, translation_matrix)
        rotation_type = self.rotation_type_combo.currentText()
        if rotation_type == 'Euler':
            angles = stl['rotation']
            if self.gui.rotation_unit == 'RAD':
                angles = np.degrees(angles)
            rotation_matrix = R.from_euler('xyz', angles, degrees=True).as_matrix()
        else:
            q = stl['quaternion']
            rotation_matrix = R.from_quat(q, scalar_first=True).as_matrix()
        rotation_matrix_4x4 = np.eye(4)
        rotation_matrix_4x4[:3, :3] = rotation_matrix
        full_transform = np.dot(full_transform, rotation_matrix_4x4)
        inv_centroid_matrix = np.eye(4)
        inv_centroid_matrix[:3, 3] = -centroid
        full_transform = np.dot(full_transform, inv_centroid_matrix)
        if 'scale' in stl:
            scale_matrix = np.eye(4)
            user_scale = stl['scale']
            scale_matrix[0, 0] = user_scale
            scale_matrix[1, 1] = user_scale
            scale_matrix[2, 2] = user_scale
            full_transform = np.dot(full_transform, scale_matrix)
        
        
        stl_mesh.apply_transform(full_transform)
        return stl_mesh.copy(), full_transform
    
    def update_stl_unit(self, unit):
        """Update the unit of the selected STL model and adjust its scale accordingly."""
        if self.selected_index >= 0:
            # Store the selected unit
            self.stl_models[self.selected_index]['unit'] = unit
            conversion_factor = self.helpers.convert_to_cm(1.0, unit)
            base_model = copy.deepcopy(self.stl_models[self.selected_index]['model'])
            base_model.vectors *= conversion_factor
            stl_vertices = base_model.vectors.reshape(-1, 3)
            stl_faces = np.arange(len(base_model.vectors) * 3).reshape(len(base_model.vectors), 3)
            stl_mesh = trimesh.Trimesh(vertices=stl_vertices, faces=stl_faces, process=True)
            centroid = stl_mesh.centroid
            display_list, wireframe_list = create_stl_display_lists(base_model)
            self.stl_models[self.selected_index]['mesh'] = stl_mesh.copy()
            self.stl_models[self.selected_index]['centroid'] =centroid.copy()
            self.stl_models[self.selected_index]['translation'] = centroid.copy()
            self.stl_models[self.selected_index]['display_list'] = display_list
            self.stl_models[self.selected_index]['wireframe_list'] = wireframe_list
            self.gui.stl_viewer.update()

