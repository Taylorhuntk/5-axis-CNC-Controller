# File: cnc_path_handler.py
class CNCPathHandler:
    def __init__(self, gui):
        self.gui = gui
        self.path_points = []  # Managed in GUI for now, can be moved here if needed

    def add_point(self, xyzab, xyz_normal):
        """Add a point to the path (used if logic moves out of GUI)."""
        self.path_points.append({'xyzab': xyzab, 'xyz_normal': xyz_normal})
        self.gui.update_path_list()

    def append_point(self, xyzab, xyz_normal):
        """Add a point to the end of the path."""
        self.path_points.append({'xyzab': xyzab, 'xyz_normal': xyz_normal})
        self.gui.update_path_list()

    def insert_point(self, index, xyzab, xyz_normal):
        """Insert a point at the specified index in the path."""
        if index >= 0:
            self.path_points.insert(index + 1, {'xyzab': xyzab, 'xyz_normal': xyz_normal})
        else:
            self.path_points.append({'xyzab': xyzab, 'xyz_normal': xyz_normal})
        self.gui.update_path_list()

    def move_point_up(self, index):
        """Move the point at the specified index up in the list."""
        if index > 0:
            self.path_points[index], self.path_points[index - 1] = self.path_points[index - 1], self.path_points[index]

    def move_point_down(self, index):
        """Move the point at the specified index down in the list."""
        if index >= 0 and index < len(self.path_points) - 1:
            self.path_points[index], self.path_points[index + 1] = self.path_points[index + 1], self.path_points[index]

    def delete_point(self, index):
        """Delete the point at the specified index."""
        if index >= 0 and index < len(self.path_points):
            self.path_points.pop(index)

    def clear_path(self):
        """Clear all points from the path."""
        self.path_points = []

    def set_path(self, path):
        """Set the path to a new list of points."""
        self.path_points = path

        