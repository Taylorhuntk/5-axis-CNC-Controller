import numpy as np

def get_rotation_matrix_ab(a_rad, b_rad, matrix):
    """A then B rotation order for CNC to Material (normal vector)."""
    cos_b = np.cos(b_rad)
    sin_b = np.sin(b_rad)
    cos_a = np.cos(a_rad)
    sin_a = np.sin(a_rad)
    matrix[0, 0] = cos_b
    matrix[0, 1] = -sin_b * cos_a
    matrix[0, 2] = sin_b * sin_a
    matrix[1, 0] = sin_b
    matrix[1, 1] = cos_b * cos_a
    matrix[1, 2] = -cos_b * sin_a
    matrix[2, 0] = 0
    matrix[2, 1] = sin_a
    matrix[2, 2] = cos_a

def get_rotation_matrix_ba(a_rad, b_rad, matrix):
    """B then A rotation order for CNC to Material (normal vector)."""
    cos_b = np.cos(b_rad)
    sin_b = np.sin(b_rad)
    cos_a = np.cos(a_rad)
    sin_a = np.sin(a_rad)
    matrix[0, 0] = cos_b
    matrix[0, 1] = -sin_b
    matrix[0, 2] = 0
    matrix[1, 0] = sin_b * cos_a
    matrix[1, 1] = cos_b * cos_a
    matrix[1, 2] = -sin_a
    matrix[2, 0] = sin_b * sin_a
    matrix[2, 1] = cos_b * sin_a
    matrix[2, 2] = cos_a

def get_inverse_rotation_matrix_ab(a_rad, b_rad, matrix):
    """Inverse of A then B for CNC to Material (coordinate transform)."""
    cos_b = np.cos(b_rad)
    sin_b = np.sin(b_rad)
    cos_a = np.cos(a_rad)
    sin_a = np.sin(a_rad)
    matrix[0, 0] = cos_b
    matrix[0, 1] = sin_b
    matrix[0, 2] = 0
    matrix[1, 0] = -sin_b * cos_a
    matrix[1, 1] = cos_b * cos_a
    matrix[1, 2] = sin_a
    matrix[2, 0] = sin_b * sin_a
    matrix[2, 1] = -cos_b * sin_a
    matrix[2, 2] = cos_a

def get_inverse_rotation_matrix_ba(a_rad, b_rad, matrix):
    """Inverse of B then A for CNC to Material (coordinate transform)."""
    cos_b = np.cos(b_rad)
    sin_b = np.sin(b_rad)
    cos_a = np.cos(a_rad)
    sin_a = np.sin(a_rad)
    matrix[0, 0] = cos_b
    matrix[0, 1] = sin_b * cos_a
    matrix[0, 2] = sin_b * sin_a
    matrix[1, 0] = -sin_b
    matrix[1, 1] = cos_b * cos_a
    matrix[1, 2] = cos_b * sin_a
    matrix[2, 0] = 0
    matrix[2, 1] = -sin_a
    matrix[2, 2] = cos_a

def get_material_to_cnc_matrix_ab(a_rad, b_rad, matrix):
    """A then B rotation order for Material to CNC."""
    cos_b = np.cos(b_rad)
    sin_b = np.sin(b_rad)
    cos_a = np.cos(a_rad)
    sin_a = np.sin(a_rad)
    matrix[0, 0] = cos_b
    matrix[0, 1] = -sin_b * cos_a
    matrix[0, 2] = sin_b * sin_a
    matrix[1, 0] = sin_b
    matrix[1, 1] = cos_b * cos_a
    matrix[1, 2] = -cos_b * sin_a
    matrix[2, 0] = 0
    matrix[2, 1] = sin_a
    matrix[2, 2] = cos_a

def get_material_to_cnc_matrix_ba(a_rad, b_rad, matrix):
    """B then A rotation order for Material to CNC."""
    cos_b = np.cos(b_rad)
    sin_b = np.sin(b_rad)
    cos_a = np.cos(a_rad)
    sin_a = np.sin(a_rad)
    matrix[0, 0] = cos_b
    matrix[0, 1] = -sin_b
    matrix[0, 2] = 0
    matrix[1, 0] = sin_b * cos_a
    matrix[1, 1] = cos_b * cos_a
    matrix[1, 2] = -sin_a
    matrix[2, 0] = sin_b * sin_a
    matrix[2, 1] = cos_b * sin_a
    matrix[2, 2] = cos_a

def get_pan_tilt_old(u_x, u_y, u_z, elbow_up, original_b_deg=None, rot_order_norm="AB"):
    """Convert unit vector to pan (A) and tilt (B) angles in radians, prioritizing original B if provided."""
    a_rad = np.acos(u_z)
    if not elbow_up:
        a_rad = -a_rad
    sin_a = np.sin(a_rad) if a_rad >= 0 else -np.sin(a_rad)
    if abs(sin_a) > 0.0001:
        b_rad = np.arctan2(u_x, u_y)
        if original_b_deg is not None:
            original_b_rad = np.radians(original_b_deg) % (2 * np.pi)
            # Start with original B angle as the default
            best_b_rad = original_b_rad
            b_candidates = [
                b_rad,
                (b_rad + np.pi) % (2 * np.pi),
                (b_rad - np.pi) % (2 * np.pi),
                (b_rad + 2 * np.pi) % (2 * np.pi),
                (b_rad - 2 * np.pi) % (2 * np.pi)
            ]
            min_error = float('inf')
            u_expected = np.array([u_x, u_y, u_z])
            # First, check if original B gives a good normal vector match
            test_matrix = np.zeros((3, 3))
            if rot_order_norm == "AB":
                get_rotation_matrix_ab(a_rad, original_b_rad, test_matrix)
            else:
                get_rotation_matrix_ba(a_rad, original_b_rad, test_matrix)
            u_test = np.dot(test_matrix, np.array([0, 0, 1]))
            vector_error = np.sum((u_test - u_expected) ** 2)
            if vector_error < 0.0001:  # If original B is a good match, use it
                b_rad = original_b_rad
            else:
                # Otherwise, find the best candidate with minimal vector error
                for cand in b_candidates:
                    test_matrix = np.zeros((3, 3))
                    if rot_order_norm == "AB":
                        get_rotation_matrix_ab(a_rad, cand, test_matrix)
                    else:
                        get_rotation_matrix_ba(a_rad, cand, test_matrix)
                    u_test = np.dot(test_matrix, np.array([0, 0, 1]))
                    vector_error = np.sum((u_test - u_expected) ** 2)
                    if vector_error < min_error:
                        min_error = vector_error
                        best_b_rad = cand
                b_rad = best_b_rad
        if b_rad < 0:
            b_rad += 2 * np.pi
    else:
        b_rad = np.radians(original_b_deg) if original_b_deg is not None else 0
    return a_rad, b_rad

def get_pan_tilt(self, u_x, u_y, u_z, elbow_up, original_b_deg=None):
    """
    Convert a unit vector (normal) to pan and tilt angles (A and B in radians).
    Adapted from firmware's getPanTilt function.
    Returns angles as a tuple (a_rad, b_rad).
    """
    a_rad = np.acos(u_z)
    if not elbow_up:
        a_rad = -a_rad  # Elbow down: negative tilt
    
    sin_a = np.sin(a_rad)  # Use absolute value since sign is handled by a
    if sin_a != 0:
        if elbow_up:
            b_rad = np.arctan2(u_x, u_y)
        else:
            b_rad = np.arctan2(-u_x, -u_y)  # Flip signs for negative a
        if b_rad < 0:
            b_rad += 2 * np.pi  # Normalize to [0, 360°]
    else:
        b_rad = 0  # Undefined when a = 0°, default to 0
    return (a_rad, b_rad)


def cnc_to_material_test(cnc_x, cnc_y, cnc_z, a_deg, b_deg, rot_order_norm, rot_order_pos):
    """Test CNC to Material conversion with separate rotation orders for normals and position."""
    a_rad = np.radians(a_deg)
    b_rad = np.radians(b_deg)
    matrix_r = np.zeros((3, 3))
    matrix_a = np.zeros((3, 3))
    
    if rot_order_norm == "AB":
        get_rotation_matrix_ab(a_rad, b_rad, matrix_r)
    else:
        get_rotation_matrix_ba(a_rad, b_rad, matrix_r)
        
    if rot_order_pos == "AB":
        get_inverse_rotation_matrix_ab(a_rad, b_rad, matrix_a)
    else:
        get_inverse_rotation_matrix_ba(a_rad, b_rad, matrix_a)
    
    u = np.array([0, 0, 1])
    rotated_unit_vector = np.dot(matrix_r, u)
    local = np.array([cnc_x, cnc_y, cnc_z])
    material = np.dot(matrix_a, local)
    
    return {
        'x': material[0], 'y': material[1], 'z': material[2],
        'u_x': rotated_unit_vector[0], 'u_y': rotated_unit_vector[1], 'u_z': rotated_unit_vector[2],
        'b': b_deg
    }

def material_to_cnc_test(mat_x, mat_y, mat_z, u_x, u_y, u_z, b_deg, elbow_up, rot_order_norm, rot_order_pos):
    """Test Material to CNC conversion with separate rotation orders for normals and position."""
    # Try both elbow_up orientations and multiple B angle candidates to find the best match for normal vector
    u_expected = np.array([u_x, u_y, u_z])
    best_a_rad = 0
    best_b_rad = 0
    best_error = float('inf')
    best_cnc = np.zeros(3)
    
    for elbow in [True, False]:
        a_rad, b_rad_initial = get_pan_tilt(u_x, u_y, u_z, elbow, original_b_deg=b_deg, rot_order_norm=rot_order_norm)
        # Test multiple B angle candidates (initial, +90, +180, +270, etc.)
        b_candidates = [
            b_rad_initial,
            (b_rad_initial + np.pi/2) % (2 * np.pi),
            (b_rad_initial + np.pi) % (2 * np.pi),
            (b_rad_initial + 3*np.pi/2) % (2 * np.pi),
            (b_rad_initial - np.pi/2) % (2 * np.pi),
            (b_rad_initial - np.pi) % (2 * np.pi),
            (b_rad_initial - 3*np.pi/2) % (2 * np.pi)
        ]
        
        for b_rad in b_candidates:
            # Reconstruct normal vector to check if it matches input
            matrix_r = np.zeros((3, 3))
            if rot_order_norm == "AB":
                get_rotation_matrix_ab(a_rad, b_rad, matrix_r)
            else:
                get_rotation_matrix_ba(a_rad, b_rad, matrix_r)
            u_reconstructed = np.dot(matrix_r, np.array([0, 0, 1]))
            error = np.sum((u_reconstructed - u_expected) ** 2)
            
            if error < best_error:
                best_error = error
                best_a_rad = a_rad
                best_b_rad = b_rad
                matrix_b = np.zeros((3, 3))
                if rot_order_pos == "AB":
                    get_material_to_cnc_matrix_ab(a_rad, b_rad, matrix_b)
                else:
                    get_material_to_cnc_matrix_ba(a_rad, b_rad, matrix_b)
                local = np.array([mat_x, mat_y, mat_z])
                best_cnc = np.dot(matrix_b, local)
    
    b_deg_normalized = np.degrees(best_b_rad) % 360
    return {
        'x': best_cnc[0], 'y': best_cnc[1], 'z': best_cnc[2],
        'a_deg': np.degrees(best_a_rad), 'b_deg': b_deg_normalized
    }

def compute_round_trip_error(original, converted_back, keys):
    """Compute error between original and converted-back values."""
    error = 0.0
    for key in keys:
        error += (original[key] - converted_back[key]) ** 2
    return np.sqrt(error)

# Expanded test cases for CNC to Material round trip
test_cases_cnc = [
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': -90.0, 'b_deg': 0.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': -90.0, 'b_deg': 45.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': -90.0, 'b_deg': 90.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': -90.0, 'b_deg': 135.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': -90.0, 'b_deg': 180.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': -68.0, 'b_deg': 0.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': -68.0, 'b_deg': 45.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': 0.0, 'b_deg': 0.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': 45.0, 'b_deg': 0.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'a_deg': 90.0, 'b_deg': 0.0}
]

# Expanded test cases for Material to CNC round trip
test_cases_mat = [
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'u_x': -1.0, 'u_y': 0.0, 'u_z': 0.0, 'b_deg': 270.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'u_x': -0.5, 'u_y': -0.5, 'u_z': 0.71, 'b_deg': 225.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'u_x': 0.5, 'u_y': 0.5, 'u_z': 0.71, 'b_deg': 45.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'u_x': 0.0, 'u_y': -1.0, 'u_z': 0.0, 'b_deg': 180.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'u_x': 0.0, 'u_y': 0.0, 'u_z': 1.0, 'b_deg': 0.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'u_x': 1.0, 'u_y': 0.0, 'u_z': 0.0, 'b_deg': 90.0},
    {'x': 0.0, 'y': -5.0, 'z': 10.0, 'u_x': 0.0, 'u_y': 1.0, 'u_z': 0.0, 'b_deg': 0.0}
]

# Test combinations with separate rotation orders for normals and position
combinations = [
    ("AB", "AB", "AB", "AB", "Combination 1: CNC->Mat Norm(A then B), Pos(A then B); Mat->CNC Norm(A then B), Pos(A then B)"),
    ("AB", "BA", "AB", "BA", "Combination 5: CNC->Mat Norm(A then B), Pos(B then A); Mat->CNC Norm(A then B), Pos(B then A)")
]

print("Testing CNC to Material Round Trip with Different Rotation Orders:")
for rot_norm_cnc, rot_pos_cnc, rot_norm_mat, rot_pos_mat, desc in combinations:
    print(f"\n{desc}")
    total_error = 0.0
    for case in test_cases_cnc:
        mat = cnc_to_material_test(case['x'], case['y'], case['z'], case['a_deg'], case['b_deg'], rot_norm_cnc, rot_pos_cnc)
        elbow_up = case['a_deg'] >= 0
        cnc_back = material_to_cnc_test(mat['x'], mat['y'], mat['z'], mat['u_x'], mat['u_y'], mat['u_z'], mat['b'], elbow_up, rot_norm_mat, rot_pos_mat)
        error = compute_round_trip_error(case, cnc_back, ['x', 'y', 'z', 'b_deg'])
        total_error += error
        print(f"CNC: X={case['x']:.2f}, Y={case['y']:.2f}, Z={case['z']:.2f}, A={case['a_deg']:.2f}, B={case['b_deg']:.2f}")
        print(f" -> Material: X={mat['x']:.2f}, Y={mat['y']:.2f}, Z={mat['z']:.2f}, Nx={mat['u_x']:.2f}, Ny={mat['u_y']:.2f}, Nz={mat['u_z']:.2f}")
        print(f" -> CNC Back: X={cnc_back['x']:.2f}, Y={cnc_back['y']:.2f}, Z={cnc_back['z']:.2f}, A={cnc_back['a_deg']:.2f}, B={cnc_back['b_deg']:.2f}, Error={error:.2f}")
        print("---")
    print(f"Total Error for {desc}: {total_error:.2f}")

print("\nTesting Material to CNC Round Trip with Different Rotation Orders:")
for rot_norm_cnc, rot_pos_cnc, rot_norm_mat, rot_pos_mat, desc in combinations:
    print(f"\n{desc}")
    total_error = 0.0
    for case in test_cases_mat:
        elbow_up = True
        cnc = material_to_cnc_test(case['x'], case['y'], case['z'], case['u_x'], case['u_y'], case['u_z'], case['b_deg'], elbow_up, rot_norm_mat, rot_pos_mat)
        mat_back = cnc_to_material_test(cnc['x'], cnc['y'], cnc['z'], cnc['a_deg'], cnc['b_deg'], rot_norm_cnc, rot_pos_cnc)
        error = compute_round_trip_error(case, mat_back, ['x', 'y', 'z', 'u_x', 'u_y', 'u_z'])
        total_error += error
        print(f"Material: X={case['x']:.2f}, Y={case['y']:.2f}, Z={case['z']:.2f}, Nx={case['u_x']:.2f}, Ny={case['u_y']:.2f}, Nz={case['u_z']:.2f}")
        print(f" -> CNC: X={cnc['x']:.2f}, Y={cnc['y']:.2f}, Z={cnc['z']:.2f}, A={cnc['a_deg']:.2f}, B={cnc['b_deg']:.2f}")
        print(f" -> Material Back: X={mat_back['x']:.2f}, Y={mat_back['y']:.2f}, Z={mat_back['z']:.2f}, Nx={mat_back['u_x']:.2f}, Ny={mat_back['u_y']:.2f}, Nz={mat_back['u_z']:.2f}, Error={error:.2f}")
        print("---")
    print(f"Total Error for {desc}: {total_error:.2f}")
