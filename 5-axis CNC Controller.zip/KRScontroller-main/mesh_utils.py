
import numpy as np
import trimesh
from scipy.spatial.transform import Rotation as R
import cv2
import networkx
from shapely.geometry import LineString

class MeshUtils:
    def __init__(self, param_dict):
        self.param_dict = param_dict
        self.planning_handler = param_dict['handlers']['planning_handler']
        self.cutting_tool_handler = param_dict['handlers']['cutting_tool_handler']
        self.cnc_properties_handler = param_dict['handlers']['cnc_properties_handler']
        self.stl_handler = param_dict['handlers']['stl_handler']
        self.raw_material_handler = param_dict['handlers']['raw_material_handler']
        self.contour_utils = param_dict['utils']['contour_utils']
        self.param_dict['utils']['mesh_utils'] = self
        self.has_protected_meshes = False  # Flag to check if protected meshes exist
        self.has_stl_meshes = False  # Flag to check if STL meshes exist
        self.has_unreachable_mesh = False  # Flag to check if unreachable meshes exist
        self.has_cut_volume_mesh = False
        self.has_cspace_meshes = False
        self.has_free_travel_mesh = False
        self.has_to_be_cut_mesh = False
        self.face_threshold = 5000 # upper threshold for face count to consider subdividing the mesh
        self.to_be_cut = None
        self.total_volume = 0.0
        self.high_res_protected_meshes = []
        self.high_res_stl_meshes = []
        self.high_res_c_space_meshes = []

    def create_cut_volume_mesh(self, tool_path):
        """
        Create a mesh representing the volume cut by the tool path for use as free travel space.
        Returns a trimesh object or None if creation fails.
        Input tool_path is in CNC coordinates, output mesh is in material coordinates.
        Uses origin and normal to align the cut volume with transformed slice meshes.
        Checks if normals/angles differ between points; if so, breaks into higher resolution steps.
        """
        if tool_path is None or len(tool_path) == 0:
            print("CUT_VOLUME: Tool path has no points, returning None. Check if path generation failed due to empty contours or collision constraints.")
            return None
        
        cut_meshes = []

        if len(tool_path)>1:
            print(f"CUT_VOLUME: Tool path has {len(tool_path)} points.")
            for i in range(len(tool_path)-1):  # Handle single point by skipping loop
                p1 = np.array(tool_path[i][:3])  # Extract only XYZ, ignore AB if present
                p2 = np.array(tool_path[i + 1][:3])  # Extract only XYZ, ignore AB if present
                p1ab = np.array(tool_path[i][3:5])
                p2ab = np.array(tool_path[i + 1][3:5])
                #print(f"CUT_VOLUME: Step {i}: p1: {p1}, p2: {p2}, p1ab: {p1ab}, p2ab: {p2ab}")
                if i == 0:
                    first_mesh = self.cutting_tool_handler.get_test_cutting_tool_mesh('XYZAB', p1[0], p1[1], p1[2], p1ab[0], p1ab[1])[0]
                    #print(f"CUT_VOLUME: First mesh volume: {first_mesh.volume:.4f}")
                    #print(f"CUT_VOLUME: First mesh extents: {first_mesh.extents}")
                    #print(f"CUT_VOLUME: First mesh bounding box: {first_mesh.bounds}")
                    first_mesh_is_valid, first_mesh = self.mesh_is_valid(first_mesh)
                    if first_mesh_is_valid:
                        cut_meshes.append(first_mesh)
                    else:
                        print(f"CUT_VOLUME: First mesh creation failed.")

                segment_length = np.linalg.norm(p2 - p1)
                angle_length = np.linalg.norm(p2ab - p1ab)
                # Allow zero length for single point case, but ensure a small volume is created
                if segment_length >= 0 or angle_length > 0:
                    # Check if angles (A and B) differ significantly
                    angles_differ = angle_length > 0.001  # Adjust threshold as needed
                    if angles_differ:
                        # Break into higher resolution steps if angles differ
                        num_steps = max(2, int(segment_length / (self.param_dict['tool_diameter'] / 8.0)))  # Step size is a fraction of tool diameter
                        if num_steps == 0:
                            num_steps = int(angle_length)  # Ensure at least two steps for angle interpolation
                        step_vec = (p2 - p1) / num_steps
                        step_angle_vec = (p2ab - p1ab) / num_steps
                        for j in range(num_steps):
                            interp_p1 = p1 + step_vec * j
                            interp_ab1 = p1ab + step_angle_vec * j
                            # Convert CNC coordinates back to material coordinates for mesh creation
                            self.cutting_tool_handler._testing = True
                            mat_p1_interp = self.cutting_tool_handler.cnc_to_material(interp_p1[0], interp_p1[1], interp_p1[2], interp_ab1[0], interp_ab1[1])
                            self.cutting_tool_handler._testing = False
                            if mat_p1_interp:
                                point_mesh = self.cutting_tool_handler.get_test_cutting_tool_mesh('XYZAB', interp_p1[0], interp_p1[1], mat_p1_interp[2], interp_ab1[0], interp_ab1[1] )[0]
                                point_mesh_is_valid, point_mesh = self.mesh_is_valid(point_mesh)
                                if point_mesh_is_valid:
                                        cut_meshes.append(point_mesh)
                                else:
                                    print(f"CUT_VOLUME: Point mesh creation failed at step {i}-{j}.")
                            else:
                                print(f"CUT_VOLUME: Conversion to material coordinates failed at interpolated step {i}-{j}.")
                    else:
                        # Convert CNC coordinates back to material coordinates for mesh creation
                        self.cutting_tool_handler._testing = True
                        mat_p1 = self.cutting_tool_handler.cnc_to_material(p1[0], p1[1], p1[2], p1ab[0], p1ab[1])
                        mat_p2 = self.cutting_tool_handler.cnc_to_material(p2[0], p2[1], p2[2], p2ab[0], p2ab[1])
                        self.cutting_tool_handler._testing = False
                        #print(f"CUT_VOLUME: CNC to material conversion: p1: {mat_p1}, p2: {mat_p2}")
                        if mat_p1 and mat_p2:
                            # Create a rectangular box connecting the tool diameters at p1 and p2
                            mat_p1_xyz = np.array([mat_p1['x'], mat_p1['y'], mat_p1['z']])
                            mat_p2_xyz = np.array([mat_p2['x'], mat_p2['y'], mat_p2['z']])
                            mat_p1_norm = np.array([mat_p1['u_x'], mat_p1['u_y'], mat_p1['u_z']])
                            #point1_mesh = self.cutting_tool_handler.get_test_cutting_tool_mesh('XYZ + Normal', mat_p1['x'], mat_p1['y'], mat_p1['z'], mat_p1['u_x'], mat_p1['u_y'], mat_p1['u_z'], p1ab[1], p1ab[0]>=0.0 )[0]
                            segment_mesh = self.create_segment_box(mat_p1_xyz, mat_p2_xyz, mat_p1_norm)
                            point2_mesh = self.cutting_tool_handler.get_test_cutting_tool_mesh('XYZAB', p2[0], p2[1], p2[2], p2ab[0], p2ab[1])[0]
                            segment_mesh_is_valid, segment_mesh = self.mesh_is_valid(segment_mesh)
                            if segment_mesh_is_valid:
                                cut_meshes.append(segment_mesh)
                            else :
                                print(f"CUT_VOLUME: Segment mesh creation failed at step {i}.") 
                            p2_is_valid, point2_mesh = self.mesh_is_valid(point2_mesh)   
                            if p2_is_valid:
                                cut_meshes.append(point2_mesh)
                            else:
                                print(f"CUT_VOLUME: Point2 mesh creation failed at step {i}.")
                            
                        else:
                            print(f"CUT_VOLUME: Conversion to material coordinates failed at step {i}.")
        elif len(tool_path) == 1:
            # Handle single point case with a small volume
            p1 = np.array(tool_path[0][:3])  # Extract only XYZ, ignore AB if present
            p1ab = np.array(tool_path[0][3:5]) if len(tool_path[0]) > 3 else np.array([0, 0])
            print(f"CUT_VOLUME: Tool path has only one point at {p1},{p1ab}.")
            point_mesh = self.cutting_tool_handler.get_test_cutting_tool_mesh('XYZAB', p1[0], p1[1], p1[2], p1ab[0], p1ab[1])[0]
            try:
                point_mesh_is_valid, point_mesh = self.mesh_is_valid(point_mesh)
                if point_mesh_is_valid:
                    cut_meshes.append(point_mesh)
                else:
                    print(f"CUT_VOLUME: Point mesh creation failed at step {i}.")
            except:
                print(f"CUT_VOLUME: Segment mesh at step {i} has zero volume or failed creation. Point: {mat_p1}")
          
        if cut_meshes:
            print(f"CUT_VOLUME: Creating cut volume mesh with {len(cut_meshes)} segments.")
            #cut_meshes = trimesh.util.concatenate(cut_meshes)
            cut_mesh = trimesh.boolean.union(cut_meshes, engine='manifold')
            cut_mesh_is_valid, cut_mesh = self.mesh_is_valid(cut_mesh)
            if cut_mesh_is_valid:
                print(f"CUT_VOLUME: Cut mesh volume: {cut_mesh.volume:.4f}")
                raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
                raw_cut_mesh = trimesh.boolean.intersection([raw_mesh, cut_mesh], engine='manifold')
                raw_cut_mesh_is_valid, raw_cut_mesh = self.mesh_is_valid(raw_cut_mesh)
                if raw_cut_mesh_is_valid:
                    cut_mesh = raw_cut_mesh
                return cut_mesh
            else:
                return cut_meshes

            print("CUT_VOLUME: No cut meshes created, returning None.")
           
        return None

    def get_protected_mesh(self):
        """
        Get the protected mesh from the STL handler.
        Returns a list of protected meshes.
        """
        print("PROTECTED: Getting protected meshes.")
        if self.has_protected_meshes:
            print("PROTECTED: Using cached protected meshes.")
            return self.param_dict['material_space_meshes']['protected_meshes'].copy(), self.param_dict['material_space_meshes']['stl_meshes'].copy()


        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        protected_meshes = []
        stl_meshes = []
        for keepout in self.cnc_properties_handler.keepout_zones:
            if keepout.hasattr('name'): print(f"PROTECTED: Processing keepout zone: {keepout['name']}")
            keepout_mesh = self.cnc_properties_handler.get_transformed_keepout_mesh(keepout)[0]
            keepout_is_invalid, keepout_mesh = self.mesh_is_invalid(keepout_mesh)
            if not keepout_is_invalid:
                print(f"PROTECTED: Adding keepout mesh with volume {keepout_mesh.volume:.4f}")
                protected_meshes.append(keepout_mesh)
                self.has_protected_meshes = True
                if update_output_callback:
                    update_output_callback(f"Added keepout mesh with volume {keepout_mesh.volume:.4f}")
           
            else:
                print(f"PROTECTED: Keepout mesh is invalid, type: {type(keepout_mesh)}")
        for stl in self.stl_handler.stl_models:
            print(f"PROTECTED: Processing STL model: {stl['name']}")
            stl_mesh = self.stl_handler.get_transformed_stl_mesh(stl)[0]
            stl_mesh_is_invalid, stl_mesh = self.mesh_is_invalid(stl_mesh)
            if not stl_mesh_is_invalid: 
                print(f"PROTECTED: Adding STL mesh {stl['name']} with volume {stl_mesh.volume:.4f}")   
                protected_meshes.append(stl_mesh)
                stl_meshes.append(stl_mesh)
                self.has_stl_meshes = True
                self.has_protected_meshes = True
                if update_output_callback:
                    update_output_callback(f"Added STL mesh with volume {stl_mesh.volume:.4f}")
            else:
                print(f"PROTECTED: STL mesh is invalid, type: {type(stl_mesh)}")
        print(f"PROTECTED MESHES: {len(protected_meshes)} protected meshes found.")
        self.param_dict['material_space_meshes']['protected_meshes'] = protected_meshes.copy()
        self.param_dict['material_space_meshes']['stl_meshes'] = stl_meshes.copy()
        if len(protected_meshes) == 0:
            self.has_protected_meshes = False
            self.has_stl_meshes = False
            if update_output_callback:
                update_output_callback("No valid protected meshes found.")
           
        if stl_meshes is None or len(stl_meshes) == 0:
            self.has_stl_meshes = False
            
        return protected_meshes, stl_meshes
   
    def mesh_to_stl(self, mesh, name):
        """
        Convert a trimesh object to STL format.
        Returns the STL data as bytes.
        """
        mesh_is_invalid, mesh = self.mesh_is_invalid(mesh)
        if not mesh_is_invalid:
            stl_data = {'mesh': mesh, 'type': 'stl', 'name': name}
            return stl_data
        else:
            print("MESH TO STL: Mesh is not valid.")
            return None

    def create_unreachable_stl(self, cut_volume):
        # Use the transformed raw material mesh from raw_material_handler if raw_mesh is not provided
        
        raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
           
        # Create a mesh for unreachable areas based on keepouts and STL objects
        unreachable_meshes = []
        total_unreachable_volume = 0.0
        
        # Process keepout zones
        for keepout in self.cnc_properties_handler.keepout_zones:
            keepout_mesh = self.cnc_properties_handler.get_transformed_keepout_mesh(keepout)[0]
            if keepout_mesh.volume > 0:
                unreachable_meshes.append(keepout_mesh)
                total_unreachable_volume += keepout_mesh.volume
        
        # Process STL objects
        for stl in self.stl_handler.stl_models:
            stl_mesh = self.stl_handler.get_transformed_stl_mesh(stl)[0]
            if stl_mesh.volume > 0:
                unreachable_meshes.append(stl_mesh)
                total_unreachable_volume += stl_mesh.volume
        
        if unreachable_meshes:
            for unreachable_mesh in unreachable_meshes:
                unreachable_mesh_is_invalid, unreachable_mesh = self.mesh_is_invalid(unreachable_mesh)
                if not unreachable_mesh_is_invalid:
                    # Combine all unreachable meshes
                    combined_unreachable = trimesh.util.concatenate(unreachable_meshes)
                else:
                    print(f"UNREACHABLE: Unreachable mesh is not valid or has zero volume: {unreachable_mesh}")
                    
            # Intersect with raw material to ensure it's within bounds
            combined_unreachable_is_invalid, combined_unreachable = self.mesh_is_invalid(combined_unreachable)
            if not combined_unreachable_is_invalid:
                combined_unreachable = trimesh.boolean.intersection([raw_mesh, combined_unreachable], engine='manifold')
            else:
                print("Warning: Raw mesh or combined unreachable mesh is not valid or has zero volume.")
                combined_unreachable = raw_mesh.copy()
                
            # Note: Mesh simplification is not currently supported in trimesh; consider future updates or alternative libraries if vertex reduction is needed
            combined_unreachable_is_invalid, combined_unreachable = self.mesh_is_invalid(combined_unreachable)
            if not combined_unreachable_is_invalid:
                return {'mesh': combined_unreachable, 'type': 'unreachable'}
            else:
                print("UNREACHABLE: Combined unreachable mesh is not valid or has zero volume.")
                # Fallback if no valid unreachable mesh is created
                unreachable_mesh = trimesh.creation.box(extents=[1, 1, 1])
                unreachable_mesh.apply_translation(raw_mesh.centroid)
                return {'mesh': unreachable_mesh, 'type': 'unreachable'}
        else:
            # Fallback if no keepouts or STLs (should not happen as per plan_path logic)
            unreachable_mesh = trimesh.creation.box(extents=[1, 1, 1])
            unreachable_mesh.apply_translation(raw_mesh.centroid)
            return {'mesh': unreachable_mesh, 'type': 'unreachable'}

    def is_volume_reachable(self, volume_mesh):
        """
        Check if a volume is reachable by the cutting tool considering mechanical limits and collisions.
        Tests multiple orientations using unique normals from STL faces.
        Returns True if reachable, False otherwise.
        """
        tool_diameter = self.param_dict['tool_diameter']
        bounds = volume_mesh.bounds
        center = volume_mesh.centroid
        test_points = [
            center,
            bounds[0],
            bounds[1],
            [bounds[0][0], bounds[0][1], bounds[1][2]],
            [bounds[0][0], bounds[1][1], bounds[0][2]],
            [bounds[1][0], bounds[0][1], bounds[0][2]],
            [bounds[0][0], bounds[1][1], bounds[1][2]],
            [bounds[1][0], bounds[0][1], bounds[1][2]],
            [bounds[1][0], bounds[1][1], bounds[0][2]],
            [bounds[0][0]+tool_diameter/2, bounds[0][1], bounds[1][2]],
            [bounds[0][0]+tool_diameter/2, bounds[1][1], bounds[0][2]],
            [bounds[1][0]+tool_diameter/2, bounds[0][1], bounds[0][2]],
            [bounds[0][0]+tool_diameter/2, bounds[1][1], bounds[1][2]],
            [bounds[1][0]+tool_diameter/2, bounds[0][1], bounds[1][2]],
            [bounds[1][0]+tool_diameter/2, bounds[1][1], bounds[0][2]],
            [bounds[0][0], bounds[0][1]+tool_diameter/2, bounds[1][2]],
            [bounds[0][0], bounds[1][1]+tool_diameter/2, bounds[0][2]],
            [bounds[1][0], bounds[0][1]+tool_diameter/2, bounds[0][2]],
            [bounds[0][0], bounds[1][1]+tool_diameter/2, bounds[1][2]],
            [bounds[1][0], bounds[0][1]+tool_diameter/2, bounds[1][2]],
            [bounds[1][0], bounds[1][1]+tool_diameter/2, bounds[0][2]],
            [bounds[0][0], bounds[0][1], bounds[0][2]+tool_diameter/2],
            [bounds[0][0], bounds[1][1], bounds[0][2]+tool_diameter/2],
            [bounds[1][0], bounds[0][1], bounds[0][2]+tool_diameter/2],
            [bounds[0][0], bounds[1][1], bounds[1][2]+tool_diameter/2],
            [bounds[1][0], bounds[0][1], bounds[1][2]+tool_diameter/2],
            [bounds[1][0], bounds[1][1], bounds[0][2]+tool_diameter/2],
            [bounds[0][0]-tool_diameter/2, bounds[0][1], bounds[1][2]],
            [bounds[0][0]-tool_diameter/2, bounds[1][1], bounds[0][2]],
            [bounds[1][0]-tool_diameter/2, bounds[0][1], bounds[0][2]],
            [bounds[0][0]-tool_diameter/2, bounds[1][1], bounds[1][2]],
            [bounds[1][0]-tool_diameter/2, bounds[0][1], bounds[1][2]],
            [bounds[1][0]-tool_diameter/2, bounds[1][1], bounds[0][2]],
            [bounds[0][0], bounds[0][1]-tool_diameter/2, bounds[1][2]],
            [bounds[0][0], bounds[1][1]-tool_diameter/2, bounds[0][2]],
            [bounds[1][0], bounds[0][1]-tool_diameter/2, bounds[0][2]],
            [bounds[0][0], bounds[1][1]-tool_diameter/2, bounds[1][2]],
            [bounds[1][0], bounds[0][1]-tool_diameter/2, bounds[1][2]],
            [bounds[1][0], bounds[1][1]-tool_diameter/2, bounds[0][2]]
        ]

        # Extract unique normals from all STL models to test various orientations
        unique_normals = []
        for stl in self.stl_handler.stl_models:
            stl_mesh = self.stl_handler.get_transformed_stl_mesh(stl)[0]
            face_normals = stl_mesh.face_normals if hasattr(stl_mesh, 'face_normals') and len(stl_mesh.face_normals) > 0 else []
            if len(face_normals) > 0:
                # Normalize and deduplicate normals to reduce redundant checks
                for normal in face_normals:
                    if np.linalg.norm(normal) > 0:
                        normalized = normal / np.linalg.norm(normal)
                        if not any(np.allclose(normalized, un, atol=0.1) for un in unique_normals):
                            unique_normals.append(normalized)
                # Limit to a reasonable number of normals to test
                unique_normals = unique_normals[:10]  # Test up to 10 distinct orientations per STL

        if not unique_normals:
            # Check the main axes if no normals are available
            unique_normals = [[0, 0, 1]]
            unique_normals.append([0, 1, 0])
            unique_normals.append([1, 0, 0])
            unique_normals.append([0, -1, 0])
            unique_normals.append([-1, 0, 0])

        for point in test_points:
            for normal in unique_normals:
                nx, ny, nz = normal
                is_valid = self.cutting_tool_handler.is_valid_cut('XYZ + Normal', point[0], point[1], point[2], nx, ny, nz=nz, b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], elbow_up=(self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.000))
                if is_valid:
                    return True
        return False

    def create_segment_box(self, p1, p2, normal=[0.000000,0.000000,1.000000]):
        """
        Create a rectangular box connecting two points with a cross-section of tool_diameter by layer_height.
        p1 and p2 are 3D points in material coordinates.
        Returns a trimesh object representing the segment volume.
        Aligns the box with the direction between p1 and p2 for accurate orientation.
        """
        if normal is None:
            normal = np.array([0, 0, 1])
        else:
            normal = np.array(normal)
            if np.linalg.norm(normal) == 0:
                normal = np.array([0, 0, 1])
            else:
                normal = normal / np.linalg.norm(normal)
        tool_diameter = self.param_dict['tool_diameter']
        layer_height = self.param_dict['layer_height']

        # Calculate the direction vector and length of the segment
        direction = p2 - p1
        length = np.linalg.norm(direction)
        radius = tool_diameter / 2.0
        
        if length < 0.000254:  # If points are nearly identical, create a small cubic volume
            # Create a small box centered at p1
            segment_mesh = trimesh.creation.cylinder(radius=radius, height=layer_height, sections=360)
            # Apply translation to position at p1
            segment_mesh.apply_translation(p1)
            segment_mesh_is_valid, segment_mesh = self.mesh_is_valid(segment_mesh)
            if segment_mesh_is_valid:
                
                full_transformation = self.cutting_tool_handler.get_test_cutting_tool_mesh('XYZ + Normal', p1[0], p1[1], p1[2], normal[0], normal[1], normal[2], b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], elbow_up=self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000)[1]
                segment_mesh.apply_transform(full_transformation)
            else:
                print("SEGMENT BOX: segment mesh invalid.")
        
            return segment_mesh

        # Calculate the midpoint for box placement
        midpoint = (p1 + p2) / 2

        # Create the box centered at origin with length along the Z-axis initially
        box = trimesh.creation.box(extents=[length, tool_diameter, layer_height])
        box.apply_translation(box.centroid)
        # Initially translate the box so that one end is at the origin (0,0,0) and the other end is at (0,0,length)
         # Move so that the bottom is at origin after this initial translation
        # Normalize the direction vector
        direction_normalized = direction / length
        
        tilt_angle = np.arcsin(direction_normalized[2])
        pan_angle = np.arctan2(direction_normalized[1], direction_normalized[0])

        # Create rotation matrix to align the box with the direction vector
        
        # Apply the rotation to the box
        rotation_matrix_b = R.from_euler('z', pan_angle, degrees=False).as_matrix()
        rotation_matrix_a = R.from_euler('x', tilt_angle, degrees=False).as_matrix()
        rotation_matrix = np.dot(rotation_matrix_b, rotation_matrix_a) 
        rotation_matrix_4x4 = np.eye(4)
        rotation_matrix_4x4[:3, :3] = rotation_matrix
        box.apply_transform(rotation_matrix_4x4)
         # Translate to the midpoint of the segment
        box.apply_translation([0, 0, layer_height/2]) 
        box.apply_translation(midpoint) 
        # Default box Z-axis is [0,0,1], we need to rotate it to align with direction_normalized
        
        #print(f"SEGMENT BOX: created with bounds: {box.bounds}")
        return box
           
    def get_nearest_stl(self, origin=[0.000000,0.000000,0.0000000], normal=[0.000000,0.000000,1.000000]):

        layer_height = self.param_dict['layer_height']
        nearest_stl = None
        if normal is None or np.allclose(normal, [0, 0, 1]):
            #print("CONCENTRIC: Searching for nearest STL for normal-based orientation")
            min_dist = float('inf')
            min_norm_dist = float('inf')
  
            #print(f"CONCENTRIC: Slice center: {slice_center}")
            for stl in self.stl_handler.stl_models:
                stl_mesh = self.stl_handler.get_transformed_stl_mesh(stl)[0]
                dist = np.linalg.norm(origin - stl_mesh.centroid)
                norm_dist = float('inf')
                for face_normal in stl_mesh.face_normals:
                    if np.linalg.norm(face_normal) > 0:
                        face_normal = face_normal / np.linalg.norm(face_normal)
                        if np.allclose(face_normal, normal, atol=0.1):
                            norm_dist = 0
                            break
                        else:
                            norm_dist = min(norm_dist, np.linalg.norm(face_normal - normal))
                
                if dist < min_dist or (dist <= min_dist and norm_dist < min_norm_dist):
                    min_dist = dist
                    min_norm_dist = norm_dist
                    nearest_stl = stl_mesh
            
        return nearest_stl
    
    def bisect_slice_mesh(self, slice_mesh, origin=[0.000000,0.000000,0.000000], normal=[0.000000,0.000000,1.000000], resolution=0.001):
        """
        Bisect the slice mesh into two halves based on the provided normal and origin.
        Returns a list of two trimesh objects representing the bisected halves.
        """
        slice_mesh_is_valid, slice_mesh = self.mesh_is_valid(slice_mesh)
        if not slice_mesh_is_valid or not self.has_protected_meshes:
            print("BISECT: Invalid slice mesh or no protected meshes, returning original slice mesh")
            return slice_mesh

        protected_meshes = self.param_dict['material_space_meshes']['protected_meshes'].copy()

        if normal is None:
            normal = np.array([0, 0, 1])
        else:
            normal = np.array(normal)
            if np.linalg.norm(normal) == 0:
                normal = np.array([0, 0, 1])
            else:
                normal = normal / np.linalg.norm(normal)
        # Define the plane origin and normal for sectioning 
        if origin is None:
            # Use the centroid of the mesh as the origin if not provided
            plane_origin = slice_mesh.centroid - normal * slice_mesh.extents[2] / 2
        else:
            plane_origin = np.array(origin)

        plane_normal = normal
        intersection_s = None
        intersection_p = None
        if not isinstance(protected_meshes, list):
            protected_meshes = [protected_meshes]
        for protected_mesh in protected_meshes:
            intersection_p = trimesh.intersections.mesh_plane(protected_mesh, plane_normal, plane_origin)
            intersection_s = trimesh.intersections.mesh_plane(slice_mesh, plane_normal, plane_origin)
            while intersection_s is not None and intersection_p is not None and len(intersection_p) > 0 and len(intersection_s) > 0:
                # Adjust the plane origin to avoid intersection with the protected mesh
                plane_origin += normal * resolution
                intersection_p = trimesh.intersections.mesh_plane(protected_mesh, plane_normal, plane_origin)
                intersection_s = trimesh.intersections.mesh_plane(slice_mesh, plane_normal, plane_origin)
        # find out if there is a plane that does not intersect the protected mesh
        if intersection_s is not None and len(intersection_s)>0 and np.linalg.norm(plane_origin - origin) > resolution:
            # If the plane intersects the protected mesh, we need to bisect the slice mesh
            # Create a new mesh from the intersection of the slice and the plane
            sliced_mesh1 = trimesh.intersections.slice_mesh_plane(slice_mesh, plane_normal, plane_origin)
            sliced_mesh2 = trimesh.boolean.difference([slice_mesh, sliced_mesh1])
            sliced_meshes = [sliced_mesh1, sliced_mesh2]
           
            return sliced_meshes
        else:
            print("BISECT: No intersection with protected mesh, returning original slice mesh")
            
            return slice_mesh

    def get_2D_slice(self, origin=[0.000000,0.000000,0.000000], normal=[0.000000,0.000000,1.000000], subdivide=False, resolution=0.001):
        """
        Get the contour slice of the slice mesh at the given origin and normal.
        Returns a list of 2D contours (lists of [x, y] points).
        """
        line_width = self.param_dict['line_width'] 
        layer_height = self.param_dict['layer_height']
        # Use the provided normal or current tool normal for the plane orientation
        if np.linalg.norm(normal) == 0:
            normal = np.array([0, 0, 1])
        else:
            normal = np.array(normal) / np.linalg.norm(normal)
        
        # Define the plane origin and normal for sectioning
        plane_origin = np.array(origin)
        plane_normal = normal
        #print(f"2D SLICE: Slicing at origin {plane_origin} with normal {plane_normal}")

        # get the raw material mesh
        raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
        #print(f"2D SLICE: Raw mesh bounds: {raw_mesh.bounds}, centroid: {raw_mesh.centroid}")
        
        # get the protected meshes
        if self.has_protected_meshes: protected_meshes = self.high_res_protected_meshes.copy()
        else: protected_meshes = []
        # get the slice contours
        contours = []
        
        contour3D = raw_mesh.section(plane_origin=plane_origin, plane_normal=plane_normal)
        if contour3D is None:
            #print("2D SLICE: No slice found, returning empty contours")
            return None
        try:
            planar_contour = contour3D.to_planar()[0]
            #print(f"2D SLICE: Planar contour vertices: {len(planar_contour.vertices)},\nbounds: {planar_contour.bounds}")
            contours.append(planar_contour)
        except Exception as e:
            print(f"2D SLICE: No contours: {str(e)}")
            return None
        if contours is None:
            #print("2D SLICE: No contours found, returning empty contours")
            return None
        if self.has_protected_meshes:
            if not isinstance(protected_meshes, list):
                protected_meshes = [protected_meshes]
            for protected_mesh in self.high_res_protected_meshes:
                    # Check if the mesh is a valid volume
                try:    
                    section = protected_mesh.section(plane_origin=plane_origin, plane_normal=plane_normal).to_planar()[0]  
                    if section is not None:
                        contours.append(section)
                        self.planning_handler.found_stl = True
                    else:
                        #print("2D SLICE: No contours found in protected mesh")
                        continue
                except Exception as e:
                    print(f"2D SLICE: No contours found in protected mesh. Error: {str(e)}")
                    continue
        return contours

    def get_3D_slice_cylinder(self, radius=10.0, origin=[0.000000,0.000000,0.000000], normal=[0.000000,000000,1.000000], b_deg=0.0, elbowUp=True):
        """
        Get the 3D slice of the mesh at the given origin and normal.
        Returns a trimesh object representing the slice volume.
        """
        layer_height = self.param_dict['layer_height']

        # Use the provided normal or current tool normal for the plane orientation
        if np.linalg.norm(normal) == 0:
            normal = np.array([0, 0, 1])
        else:
            normal = np.array(normal) / np.linalg.norm(normal)
        
        # Define the plane origin and normal for sectioning
        plane_origin = np.array(origin)
        plane_normal = normal
        try:
            result = self.cutting_tool_handler.get_test_cutting_tool_mesh('XYZ + Normal', plane_origin[0], plane_origin[1], plane_origin[2], normal[0], normal[1], normal[2], b_deg=b_deg, elbow_up=elbowUp)
        except Exception as e:
            print(f"3D CYLINDER: Error getting cutting tool mesh: {str(e)}")
            return trimesh.Trimesh()
       
        if result is None or len(result) < 2:
            print("3D CYLINDER: get_test_cutting_tool_mesh returned None or invalid result.")
            return trimesh.Trimesh()
        full_transform = result[1]
        
        result_is_valid, tool_mesh = self.mesh_is_valid(result[0])
        if result_is_valid:
            slice_cylinder = trimesh.creation.cylinder(radius=radius, height=layer_height, sections=360)
            slice_cylinder.apply_translation(slice_cylinder.centroid)
            # Initially translate the cylinder so that one end is at the origin (0,0,0) and the other end is at (0,0,length)
            slice_cylinder.apply_translation([0, 0, layer_height/2])
            slice_cylinder.apply_transform(full_transform)
            return slice_cylinder
        else:
            print("3D CYLINDER: Raw mesh is invalid.")
            return trimesh.Trimesh()

    def get_to_be_cut_mesh(self, new_cut_volume=None):
        """
        Get the to_be_cut mesh from the STL handler.
        Returns a list of to_be_cut meshes.
        """
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
        cut_volume_mesh = trimesh.Trimesh()
        to_be_cut = trimesh.Trimesh()
        if self.has_to_be_cut_mesh:
            to_be_cut = self.param_dict['material_space_meshes']['to_be_cut'].copy()
        else:
            to_be_cut = raw_mesh.copy()
        if self.has_cut_volume_mesh:
            #print("TO BE CUT: Has existing cut volume mesh")
            cut_volume_mesh = self.param_dict['material_space_meshes']['cut_volume_mesh'].copy()
            cut_volume_mesh_is_invalid, cut_volume_mesh = self.mesh_is_invalid(cut_volume_mesh)
            if cut_volume_mesh_is_invalid:
                self.has_cut_volume_mesh = False
        else:
            cut_volume_mesh = self.create_cut_volume_mesh(self.param_dict['tool_path'])
            cut_volume_mesh_is_invalid, cut_volume_mesh = self.mesh_is_invalid(cut_volume_mesh)
            if not cut_volume_mesh_is_invalid:
                self.has_cut_volume_mesh = True
                if update_output_callback:
                    update_output_callback(f"Created cut volume mesh with volume {cut_volume_mesh.volume:.4f}")
        new_cut_volume_is_list = False
        new_cut_volume_is_invalid, new_cut_volume = self.mesh_is_invalid(new_cut_volume)
        if new_cut_volume_is_invalid:
            if isinstance(new_cut_volume, list):
                new_cut_volume_is_list = True
        if new_cut_volume_is_invalid and not self.has_cut_volume_mesh and not (self.has_protected_meshes or self.has_stl_meshes):
            self.has_cut_volume_mesh = False
            self.param_dict['material_space_meshes']['to_be_cut'] = raw_mesh.copy()
        if self.has_protected_meshes:
            protected_meshes = self.param_dict['material_space_meshes']['protected_meshes'].copy()
        
        if self.has_protected_meshes and not self.has_to_be_cut_mesh:
            print("TO BE CUT: Processing protected meshes for subtraction")
            for idx, protected_mesh in enumerate(protected_meshes):
                test_to_be_cut = to_be_cut.copy()
                try:
                    test_to_be_cut = trimesh.boolean.difference([to_be_cut, protected_mesh])
                    to_be_cut_is_invalid, test_to_be_cut = self.mesh_is_invalid(test_to_be_cut)
                    if not to_be_cut_is_invalid:
                        to_be_cut = test_to_be_cut.copy()

                        print(f"TO BE CUT: Protected mesh {idx} difference successful, resulting volume: {to_be_cut.volume:.4f}")
                    else:
                        print(f"TO BE CUT: Protected mesh {idx} is not valid, skipping. Volume: {protected_mesh.volume if isinstance(protected_mesh, trimesh.Trimesh) else 'N/A'}")
                except Exception as e:
                    print(f"TO BE CUT: Difference operation for mesh {idx} failed with error: {str(e)}")
                
        
        has_combined_cut_volume_mesh = False
        if not new_cut_volume_is_invalid:
            if self.has_cut_volume_mesh:
                print(f"TO BE CUT: Attempting union operation on cut_volume meshes with bounds: {cut_volume_mesh.bounds} and {new_cut_volume.bounds}")
                try:
                    print("TO BE CUT: Copying cut volume mesh for union operation")
                    combined_cut_volume_mesh = cut_volume_mesh.copy()
                    print("TO BE CUT: Attempting union operation")
                    combined_cut_volume_mesh = trimesh.boolean.union([new_cut_volume, cut_volume_mesh])
                    combined_cut_volume_mesh_is_invalid, combined_cut_volume_mesh = self.mesh_is_invalid(combined_cut_volume_mesh)
                    if not combined_cut_volume_mesh_is_invalid:
                        print("TO BE CUT: cut volume union operation successful")
                        has_combined_cut_volume_mesh = True
                        cut_volume_mesh = combined_cut_volume_mesh.copy()
                    else:
                        print("TO BE CUT: Union operation resulted in an invalid mesh.")
                        
                except Exception as e:
                    print(f"TO BE CUT: Union operation failed: {str(e)}")
            else:
                cut_volume_mesh = new_cut_volume.copy()
                cut_volume_mesh_is_valid, cut_volume_mesh = self.mesh_is_valid(cut_volume_mesh)
                if cut_volume_mesh_is_valid:
                    self.has_cut_volume_mesh = True
                    print(f"TO BE CUT: Using new cut volume mesh of volume {cut_volume_mesh.volume:.4f}")

        has_raw_cut_volume_mesh = False
        if self.has_cut_volume_mesh:
                # If the intersection is valid, use it as the cut volume mesh
            raw_cut_volume_mesh = trimesh.boolean.intersection([raw_mesh, cut_volume_mesh])
            raw_cut_volume_mesh_is_valid, raw_cut_volume_mesh = self.mesh_is_valid(raw_cut_volume_mesh)
            if raw_cut_volume_mesh_is_valid:
                cut_volume_mesh = raw_cut_volume_mesh.copy()
                has_raw_cut_volume_mesh = True
                print(f"TO BE CUT: Raw cut volume mesh of volume {raw_cut_volume_mesh.volume:.4f}")
        

        if self.has_cut_volume_mesh:
                print(f"TO BE CUT: to be cut bounds {to_be_cut.bounds} and cut volume bounds {cut_volume_mesh.bounds}")
                try:
                    if not self.has_to_be_cut_mesh or has_combined_cut_volume_mesh or has_raw_cut_volume_mesh:
                        #print("TO BE CUT: Copying to be cut mesh for difference operation")
                        test_to_be_cut = to_be_cut.copy()
                        #print("TO BE CUT: Attempting difference operation")
                        if not has_raw_cut_volume_mesh: test_to_be_cut = trimesh.boolean.difference([to_be_cut, cut_volume_mesh])
                        else: test_to_be_cut = trimesh.boolean.difference([to_be_cut, raw_cut_volume_mesh])
                        test_to_be_cut_is_invalid, test_to_be_cut = self.mesh_is_valid(test_to_be_cut)
                        if not test_to_be_cut_is_invalid:
                            to_be_cut = test_to_be_cut.copy()
                            #print(f"TO BE CUT: Cut volume difference successful, volume: {to_be_cut.volume:.4f}")
                    if not has_combined_cut_volume_mesh and not new_cut_volume_is_invalid:
                        #print("TO BE CUT: Attempting to subtract new cut volume from to be cut mesh")
                        if not new_cut_volume_is_list:
                            test_to_be_cut = trimesh.boolean.difference([to_be_cut, new_cut_volume])
                            test_to_be_cut_is_valid, test_to_be_cut = self.mesh_is_valid(test_to_be_cut)
                            if test_to_be_cut_is_valid:
                                to_be_cut = test_to_be_cut.copy()
                                #print(f"TO BE CUT: Cut volume difference successful, volume: {to_be_cut.volume:.4f}")
                        else:
                            for new_cut_volume_mesh in new_cut_volume:
                                test_to_be_cut = trimesh.boolean.difference([to_be_cut, new_cut_volume_mesh])
                                test_to_be_cut_is_valid, test_to_be_cut = self.mesh_is_valid(test_to_be_cut)
                                if test_to_be_cut_is_valid:
                                    to_be_cut = test_to_be_cut.copy()
                                    self.has_to_be_cut_mesh = True
                                    #print(f"TO BE CUT: Cut volume difference successful, volume: {to_be_cut.volume:.4f}")
                            to_be_cut_is_valid, to_be_cut = self.mesh_is_valid(to_be_cut)
                            if to_be_cut_is_valid:
                                to_be_cut = to_be_cut.copy()
                                self.has_to_be_cut_mesh = True
                        
                except Exception as e:
                    print(f"TO BE CUT: Difference operation failed (2): {str(e)}")                
        
        if self.has_cut_volume_mesh:
            self.param_dict['material_space_meshes']['cut_volume_mesh'] = cut_volume_mesh.copy()
        to_be_cut_is_valid, to_be_cut = self.mesh_is_valid(to_be_cut)
        if to_be_cut_is_valid:
            self.param_dict['material_space_meshes']['to_be_cut'] = to_be_cut.copy()
            self.has_to_be_cut_mesh = True
        
        return to_be_cut.copy()
   
    def generate_configuration_space_meshes(self):
        
        """
        Generate the configuration space mesh for the CNC machine.
        Returns a trimesh object representing the configuration space.
        """
        # Get the raw material mesh
        raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
        protected_meshes = self.param_dict['material_space_meshes']['protected_meshes'].copy()
        unreachable_mesh = self.param_dict['material_space_meshes']['unreachable_mesh'].copy()
        cut_volume_mesh = self.param_dict['material_space_meshes']['cut_volume_mesh'].copy()
        stl_meshes = self.param_dict['material_space_meshes']['stl_meshes'].copy()
        a_deg = self.param_dict['ab_rotation'][0]
        b_deg = self.param_dict['ab_rotation'][1]
        cspace_matrix = self.param_dict['cspace_matrix'].copy()
        if self.has_protected_meshes and protected_meshes is None or len(protected_meshes) == 0:
            self.has_protected_meshes = False
        if self.has_stl_meshes and stl_meshes is None or len(stl_meshes) == 0:
            self.has_stl_meshes = False
        if self.has_cut_volume_mesh:
            cut_volume_is_invalid, cut_volume_mesh = self.mesh_is_invalid(cut_volume_mesh)
            self.has_cut_volume_mesh = False if cut_volume_is_invalid else True
        if self.has_unreachable_mesh:
            unreachable_is_invalid, unreachable_mesh = self.mesh_is_invalid(unreachable_mesh)
            if unreachable_is_invalid: 
                #print("CSPACE GEN: Unreachable mesh is not valid, skipping.")
                self.has_unreachable_mesh = False
        
        cspace_matrix = self.cutting_tool_handler.get_material_to_cnc_matrix(a_deg, b_deg) 
        cspace_matrix_4x4 = np.eye(4)
        cspace_matrix_4x4[:3, :3] = cspace_matrix
        cspace_raw_mesh = raw_mesh.copy()
        if not self.has_cut_volume_mesh and not self.has_unreachable_mesh and not self.has_protected_meshes and not self.has_stl_meshes:
            self.has_cspace_meshes = False
            print("CSPACE GEN: No meshes to process, returning empty configuration space mesh")
            return False
        
        if self.has_cut_volume_mesh: cspace_cut_volume_mesh = cut_volume_mesh.copy()
        if self.has_unreachable_mesh: cspace_unreachable_mesh = unreachable_mesh.copy()
        if self.has_protected_meshes: cspace_protected_meshes = protected_meshes.copy()
        if self.has_stl_meshes: cspace_stl_meshes = stl_meshes.copy()
        
        

        try:
            if cspace_matrix is None or not isinstance(cspace_matrix, np.ndarray) or cspace_matrix.shape != (3, 3):
                raise ValueError("Invalid transformation matrix for configuration space")
            cspace_raw_mesh.apply_transform(cspace_matrix_4x4)
            if self.has_cut_volume_mesh: cspace_cut_volume_mesh.apply_transform(cspace_matrix_4x4)
            if self.has_unreachable_mesh: cspace_unreachable_mesh.apply_transform(cspace_matrix_4x4)

            if self.has_protected_meshes:
                for mesh in cspace_protected_meshes:
                    mesh_invalid, mesh = self.mesh_is_invalid(mesh)
                    if mesh_invalid:
                        mesh.apply_transform(cspace_matrix_4x4)
                    else:
                        print("CSPACE GEN: Protected mesh is not valid, skipping.")
            if self.has_stl_meshes and isinstance(cspace_stl_meshes, list):
                for mesh in cspace_stl_meshes:
                    stl_is_invalid, mesh = self.mesh_is_invalid(mesh)
                    if stl_is_invalid:
                        mesh.apply_transform(cspace_matrix_4x4)
                    else:
                        print("CSPACE GEN: STL mesh is not valid, skipping.")
            # pack the dict
            self.param_dict['cspace_matrix'] = cspace_matrix.copy()
            self.param_dict['cspace_meshes']['raw_mesh'] = cspace_raw_mesh.copy()
            if self.has_cut_volume_mesh: self.param_dict['cspace_meshes']['cut_volume_mesh'] = cspace_cut_volume_mesh.copy()
            if self.has_unreachable_mesh: self.param_dict['cspace_meshes']['unreachable_mesh'] = cspace_unreachable_mesh.copy()
            if self.has_protected_meshes: self.param_dict['cspace_meshes']['protected_meshes'] = cspace_protected_meshes.copy()
            if self.has_stl_meshes: self.param_dict['cspace_meshes'] ['stl_meshes'] = cspace_stl_meshes.copy()
            
            return True
        except ValueError:
            print("CSPACE MESHES: Invalid transformation matrix for configuration space")
            return False
        except Exception as e:
            print(f"CSPACE MESHES: Error applying transformation to meshes: {str(e)}")
            return False
 
    def mesh_is_valid(self, mesh):
        """
        Check if a mesh is valid.
        Args:
            mesh (trimesh.Trimesh): Mesh to check.
        Returns:
            bool: True if the mesh is valid, False otherwise.
        """
        
        if mesh is None:
            print("MESH VALID: Mesh is None.")
            return False, mesh
        if not isinstance(mesh, trimesh.Trimesh) and not isinstance(mesh, trimesh.base.Trimesh):
            print(f"MESH VALID: Mesh is not a valid Trimesh object. Type: {type(mesh)}")
            return False, mesh
        invalid_mesh = False
        if not mesh.is_volume:
            invalid_mesh = True
            print("MESH VALID: Mesh is not a valid volume.")
        if mesh.volume <= 0.0:
            invalid_mesh = True
            if mesh.volume == 0.0:
                print("MESH VALID: Mesh volume is zero.")
                return False, mesh
            else:   
                print("MESH VALID: Mesh volume is negative.")
        if not mesh.is_watertight:
            invalid_mesh = True
            print("MESH VALID: Mesh is not watertight.")
        if invalid_mesh:
            print("MESH VALID: Attempting to fix mesh.")
            mesh = self.fix_mesh(mesh)  # Attempt to fix the mesh
        else: 
            return True, mesh
        invalid_mesh = False
        if mesh is None:
            print("MESH VALID: Mesh is None after fixing.")
            return False, mesh
        if not isinstance(mesh, trimesh.Trimesh):
            print(f"MESH VALID: Mesh is not a valid Trimesh object after fixing. Type: {type(mesh)}")
            return False, mesh
        if not mesh.is_watertight:
            invalid_mesh = True
            print("MESH VALID: Mesh is not watertight after fixing.")
        if not mesh.is_volume:
            invalid_mesh = True
            print("MESH VALID: Mesh is not a valid volume after fixing.")
        if mesh.volume <= 0.0:
            invalid_mesh = True
            if mesh.volume == 0.0:
                print("MESH VALID: Mesh volume is zero after fixing.")
                return False, mesh
            else:
                print("MESH VALID: Mesh volume is negative after fixing.")
        if invalid_mesh:
            print("MESH VALID: Mesh is still invalid after fixing.")
            return False, mesh
        print("MESH VALID: Mesh repair succesful.")
        return True, mesh

    def mesh_is_invalid(self, mesh, repair=True):
        """
        Check if a mesh is invalid.
        Args:
            mesh (trimesh.Trimesh): Mesh to check.
        Returns:
            bool: True if the mesh is invalid, False otherwise.
        """
        
        if mesh is None:
            #print("MESH INVALID: Mesh is None.")
            return True, mesh
        if not isinstance(mesh, trimesh.Trimesh) and not isinstance(mesh, trimesh.base.Trimesh):
            print(f"MESH INVALID: Mesh is not a valid Trimesh object. Type: {type(mesh)}")
            return True, mesh
        
        if repair: 
            mesh = self.repair_mesh(mesh)
        mesh_is_invalid = False
        if not mesh.is_volume:
            print("MESH INVALID: Mesh is not a volume.")
            mesh_is_invalid = True
        if mesh.volume <= 0.0:
            print("MESH INVALID: Mesh volume is zero or negative.")
            mesh_is_invalid = True
        if not mesh.is_watertight:
            print("MESH INVALID: Mesh is not watertight.")
            mesh_is_invalid = True
        if mesh.is_empty:
            print("MESH INVALID: Mesh is empty.")
            mesh_is_invalid = True
        
        return mesh_is_invalid, mesh

    def fix_mesh(self, mesh):
        
        if mesh is not None and isinstance(mesh, trimesh.Trimesh) and not mesh.volume==0.0:
            print(f"FIX MESH: Fixing mesh with volume {mesh.volume} and is_watertight={mesh.is_watertight}")
            while not mesh.is_watertight or not mesh.is_volume:
                mesh = mesh.convex_hull

                trimesh.repair.fill_holes(mesh)
                trimesh.repair.broken_faces(mesh)
           
                
                trimesh.repair.fix_normals(mesh)
                trimesh.repair.fix_winding(mesh)
            if mesh.volume<0:  
                mesh.invert()  
        print(f"FIX MESH: Fixed mesh with volume {mesh.volume} and is_watertight={mesh.is_watertight}")
        return mesh

    def repair_mesh(self, mesh): 
        """
        Repair a mesh using trimesh.
        Args:
            mesh (trimesh.Trimesh): Mesh to repair.
        Returns:
            trimesh.Trimesh: Repaired mesh.
        """
        if mesh is not None and (isinstance(mesh, trimesh.Trimesh) or isinstance(mesh, trimesh.base.Trimesh)):
            trimesh.repair.fill_holes(mesh)
            trimesh.repair.broken_faces(mesh)
            trimesh.repair.fix_normals(mesh)
            trimesh.repair.fix_winding(mesh)
        return mesh
    
    def initialize_meshes(self):
        # Placeholder for raw material mesh
        raw_material = self.raw_material_handler.raw_material
        if not raw_material:
            
            return False, "No raw material mesh found."
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        
# Use the transformed raw material mesh from raw_material_handler
        raw_mesh = self.raw_material_handler.get_transformed_raw_material_mesh()[0]
        if update_output_callback:
            update_output_callback(f"Added raw material mesh with volume {raw_mesh.volume:.4f}")
        raw_is_invalid, raw_mesh = self.mesh_is_invalid(raw_mesh)
        if raw_is_invalid:
            return False, "Raw material mesh is not a Trimesh object, type: {type(raw_mesh)}"

        #find a sphere which encloses the entire raw material, centered at [0,0,0]
        raw_mesh_bounds = raw_mesh.bounds
        layer_height = self.param_dict['layer_height']
        line_width = self.param_dict['line_width']
        resolution = self.param_dict['tolerance']
        
        corner_points = [
            raw_mesh_bounds[0],  # min x, min y, min z
            [raw_mesh_bounds[0][0], raw_mesh_bounds[0][1], raw_mesh_bounds[1][2]],  # min x, min y, max z
            [raw_mesh_bounds[0][0], raw_mesh_bounds[1][1], raw_mesh_bounds[0][2]],  # min x, max y, min z
            [raw_mesh_bounds[0][0], raw_mesh_bounds[1][1], raw_mesh_bounds[1][2]],  # min x, max y, max z
            [raw_mesh_bounds[1][0], raw_mesh_bounds[0][1], raw_mesh_bounds[0][2]],  # max x, min y, min z
            [raw_mesh_bounds[1][0], raw_mesh_bounds[0][1], raw_mesh_bounds[1][2]],  # max x, min y, max z
            [raw_mesh_bounds[1][0], raw_mesh_bounds[1][1], raw_mesh_bounds[0][2]],  # max x, max y, min z
            raw_mesh_bounds[1]   # max x, max y, max z
        ]
        distances_from_origin = [np.linalg.norm(np.array(corner)) for corner in corner_points]
        self.planning_handler.z_retraction_point = max(distances_from_origin)+layer_height  # Add 20% margin for safety


        self.param_dict['material_space_meshes']['raw_mesh'] = raw_mesh
        self.total_volume = raw_mesh.volume
        initial_to_be_cut_volume = raw_mesh.volume
        
        print(f"Initial volume to be cut: {initial_to_be_cut_volume:.4f}")
        if initial_to_be_cut_volume == 0:
            return False, "MESH INIT: Initial volume is zero, no material to cut."
            
        self.has_cut_volume_mesh = False  # Initialize cut volume mesh flag
        self.has_unreachable_mesh = False  # Initialize unreachable mesh flag  
        cut_volume_mesh = trimesh.Trimesh()  # Initialize empty "cut" volume
        unreachable_mesh = trimesh.Trimesh()  # Initialize empty "unreachable" volume

        protected_meshes, stl_meshes = self.get_protected_mesh()
        self.has_stl_meshes = True  # Initialize STL meshes flag
        if isinstance(protected_meshes, trimesh.Trimesh) or isinstance(protected_meshes, trimesh.base.Trimesh):
            protected_meshes = [protected_meshes]
        if isinstance(stl_meshes, trimesh.Trimesh) or isinstance(stl_meshes, trimesh.base.Trimesh):
            stl_meshes = [stl_meshes]
        if protected_meshes is None or len(protected_meshes) == 0:
            self.has_protected_meshes = False
            if update_output_callback:
                update_output_callback("No protected meshes found.")
        if stl_meshes is None or len(stl_meshes) == 0:
            if update_output_callback:
                update_output_callback("No STL meshes found.")
            self.has_stl_meshes = False

        if not self.has_protected_meshes and not self.has_stl_meshes:
            return False, "No protected meshes or STL meshes found."

        if update_output_callback:
            update_output_callback(f"Added {len(protected_meshes)} protected meshes. Getting high-resolution versions for slicing.")
            update_output_callback(f"This may take some time....")
        for protected_mesh in protected_meshes:
            self.high_res_protected_meshes.append(self.get_high_res_mesh(protected_mesh.copy(), resolution=resolution))
        for stl_mesh in stl_meshes:
            self.high_res_stl_meshes.append(self.get_high_res_mesh(stl_mesh.copy(), resolution=resolution))
        if update_output_callback:
            update_output_callback(f"Added {len(self.high_res_protected_meshes)} high-res protected meshes.")
        self.param_dict['material_space_meshes'] = {
                'cut_volume_mesh': cut_volume_mesh,
                'unreachable_mesh': unreachable_mesh,
                'protected_meshes': protected_meshes,
                'stl_meshes': stl_meshes,
                'raw_mesh': raw_mesh}
        self.param_dict['cspace_meshes'] = {
                'cut_volume_mesh': cut_volume_mesh,
                'unreachable_mesh': unreachable_mesh,
                'protected_meshes': protected_meshes,
                'stl_meshes': stl_meshes,
                'raw_mesh': raw_mesh}
        return True, "Mesh initialization successful."

    def get_unreachable_stl(self):
        """
        Get the unreachable mesh from the STL handler.
        Returns a trimesh object representing the unreachable volume.
        """
        cut_volume_mesh = trimesh.Trimesh()
        unreachable_mesh = trimesh.Trimesh()
        unreachable_stl = None
        unreachable_volume = 0.0
        if self.has_cut_volume_mesh: cut_volume_mesh = self.param_dict['material_space_meshes']['cut_volume_mesh'].copy()
        if self.has_unreachable_mesh: unreachable_mesh = self.param_dict['material_space_meshes']['unreachable_mesh'].copy()
        # Identify unreachable volumes
        if self.has_unreachable_mesh:
            unreachable_volume = unreachable_mesh.volume if isinstance(unreachable_mesh, trimesh.Trimesh) else 0
        else:
            if self.has_cut_volume_mesh:
                raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
                cut_volume_mesh = self.param_dict['material_space_meshes']['cut_volume_mesh'].copy()
                if raw_mesh.is_empty:
                    print("UNREACHABLE: Raw mesh is empty, cannot calculate unreachable volume.")
                    return None
                else:
                    unreachable_mesh = raw_mesh.difference(cut_volume_mesh)
                    unreachable_volume = unreachable_mesh.volume if isinstance(unreachable_mesh, trimesh.Trimesh) else 0
        if unreachable_volume > 0:
                unreachable_mesh_is_invalid, unreachable_mesh = self.mesh_is_invalid(unreachable_mesh)
                if self.has_unreachable_mesh and not unreachable_mesh_is_invalid:
                    unreachable_stl = {'mesh': unreachable_mesh, 'type': 'unreachable'}
                else: 
                    unreachable_stl = {'mesh': trimesh.Trimesh(), 'type': 'unreachable'}
        else:
            return None
        
        return unreachable_stl
        
    def get_cut_volume_stl(self, tool_path):
        if tool_path is None:
            return None
        cut_volume_mesh = self.create_cut_volume_mesh(tool_path)
        return self.mesh_to_stl(cut_volume_mesh, 'cut_volume_mesh')

    def get_z_slices(self, steps, resolution=0.01, origin=[0.000000,0.000000,0.000000], normal=[0.000000,0.000000,1.000000], top_down=True):
        """
        Get the Z slices of the mesh.
        Returns a list of Z slice values.
        """
        update_progress_callback = self.param_dict['callbacks']['update_progress_callback']
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        contours = []
        if top_down:
            bottom_range = steps
            step_direction = -1
            top_range = 0
        else:
            bottom_range = 0
            top_range = steps
            step_direction = 1
        if update_output_callback:
            update_output_callback(f"Z SLICES: Processing {steps} slices from {bottom_range*abs(resolution)} to {top_range*abs(resolution)} with resolution {abs(resolution)}.")
        print(f"Z SLICES: Processing {steps} slices from {bottom_range*abs(resolution)} to {top_range*abs(resolution)} with resolution {abs(resolution)}.")
        self.planning_handler.found_stl = False
        for i in range(bottom_range, top_range+step_direction, step_direction):
            slice_origin = [origin[0]+i*resolution*normal[0], origin[1]+i*resolution*normal[1], origin[2]+i*resolution*normal[2]]
            #print(f"Z SLICES: Slice {i}: Origin: {slice_origin}, Normal: {normal}")
           
            slices = self.get_2D_slice(origin=slice_origin, normal=normal)
            if slices is None:
                print(f"Z SLICES: No slices found at slice {i}.")
                continue
            if isinstance(slices, trimesh.path.Path2D):
                slice_contours = self.contour_utils.slice_to_contours(slices)
                contours.append(slice_contours)
            elif isinstance(slices, (list, trimesh.path.Path2D)):
                for slice in slices:
                    slice_contours = self.contour_utils.slice_to_contours(slice)
                    contours.append(slice_contours)
            else:
                contours.append(None)
            if update_progress_callback:
                if top_down:
                    update_progress_callback(((steps-i)/steps) * 100)
                else:
                    update_progress_callback((i/steps) * 100)
        return contours   

    def slices_are_equal(self, slice1, slice2):
        """
        Check if two slices are equal.
        Returns True if equal, False otherwise.
        """
        if slice1 is None or slice2 is None:
            return False
        if len(slice1) != len(slice2):
            return False
        for contour1, contour2 in zip(slice1, slice2):
            if not np.array_equal(contour1, contour2):
                return False
        return True
    
    def point_is_inside_mesh(self, point, mesh):
        """
        Check if a point is inside a mesh.
        Returns True if inside, False otherwise.
        """
        if mesh is None or not isinstance(mesh, trimesh.Trimesh):
            return False
        return mesh.contains([point])[0]
    
    def plane_intersects_mesh(self, plane_origin, plane_normal, mesh):
        """
        Check if a plane intersects a mesh.
        Returns True if intersects, False otherwise.
        """
        if mesh is None or not isinstance(mesh, trimesh.Trimesh):
            return False
        return mesh.section(plane_origin=plane_origin, plane_normal=plane_normal) is not None
    
    def plane_intersects_protected_mesh(self, plane_origin, plane_normal, protected_meshes):
        """
        Check if a plane intersects a protected mesh.
        Returns True if intersects, False otherwise.
        """
        if protected_meshes is None or not isinstance(protected_meshes, list):
            return False
        for protected_mesh in protected_meshes:
            if self.plane_intersects_mesh(plane_origin, plane_normal, protected_mesh):
                return True
        return False
    
    def get_high_res_mesh(self, mesh, resolution=0.001):
        """
        Get a high resolution mesh from the given mesh.
        Returns a trimesh object representing the high resolution mesh.
        """
        if mesh is None or not isinstance(mesh, trimesh.Trimesh):
            return None
        if len(mesh.faces) > self.face_threshold:
            print(f"GET HIGH RES MESH: Mesh has {len(mesh.faces)} faces, skipping high res generation.")
            return mesh.copy()
           
        high_res_mesh = mesh.subdivide_to_size(max_edge=resolution)
        return high_res_mesh.copy()






