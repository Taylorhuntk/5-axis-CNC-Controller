# File: cnc_gui.py
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel, QHBoxLayout, 
                             QTextEdit, QComboBox, QListWidget, QSlider, QLineEdit, QTabWidget, 
                             QFormLayout, QDoubleSpinBox, QRadioButton, QButtonGroup, QCheckBox, QProgressBar)
from PyQt5.QtCore import Qt, pyqtSignal, QPoint, QTimer, QThread, QEvent
from PyQt5.QtGui import QColor, QPalette, QMouseEvent, QWheelEvent
from PyQt5.QtOpenGL import QGLWidget as QOpenGLWidget
from cnc_planning_handler import CNCPlanningHandler
from PyQt5.QtWidgets import QProgressDialog
from PyQt5.QtGui import QGuiApplication
from PyQt5.QtWidgets import QToolTip
from PyQt5.QtGui import QCursor
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
from scipy.spatial.transform import Rotation as R  # Added for rotation matrix creation
import sys
import numpy as np
import math
import trimesh
from cnc_controller import CNCController
from stl_handler import STLHandler
from raw_material_handler import RawMaterialHandler
from cutting_tool_handler import CuttingToolHandler

from cnc_properties_handler import CNCPropertiesHandler
from cnc_path_handler import CNCPathHandler
from cnc_planning_handler import CNCPlanningHandler
from helper_methods import Helpers

class CNCGUI(QMainWindow):
    view_rotation_changed = pyqtSignal(float, float, float)

    def __init__(self):
        super().__init__()
        self.cnc = CNCController()
        self.view_rotation = [-60, 0, 45]
        self.current_unit = 'CM'
        self.rotation_unit = 'DEG'
        self.zoom = 30.0
        self.translation = [10, 10, 0]
        self.last_pos = QPoint()
        self.mouse_pressed = False
        # Initialize handlers first without accessing UI elements
        self.helpers = Helpers()
        self.stl_handler = STLHandler(self)
        self.raw_material_handler = RawMaterialHandler(self)
        self.cnc_properties_handler = CNCPropertiesHandler(self)
        self.cutting_tool_handler = CuttingToolHandler(self)
        self.path_handler = CNCPathHandler(self)
        self.planning_handler = CNCPlanningHandler(self)
        
        self.pending_tool_update = False
        self.pending_xyzab = None
        self.pending_xyz_normal = None
        # Set the signal for updating tool position during planning
        self.initUI()
        self.cutting_tool_handler.test_cnc_to_material_round_trip()
        self.cutting_tool_handler.test_material_to_cnc_round_trip()

    def initUI(self):
        self.setWindowTitle('5-Axis CNC Controller with STL Viewer')
        
        #self.setGeometry(100, 100, 1200, 800)  # Original size
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)
        
        left_layout = QVBoxLayout()
        main_layout.addLayout(left_layout, 1)
        
        self.connection_status = QLabel('Disconnected')
        self.connection_status.setAlignment(Qt.AlignCenter)
        self.update_connection_status(False)
        left_layout.addWidget(self.connection_status)
        
        connect_button = QPushButton('Connect')
        connect_button.clicked.connect(self.toggle_connection)
        left_layout.addWidget(connect_button)
        
        start_button = QPushButton('Start')
        start_button.clicked.connect(self.cnc.start_operation)
        left_layout.addWidget(start_button)
        
        stop_button = QPushButton('Stop')
        stop_button.clicked.connect(self.cnc.stop_operation)
        left_layout.addWidget(stop_button)
        
        self.add_motor_controls(left_layout)
        spacer = QWidget()
        spacer.setFixedHeight(20)
        left_layout.addWidget(spacer)
        
        self.tab_widget = QTabWidget()
        left_layout.addWidget(self.tab_widget)
        self.setup_stl_tab()
        self.setup_material_tab()
        self.setup_tool_tab()
        self.setup_cnc_tab()
        self.setup_path_tab()
        self.setup_planning_tab()
        
        self.tab_widget.currentChanged.connect(self.on_tab_changed)  # Added to call set_final_slider_ranges on tab switch

        right_layout = QVBoxLayout()
        main_layout.addLayout(right_layout, 2)
        
        self.stl_viewer = QOpenGLWidget()
        self.stl_viewer.initializeGL = self.initializeGL
        self.stl_viewer.paintGL = self.paintGL
        self.stl_viewer.resizeGL = self.resizeGL
        self.stl_viewer.mousePressEvent = self.mousePressEvent
        self.stl_viewer.mouseMoveEvent = self.mouseMoveEvent
        self.stl_viewer.wheelEvent = self.wheelEvent
        right_layout.addWidget(self.stl_viewer)
        
        # Add path slider and playback controls below STL viewer
        path_control_layout = QHBoxLayout()
        right_layout.addLayout(path_control_layout)
        self.path_slider = QSlider(Qt.Horizontal)
        self.path_slider.setRange(0, 0)  # Initially empty
        self.path_slider.valueChanged.connect(self.on_path_slider_changed)
        path_control_layout.addWidget(self.path_slider)
        
        self.play_button = QPushButton('Play')
        self.play_button.clicked.connect(self.play_path)
        path_control_layout.addWidget(self.play_button)
        
        self.pause_button = QPushButton('Pause')
        self.pause_button.clicked.connect(self.pause_path)
        path_control_layout.addWidget(self.pause_button)
        
        self.stop_button = QPushButton('Stop')
        self.stop_button.clicked.connect(self.stop_path)
        path_control_layout.addWidget(self.stop_button)
        
        unit_selector_layout = QHBoxLayout()
        right_layout.addLayout(unit_selector_layout)
        self.setup_unit_selectors(unit_selector_layout)
        
        self.file_info = QTextEdit()
        self.file_info.setReadOnly(True)
        self.file_info.setFixedHeight(100)
        right_layout.addWidget(self.file_info)
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_pending_tool_update)
        self.timer.start(16)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.stl_viewer.update)
        self.timer.start(16)
        
        self.path_timer = QTimer(self)
        self.path_timer.timeout.connect(self.advance_path)
        
        # After UI is fully initialized, update initial values for handlers
        if hasattr(self.raw_material_handler, 'update_initial_ui_values'):
            self.raw_material_handler.update_initial_ui_values()
        # Ensure tool sliders are initialized for Stepper (XYZAB) mode
        self.cutting_tool_handler.update_tool_sliders_visibility('Stepper (XYZAB)')

    def setup_stl_tab(self):
        stl_tab = QWidget()
        stl_layout = QVBoxLayout()
        stl_tab.setLayout(stl_layout)
        
        button_layout = QHBoxLayout()
        stl_layout.addLayout(button_layout)
        
        load_button = QPushButton('Load STL')
        load_button.clicked.connect(self.stl_handler.load_stl)
        button_layout.addWidget(load_button)
        
        delete_button = QPushButton('Delete Selected')
        delete_button.clicked.connect(self.stl_handler.delete_selected_object)
        button_layout.addWidget(delete_button)
        
            # Add unit selector for STL
        unit_label = QLabel('STL Units:')
        button_layout.addWidget(unit_label)
        
        self.stl_unit_combo = QComboBox()
        self.stl_unit_combo.addItems(['MM', 'CM', 'IN', 'MIL'])
        self.stl_unit_combo.currentTextChanged.connect(self.stl_handler.update_stl_unit)
        self.stl_unit_combo.setCurrentText(self.current_unit)
        button_layout.addWidget(self.stl_unit_combo)
        
        self.stl_list = QListWidget()
        self.stl_list.setFixedHeight(100)
        self.stl_list.itemClicked.connect(self.stl_handler.select_stl)
        stl_layout.addWidget(self.stl_list)
        
        align_buttons_layout = QHBoxLayout()
        stl_layout.addLayout(align_buttons_layout)
        align_axes_button = QPushButton('Align Axes')
        align_axes_button.clicked.connect(self.stl_handler.align_stl_axes)
        align_buttons_layout.addWidget(align_axes_button)
        zero_button = QPushButton('Zero Position')
        zero_button.clicked.connect(self.stl_handler.zero_stl_position)
        align_buttons_layout.addWidget(zero_button)
        snap_button = QPushButton('Snap to Build Plate')
        snap_button.clicked.connect(self.stl_handler.snap_to_build_plate)
        align_buttons_layout.addWidget(snap_button)
        
        self.stl_handler.add_sliders(stl_layout)
        
        render_mode_layout = QHBoxLayout()
        stl_layout.addLayout(render_mode_layout)
        render_mode_group = QButtonGroup(self)
        self.stl_wireframe_button = QRadioButton('Wireframe')
        self.stl_solid_button = QRadioButton('Solid')
        self.stl_solid_button.setChecked(True)  # Default to solid
        render_mode_group.addButton(self.stl_wireframe_button)
        render_mode_group.addButton(self.stl_solid_button)
        self.stl_wireframe_button.toggled.connect(self.stl_handler.change_render_mode)
        render_mode_layout.addWidget(self.stl_wireframe_button)
        render_mode_layout.addWidget(self.stl_solid_button)
        
        self.tab_widget.addTab(stl_tab, "STL Objects")

    def setup_material_tab(self):
        material_tab = QWidget()
        material_layout = QVBoxLayout()
        material_tab.setLayout(material_layout)
        
        self.raw_material_type_group = QButtonGroup(self)
        self.raw_material_stl_button = QRadioButton('Use STL')
        self.raw_material_shape_button = QRadioButton('Use Shape')
        self.raw_material_shape_button.setChecked(True)
        self.raw_material_type_group.addButton(self.raw_material_stl_button)
        self.raw_material_type_group.addButton(self.raw_material_shape_button)
        self.raw_material_stl_button.toggled.connect(self.raw_material_handler.update_raw_material_ui)
        self.raw_material_type_layout = QHBoxLayout()
        self.raw_material_type_layout.addWidget(self.raw_material_stl_button)
        self.raw_material_type_layout.addWidget(self.raw_material_shape_button)
        material_layout.addLayout(self.raw_material_type_layout)
        
        self.material_load_button = QPushButton('Load Material STL')
        self.material_load_button.clicked.connect(self.raw_material_handler.load_material_stl)
        material_layout.addWidget(self.material_load_button)
        self.material_load_button.hide()
        
        material_form = QFormLayout()
        self.material_type_combo = QComboBox()
        self.material_type_combo.addItems(['Rectangular Cube', 'Cylinder'])
        self.material_form_label_type = QLabel('Material Type:')
        material_form.addRow(self.material_form_label_type, self.material_type_combo)
        self.material_type_combo.currentTextChanged.connect(self.raw_material_handler.update_shape_fields)
        
        self.dimension_row_layout = QHBoxLayout()
        material_form.addRow(self.dimension_row_layout)
        
        self.material_diameter = QDoubleSpinBox()
        self.material_diameter.setRange(0.1, 30.0)
        self.material_diameter.setSuffix(' cm')
        self.material_diameter.setValue(10.0)
        self.material_form_label_diameter = QLabel('Diameter:')
        self.material_form_label_diameter.setVisible(False)
        self.material_diameter.hide()
        material_form.addRow(self.material_form_label_diameter, self.material_diameter)
        
        self.material_length = QDoubleSpinBox()
        self.material_length.setRange(0.1, 30.0)
        self.material_length.setSuffix(' cm')
        self.material_form_label_length = QLabel('Length:')
        material_form.addRow(self.material_form_label_length, self.material_length)
        
        self.material_width = QDoubleSpinBox()
        self.material_width.setRange(0.1, 30.0)
        self.material_width.setSuffix(' cm')
        self.material_form_label_width = QLabel('Width:')
        material_form.addRow(self.material_form_label_width, self.material_width)
        
        self.material_height = QDoubleSpinBox()
        self.material_height.setRange(0.1, 30.0)
        self.material_height.setSuffix(' cm')
        self.material_form_label_height = QLabel('Height:')
        material_form.addRow(self.material_form_label_height, self.material_height)
        material_layout.addLayout(material_form)
        
        self.material_length.valueChanged.connect(lambda: self.raw_material_handler.update_material_dimensions('length', self.material_length.value()))
        self.material_width.valueChanged.connect(lambda: self.raw_material_handler.update_material_dimensions('width', self.material_width.value()))
        self.material_height.valueChanged.connect(lambda: self.raw_material_handler.update_material_dimensions('height', self.material_height.value()))
        self.material_diameter.valueChanged.connect(lambda: self.raw_material_handler.update_material_dimensions('diameter', self.material_diameter.value()))
        
        self.raw_material_handler.update_shape_fields()
        
        alignment_buttons_layout = QHBoxLayout()
        material_layout.addLayout(alignment_buttons_layout)
        align_axes_button = QPushButton('Align Axes')
        align_axes_button.clicked.connect(self.raw_material_handler.align_raw_material_axes)
        alignment_buttons_layout.addWidget(align_axes_button)
        zero_button = QPushButton('Zero Position')
        zero_button.clicked.connect(self.raw_material_handler.zero_raw_material_position)
        alignment_buttons_layout.addWidget(zero_button)
        snap_button = QPushButton('Snap to Build Plate')
        snap_button.clicked.connect(self.raw_material_handler.snap_raw_material_to_build_plate)
        alignment_buttons_layout.addWidget(snap_button)
        
        self.raw_material_handler.add_sliders(material_layout)
        self.raw_material_info_label = QLabel("No STL loaded")
        material_layout.addWidget(self.raw_material_info_label)
        self.tab_widget.addTab(material_tab, "Raw Material")

    def setup_tool_tab(self):
        tool_tab = QWidget()
        tool_layout = QVBoxLayout()
        tool_tab.setLayout(tool_layout)
        
        self.tool_type_group = QButtonGroup(self)
        self.tool_stl_button = QRadioButton('Use STL')
        self.tool_shape_button = QRadioButton('Use Shape')
        self.tool_shape_button.setChecked(True)
        self.tool_type_group.addButton(self.tool_stl_button)
        self.tool_type_group.addButton(self.tool_shape_button)
        self.tool_stl_button.toggled.connect(self.cutting_tool_handler.update_tool_ui)
        tool_type_layout = QHBoxLayout()
        tool_type_layout.addWidget(self.tool_stl_button)
        tool_type_layout.addWidget(self.tool_shape_button)
        tool_layout.addLayout(tool_type_layout)
        
        self.load_tool_stl_button = QPushButton('Load Tool STL')
        self.load_tool_stl_button.clicked.connect(self.cutting_tool_handler.load_tool_stl)
        tool_layout.addWidget(self.load_tool_stl_button)
        self.load_tool_stl_button.hide()
        
        self.tool_form = QFormLayout()
        self.tool_type_combo = QComboBox()
        self.tool_type_combo.addItems(['Cylinder', 'Pointed Cylinder'])
        self.tool_type_combo.currentTextChanged.connect(self.cutting_tool_handler.update_tool_type)
        self.tool_form.addRow('Tool Type:', self.tool_type_combo)
        
        self.tool_diameter = QDoubleSpinBox()
        self.tool_diameter.setRange(0.1, 100.0)
        self.tool_diameter.setSuffix(' cm')
        self.tool_diameter.setValue(1.0)
        self.tool_diameter.valueChanged.connect(self.cutting_tool_handler.update_tool_dimensions)
        self.tool_form.addRow('Diameter:', self.tool_diameter)
        
        self.tool_length = QDoubleSpinBox()
        self.tool_length.setRange(0.1, 100.0)
        self.tool_length.setSuffix(' cm')
        self.tool_length.setValue(5.0)
        self.tool_length.valueChanged.connect(self.cutting_tool_handler.update_tool_dimensions)
        self.tool_form.addRow('Length:', self.tool_length)
        
        self.tool_cone_length = QDoubleSpinBox()
        self.tool_cone_length.setRange(0.1, 100.0)
        self.tool_cone_length.setSuffix(' cm')
        self.tool_cone_length.setValue(1.0)
        self.tool_cone_length.valueChanged.connect(self.cutting_tool_handler.update_tool_dimensions)
        self.tool_cone_length_label = QLabel('Cone Length:')
        self.tool_form.addRow(self.tool_cone_length_label, self.tool_cone_length)
        self.tool_cone_length.hide()
        self.tool_cone_length_label.hide()
        
        tool_layout.addLayout(self.tool_form)
        
        self.coord_system_combo = QComboBox()
        self.coord_system_combo.addItems(['Stepper (XYZAB)', 'XYZ + Normal'])
        self.coord_system_combo.currentTextChanged.connect(lambda system: self.cutting_tool_handler.update_tool_sliders_visibility(system))
        tool_layout.addWidget(QLabel('Coordinate System:'))
        tool_layout.addWidget(self.coord_system_combo)
        
        self.cutting_tool_handler.add_sliders(tool_layout)
        
        # Add buttons for appending and inserting current position to path
        path_buttons_layout = QHBoxLayout()
        append_button = QPushButton('Append to Path')
        append_button.clicked.connect(self.append_to_path)
        path_buttons_layout.addWidget(append_button)
        
        insert_button = QPushButton('Insert to Path')
        insert_button.clicked.connect(self.insert_to_path)
        path_buttons_layout.addWidget(insert_button)
        
        tool_layout.addLayout(path_buttons_layout)
        
        tool_render_mode_group = QButtonGroup(self)
        self.tool_wireframe_button = QRadioButton('Wireframe')
        self.tool_solid_button = QRadioButton('Solid')
        self.tool_wireframe_button.setChecked(True)
        tool_render_mode_group.addButton(self.tool_wireframe_button)
        tool_render_mode_group.addButton(self.tool_solid_button)
        self.tool_wireframe_button.toggled.connect(self.cutting_tool_handler.update_tool_render_mode)
        render_mode_layout = QHBoxLayout()
        render_mode_layout.addWidget(self.tool_wireframe_button)
        render_mode_layout.addWidget(self.tool_solid_button)
        tool_layout.addLayout(render_mode_layout)
        self.tab_widget.addTab(tool_tab, "Cutting Tool")

    def setup_cnc_tab(self):
        cnc_tab = QWidget()
        cnc_layout = QVBoxLayout()
        cnc_tab.setLayout(cnc_layout)
        
        # Mechanical Limits Section
        cnc_layout.addWidget(QLabel("Mechanical Limits"))
        limits_layout = QVBoxLayout()
        
        # Min Limits Row
        min_limits_layout = QHBoxLayout()
        min_limits_layout.addWidget(QLabel("Min:"))
        
        self.x_min_limit = QDoubleSpinBox()
        self.y_min_limit = QDoubleSpinBox()
        self.z_min_limit = QDoubleSpinBox()
        self.a_min_limit = QDoubleSpinBox()
        self.b_min_limit = QDoubleSpinBox()
        
        for spinbox in [self.x_min_limit, self.y_min_limit, self.z_min_limit, self.a_min_limit, self.b_min_limit]:
            spinbox.setRange(-1e18, 1e18)  # Remove limits by setting an extremely wide range
            spinbox.setDecimals(4)
            spinbox.setFixedWidth(100)
            spinbox.setSuffix(f" {self.current_unit.lower() if spinbox in [self.x_min_limit, self.y_min_limit, self.z_min_limit] else 'deg'}")
        
        self.x_min_limit.setValue(-30.0)
        self.y_min_limit.setValue(-30.0)
        self.z_min_limit.setValue(0.0)
        self.a_min_limit.setValue(-90.0)
        self.b_min_limit.setValue(0.0)
        
        min_limits_layout.addWidget(QLabel("X:"))
        min_limits_layout.addWidget(self.x_min_limit)
        min_limits_layout.addWidget(QLabel("Y:"))
        min_limits_layout.addWidget(self.y_min_limit)
        min_limits_layout.addWidget(QLabel("Z:"))
        min_limits_layout.addWidget(self.z_min_limit)
        min_limits_layout.addWidget(QLabel("A:"))
        min_limits_layout.addWidget(self.a_min_limit)
        min_limits_layout.addWidget(QLabel("B:"))
        min_limits_layout.addWidget(self.b_min_limit)
        min_limits_layout.addStretch()
        limits_layout.addLayout(min_limits_layout)
        
        # Max Limits Row
        max_limits_layout = QHBoxLayout()
        max_limits_layout.addWidget(QLabel("Max:"))
        
        self.x_max_limit = QDoubleSpinBox()
        self.y_max_limit = QDoubleSpinBox()
        self.z_max_limit = QDoubleSpinBox()
        self.a_max_limit = QDoubleSpinBox()
        self.b_max_limit = QDoubleSpinBox()
        
        for spinbox in [self.x_max_limit, self.y_max_limit, self.z_max_limit, self.a_max_limit, self.b_max_limit]:
            spinbox.setRange(-1e18, 1e18)  # Remove limits by setting an extremely wide range
            spinbox.setDecimals(4)
            spinbox.setFixedWidth(100)
            spinbox.setSuffix(f" {self.current_unit.lower() if spinbox in [self.x_max_limit, self.y_max_limit, self.z_max_limit] else 'deg'}")
        
        self.x_max_limit.setValue(30.0)
        self.y_max_limit.setValue(30.0)
        self.z_max_limit.setValue(30.0)
        self.a_max_limit.setValue(90.0)
        self.b_max_limit.setValue(360.0)
        
        max_limits_layout.addWidget(QLabel("X:"))
        max_limits_layout.addWidget(self.x_max_limit)
        max_limits_layout.addWidget(QLabel("Y:"))
        max_limits_layout.addWidget(self.y_max_limit)
        max_limits_layout.addWidget(QLabel("Z:"))
        max_limits_layout.addWidget(self.z_max_limit)
        max_limits_layout.addWidget(QLabel("A:"))
        max_limits_layout.addWidget(self.a_max_limit)
        max_limits_layout.addWidget(QLabel("B:"))
        max_limits_layout.addWidget(self.b_max_limit)
        max_limits_layout.addStretch()
        limits_layout.addLayout(max_limits_layout)
        
        self.x_min_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.x_max_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.y_min_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.y_max_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.z_min_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.z_max_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.a_min_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.a_max_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.b_min_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        self.b_max_limit.valueChanged.connect(self.cnc_properties_handler.update_limits)
        
        cnc_layout.addLayout(limits_layout)
        
        # Build Plate Offsets Section
        cnc_layout.addWidget(QLabel("Build Plate Offsets"))
        offsets_layout = QHBoxLayout()
        offsets_layout.addWidget(QLabel("Offsets:"))
        
        self.build_x_offset = QDoubleSpinBox()
        self.build_y_offset = QDoubleSpinBox()
        self.build_z_offset = QDoubleSpinBox()
        
        for spinbox in [self.build_x_offset, self.build_y_offset, self.build_z_offset]:
            spinbox.setRange(-1e18, 1e18)  # Remove limits by setting an extremely wide range
            spinbox.setDecimals(4)
            spinbox.setFixedWidth(100)
            spinbox.setSuffix(f" {self.current_unit.lower()}")
            spinbox.setValue(0.0)
        
        offsets_layout.addWidget(QLabel("X:"))
        offsets_layout.addWidget(self.build_x_offset)
        offsets_layout.addWidget(QLabel("Y:"))
        offsets_layout.addWidget(self.build_y_offset)
        offsets_layout.addWidget(QLabel("Z:"))
        offsets_layout.addWidget(self.build_z_offset)
        offsets_layout.addStretch()
        
        self.build_x_offset.valueChanged.connect(self.cnc_properties_handler.update_build_offsets)
        self.build_y_offset.valueChanged.connect(self.cnc_properties_handler.update_build_offsets)
        self.build_z_offset.valueChanged.connect(self.cnc_properties_handler.update_build_offsets)
        
        cnc_layout.addLayout(offsets_layout)
        
        # Keepout Zones Section
        keepout_layout = QVBoxLayout()
        cnc_layout.addWidget(QLabel("Keepout Zones"))
        button_layout = QHBoxLayout()
        load_stl_button = QPushButton('Load STL')
        load_stl_button.clicked.connect(self.cnc_properties_handler.load_keepout_stl)
        button_layout.addWidget(load_stl_button)
        new_shape_button = QPushButton('New Keepout Shape')
        new_shape_button.clicked.connect(self.cnc_properties_handler.new_keepout_shape)
        button_layout.addWidget(new_shape_button)
        delete_button = QPushButton('Delete Selected')
        delete_button.clicked.connect(self.cnc_properties_handler.delete_selected_keepout)
        button_layout.addWidget(delete_button)
        keepout_layout.addLayout(button_layout)
        
        self.keepout_list = QListWidget()
        self.keepout_list.setFixedHeight(100)
        self.keepout_list.itemClicked.connect(self.cnc_properties_handler.select_keepout)
        keepout_layout.addWidget(self.keepout_list)
        
        self.cnc_properties_handler.add_sliders(keepout_layout)
        cnc_layout.addLayout(keepout_layout)
        
        self.tab_widget.addTab(cnc_tab, "CNC Properties")

    def setup_unit_selectors(self, layout):
        translation_unit_label = QLabel("Translation Unit:")
        layout.addWidget(translation_unit_label)
        self.translation_unit_combo = QComboBox()
        self.translation_unit_combo.addItems(['MM', 'CM', 'IN', 'MIL'])
        self.translation_unit_combo.setCurrentText(self.current_unit)
        self.translation_unit_combo.currentTextChanged.connect(self.change_unit)
        layout.addWidget(self.translation_unit_combo)
        
        rotation_unit_label = QLabel("Rotation Unit:")
        layout.addWidget(rotation_unit_label)
        self.rotation_unit_combo = QComboBox()
        self.rotation_unit_combo.addItems(['DEG', 'RAD'])
        self.rotation_unit_combo.setCurrentText(self.rotation_unit)
        self.rotation_unit_combo.currentTextChanged.connect(self.change_rotation_unit)
        layout.addWidget(self.rotation_unit_combo)
        
        zoom_label = QLabel("Zoom:")
        layout.addWidget(zoom_label)
        self.zoom_slider = QSlider(Qt.Horizontal)
        self.zoom_slider.setRange(-3500, 700)
        self.zoom_slider.setValue(int(self.zoom))
        self.zoom_slider.setInvertedAppearance(True)
        self.zoom_slider.setInvertedControls(True)
        self.zoom_slider.valueChanged.connect(self.update_zoom)
        layout.addWidget(self.zoom_slider)
        
        reset_zoom_button = QPushButton('Reset Zoom')
        reset_zoom_button.clicked.connect(self.reset_zoom)
        layout.addWidget(reset_zoom_button)
        
        center_button = QPushButton('Center Selected')
        center_button.clicked.connect(self.center_view)
        layout.addWidget(center_button)
        
        reset_view_button = QPushButton('Reset View')
        reset_view_button.clicked.connect(self.reset_view)
        layout.addWidget(reset_view_button)
        
        layout.addStretch()

    def update_connection_status(self, connected):
        palette = self.connection_status.palette()
        if connected:
            self.connection_status.setText('Connected')
            palette.setColor(QPalette.WindowText, QColor('green'))
        else:
            self.connection_status.setText('Disconnected')
            palette.setColor(QPalette.WindowText, QColor('red'))
        self.connection_status.setPalette(palette)

    def toggle_connection(self):
        if self.cnc.is_connected():
            self.cnc.disconnect()
            self.update_connection_status(False)
        else:
            try:
                self.cnc.connect()
                self.update_connection_status(True)
            except Exception as e:
                print(f"Connection failed: {e}")

    def add_motor_controls(self, layout):
        motor_layout = QVBoxLayout()
        layout.addLayout(motor_layout)
        self.add_axis_control(motor_layout, 'X', 'CM')
        self.add_axis_control(motor_layout, 'Y', 'CM')
        self.add_axis_control(motor_layout, 'Z', 'CM')
        self.add_axis_control(motor_layout, 'A', self.rotation_unit)
        self.add_axis_control(motor_layout, 'B', self.rotation_unit)

    def add_axis_control(self, layout, axis, unit):
        axis_layout = QHBoxLayout()
        layout.addLayout(axis_layout)
        axis_label = QLabel(f'{axis} ({unit}):')
        axis_layout.addWidget(axis_label)
        axis_input = QLineEdit()
        axis_input.setPlaceholderText('Enter distance/angle')
        axis_input.returnPressed.connect(lambda: self.move_motor(axis, axis_input.text(), unit))
        axis_layout.addWidget(axis_input)
        move_button = QPushButton(f'Move {axis}')
        move_button.clicked.connect(lambda: self.move_motor(axis, axis_input.text(), unit))
        axis_layout.addWidget(move_button)

    def move_motor(self, axis, value, unit):
        try:
            value = float(value)
            if axis in ['X', 'Y', 'Z']:
                value = self.helpers.convert_to_cm(value, unit)
            elif axis in ['A', 'B']:
                if unit == 'DEG':
                    value = np.radians(value)
            self.cnc.move_axis(axis, value)
        except ValueError:
            print(f"Invalid input for {axis} axis")

    def center_view(self):
        current_tab = self.tab_widget.currentWidget()
        tab_text = self.tab_widget.tabText(self.tab_widget.currentIndex())
        centered = False
        
        # Initialize last selected if not already set
        if not hasattr(self, 'last_selected_object'):
            self.last_selected_object = None
            self.last_selected_type = None
        
        # Initialize rotation_center if not already set
        if not hasattr(self, 'rotation_center'):
            self.rotation_center = None
        
        if tab_text == "STL Objects" and self.stl_handler.selected_index >= 0:
            stl = self.stl_handler.stl_models[self.stl_handler.selected_index]
            self.translation = [
                -stl['translation'][0] + 10,
                -stl['translation'][1] + 10,
                -stl['translation'][2]
            ]
            # Update rotation center to the object's position
            self.rotation_center = [
                stl['translation'][0],
                stl['translation'][1],
                stl['translation'][2]
            ]
            self.last_selected_object = stl
            self.last_selected_type = "STL"
            centered = True
        elif tab_text == "CNC Properties" and self.cnc_properties_handler.selected_index >= 0:
            keepout = self.cnc_properties_handler.keepout_zones[self.cnc_properties_handler.selected_index]
            self.translation = [
                -keepout['translation'][0] + 10,
                -keepout['translation'][1] + 10,
                -keepout['translation'][2]
            ]
            # Update rotation center to the object's position
            self.rotation_center = [
                keepout['translation'][0],
                keepout['translation'][1],
                keepout['translation'][2]
            ]
            self.last_selected_object = keepout
            self.last_selected_type = "Keepout"
            centered = True
        elif tab_text == "Cutting Tool":
            if self.cutting_tool_handler.cutting_tool:
                current_system = self.coord_system_combo.currentText()
                if current_system == 'XYZ + Normal':
                    translation = self.cutting_tool_handler.cutting_tool['material_translation']
                else:
                    translation = self.cutting_tool_handler.cutting_tool['cnc_translation']
                self.translation = [
                    -translation[0] + 10,
                    -translation[1] + 10,
                    -translation[2]
                ]
                # Update rotation center to the tool's position
                self.rotation_center = [
                    translation[0],
                    translation[1],
                    translation[2]
                ]
                self.last_selected_object = self.cutting_tool_handler.cutting_tool
                self.last_selected_type = "Tool"
                centered = True
        elif tab_text == "Raw Material":
            if self.raw_material_handler.raw_material:
                translation = self.raw_material_handler.raw_material['translation']
                self.translation = [
                    -translation[0] + 10,
                    -translation[1] + 10,
                    -translation[2]
                ]
                # Update rotation center to the raw material's position
                self.rotation_center = [
                    translation[0],
                    translation[1],
                    translation[2]
                ]
                self.last_selected_object = self.raw_material_handler.raw_material
                self.last_selected_type = "RawMaterial"
                centered = True
        
        # Fallback to last selected object if no object is selected on current tab
        if not centered:
            size = self.get_build_plate_size()
            self.translation = [10, 10, 0]
            self.view_rotation = [-60, 0, 30]
            self.rotation_center = [0, 0, 0]
        
        self.stl_viewer.update()

    def reset_view(self):
        self.view_rotation = [-60, 0, 30]
        self.translation = [10, 10, 0]
        self.stl_viewer.update()

    def get_build_plate_size(self):
        return 20.0

    def mousePressEvent(self, event: QMouseEvent):
        local_pos = self.stl_viewer.mapFromGlobal(event.globalPos())
        if not self.stl_viewer.rect().contains(local_pos):
            return
        self.stl_viewer.makeCurrent()  # Make context current for OpenGL calls
        self.mouse_pressed = True
        self.last_pos = event.pos()
 
    def mouseReleaseEvent(self, event: QMouseEvent):
        if self.mouse_pressed:
            self.mouse_pressed = False
            
    def mouseMoveEvent(self, event: QMouseEvent):
        if not self.mouse_pressed:
            return
        dx = event.x() - self.last_pos.x()
        dy = event.y() - self.last_pos.y()
        if event.buttons() & Qt.LeftButton:
            self.view_rotation[2] += dx / 2.0
            self.view_rotation[0] += dy / 2.0
            self.stl_viewer.update()
        if event.buttons() & Qt.RightButton:
            zoom_factor = self.zoom / 30.0
            pan_speed = zoom_factor / 10.0
            cosx = math.cos(math.radians(self.view_rotation[0]))
            sinx = math.sin(math.radians(self.view_rotation[0]))
            cosy = math.cos(math.radians(self.view_rotation[1]))
            siny = math.sin(math.radians(self.view_rotation[1]))
            cosz = math.cos(math.radians(self.view_rotation[2]))
            sinz = math.sin(math.radians(self.view_rotation[2]))
            camera_right_x = cosy * cosz - siny * sinx * sinz
            camera_right_y = cosy * sinz + siny * sinx * cosz
            camera_right_z = -siny * cosx
            camera_up_x = -cosx * sinz
            camera_up_y = cosx * cosz
            camera_up_z = sinx
            self.translation[0] += (dx * camera_right_x + dy * camera_up_x) * pan_speed
            self.translation[1] -= (dx * camera_right_y + dy * camera_up_y) * pan_speed
            self.translation[2] += (dx * camera_right_z + dy * camera_up_z) * pan_speed
            self.stl_viewer.update()
        self.last_pos = event.pos()

    def update_zoom(self, value):
        self.zoom = 30.0*np.pow(10.0, (float(value)/1000.0))
        self.stl_viewer.update()

    def reset_zoom(self):
        self.zoom = 30.0
        self.zoom_slider.setValue(0)
        self.stl_viewer.update()

    def wheelEvent(self, event: QWheelEvent):
        local_pos = self.stl_viewer.mapFromGlobal(event.globalPos())
        if not self.stl_viewer.rect().contains(local_pos):
            return
        delta = event.angleDelta().y() / 120.0
        zoom_factor = self.zoom / 30.0
        adjusted_zoom_factor = max(0.5, zoom_factor ** 0.7)
        adjusted_delta = delta * adjusted_zoom_factor
        current_log_value = np.log10(self.zoom / 30.0) * 1000.0
        new_log_value = current_log_value + adjusted_delta * 10.0
        self.zoom = 30.0 * np.power(10.0, new_log_value / 1000.0)
        self.zoom = max(0.01, min(150.0, self.zoom))
        self.zoom_slider.setValue(int(new_log_value))
        self.stl_viewer.update()

    def initializeGL(self):
        glutInit(sys.argv)  # Initialize GLUT to fix the error with glutBitmapCharacter
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glLightfv(GL_LIGHT0, GL_POSITION, [1.0, 1.0, 1.0, 0.0])
        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.1, 0.1, 0.1, 1.0])
        glLightfv(GL_LIGHT0, GL_DIFFUSE, [5.0, 5.0, 5.0, 1.0])
        glLightfv(GL_LIGHT0, GL_SPECULAR, [5.0, 5.0, 5.0, 1.0])
        glEnable(GL_COLOR_MATERIAL)
        glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE)
        glMaterialfv(GL_FRONT, GL_SPECULAR, [1.0, 1.0, 1.0, 1.0])
        glMaterialf(GL_FRONT, GL_SHININESS, 128.0)
        # Set the wireframe pending flag to ensure raw material wireframe is created during paintGL
        if self.raw_material_handler.raw_material:
            self.raw_material_handler.raw_material['wireframe_pending'] = True
            self.raw_material_handler.raw_material['wireframe_type'] = 'rectangular'
        self.cutting_tool_handler.create_tool_display_lists()

    def paintGL(self):
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(self.zoom, self.stl_viewer.width() / self.stl_viewer.height(), 0.1, 1000.0)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        glTranslatef(0.0, 0.0, -100.0)
        size = self.get_build_plate_size()
        glTranslatef(-size / 2.0, -size / 2.0, 0)
        glPushMatrix()
        glTranslatef(size / 2.0, size / 2.0, 0.0)
        glRotatef(self.view_rotation[0], 1, 0, 0)
        glRotatef(self.view_rotation[1], 0, 1, 0)
        glRotatef(self.view_rotation[2], 0, 0, 1)
        glTranslatef(-size / 2.0, -size / 2.0, 0.0)
        glTranslatef(self.translation[0], self.translation[1], self.translation[2])
        glDisable(GL_LIGHTING)
        self.draw_build_plate()
        
        if hasattr(self.raw_material_handler, 'create_deferred_wireframe'):
            self.raw_material_handler.create_deferred_wireframe()
        
        if self.raw_material_handler.raw_material and self.raw_material_handler.raw_material.get('wireframe_list'):
            glPushMatrix()
            mode = self.raw_material_handler.rotation_type_combo.currentText()
            if mode == 'Euler':
                glTranslatef(self.raw_material_handler.raw_material['translation'][0],
                             self.raw_material_handler.raw_material['translation'][1],
                             self.raw_material_handler.raw_material['translation'][2])
                glRotatef(self.raw_material_handler.raw_material['rotation'][2], 0, 0, 1)
                glRotatef(self.raw_material_handler.raw_material['rotation'][1], 0, 1, 0)
                glRotatef(self.raw_material_handler.raw_material['rotation'][0], 1, 0, 0)
            else:
                glTranslatef(self.raw_material_handler.raw_material['translation'][0],
                             self.raw_material_handler.raw_material['translation'][1],
                             self.raw_material_handler.raw_material['translation'][2])
                q = self.raw_material_handler.raw_material['quaternion']
                w, x, y, z = q
                w = max(min(w, 1.0), -1.0)
                angle = 2.0 * np.degrees(np.acos(w))
                if abs(angle) > 0.0001:
                    s = np.sqrt(1.0 - w * w)
                    axis_x = x / s if s != 0 else 0
                    axis_y = y / s if s != 0 else 0
                    axis_z = z / s if s != 0 else 0
                    glRotatef(angle, axis_x, axis_y, axis_z)
            glCallList(self.raw_material_handler.raw_material['wireframe_list'])
            glPopMatrix()
        
        for i, stl in enumerate(self.stl_handler.stl_models):
            glPushMatrix()
            mode = self.stl_handler.rotation_type_combo.currentText()
            if mode == 'Euler':
                unit = stl.get('unit', 'MM')
                user_scale = stl['scale']
                # Translate to the object's position
                glTranslatef(stl['translation'][0], stl['translation'][1], stl['translation'][2])
                # Move to centroid for rotation (centroid should be in CM for consistency)
                centroid = stl['centroid']
                glTranslatef(centroid[0], centroid[1], centroid[2])
                # Apply scaling
                glScalef(user_scale, user_scale, user_scale)
                # Apply rotations around the centroid
                glRotatef(stl['rotation'][2], 0, 0, 1)
                glRotatef(stl['rotation'][1], 0, 1, 0)
                glRotatef(stl['rotation'][0], 1, 0, 0)
                # Translate back from centroid
                glTranslatef(-centroid[0], -centroid[1], -centroid[2])
                
            else:
                # Similar adjustments for quaternion-based rendering
                unit = stl.get('unit', 'MM')
                user_scale = stl['scale']
                glTranslatef(stl['translation'][0], stl['translation'][1], stl['translation'][2])
                centroid = stl['centroid']
                glTranslatef(centroid[0], centroid[1], centroid[2])
                glScalef(user_scale, user_scale, user_scale)
                q = stl['quaternion']
                w, x, y, z = q
                w = max(min(w, 1.0), -1.0)
                angle = 2.0 * np.degrees(np.acos(w))
                if abs(angle) > 0.0001:
                    s = np.sqrt(1.0 - w * w)
                    axis_x = x / s if s != 0 else 0
                    axis_y = y / s if s != 0 else 0
                    axis_z = z / s if s != 0 else 0
                    glRotatef(angle, axis_x, axis_y, axis_z)
                glTranslatef(-centroid[0], -centroid[1], -centroid[2])
            if i == self.stl_handler.selected_index:
                glColor3f(0.5, 0.5, 0.0)
            else:
                glColor3f(0.5, 0.5, 0.5)
            if self.stl_handler.render_modes[i] == 'wireframe':
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
                glDisable(GL_LIGHTING)
                glLineWidth(2.0)
                glCallList(stl['wireframe_list'])
            else:
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                glEnable(GL_LIGHTING)
                glCallList(stl['display_list'])
                glDisable(GL_LIGHTING)
                glColor3f(0.1, 0.1, 0.1)
                glLineWidth(2.0)
                glCallList(stl['wireframe_list'])
            glPopMatrix()
        
        if self.stl_handler.selected_index >= 0:
            selected_stl = self.stl_handler.stl_models[self.stl_handler.selected_index]
            glPushMatrix()
            mode = self.stl_handler.rotation_type_combo.currentText()
            if mode == 'Euler':
                glTranslatef(selected_stl['translation'][0], selected_stl['translation'][1], selected_stl['translation'][2])
                centroid = selected_stl['centroid']
                glTranslatef(centroid[0], centroid[1], centroid[2])
                user_scale = selected_stl['scale']
                glScalef(user_scale, user_scale, user_scale)
                glRotatef(selected_stl['rotation'][2], 0, 0, 1)
                glRotatef(selected_stl['rotation'][1], 0, 1, 0)
                glRotatef(selected_stl['rotation'][0], 1, 0, 0)
                # Do NOT translate back from centroid for the triad, keep it centered at the centroid
               
            # Similar logic for quaternion mode
            else:
                unit = selected_stl.get('unit', 'MM')
                conversion_factor = self.helpers.convert_to_cm(1.0, unit)
                glTranslatef(selected_stl['translation'][0], selected_stl['translation'][1], selected_stl['translation'][2])
                centroid = stl['centroid']
                glTranslatef(centroid[0], centroid[1], centroid[2])
                base_scale = selected_stl.get('base_scale', 1.0)
                user_scale = selected_stl['scale']
                glScalef(user_scale, user_scale, user_scale)
                q = selected_stl['quaternion']
                w, x, y, z = q
                w = max(min(w, 1.0), -1.0)
                angle = 2.0 * np.degrees(np.acos(w))
                if abs(angle) > 0.0001:
                    s = np.sqrt(1.0 - w * w)
                    axis_x = x / s if s != 0 else 0
                    axis_y = y / s if s != 0 else 0
                    axis_z = z / s if s != 0 else 0
                    glRotatef(angle, axis_x, axis_y, axis_z)
                # Do NOT translate back from centroid for the triad
                
            glLineWidth(6.0)
            self.draw_triad(5.0)
            glPopMatrix()
        
        self.draw_cutting_tool()
        
        # Draw Keepout Zones with scaling applied
        for i, keepout in enumerate(self.cnc_properties_handler.keepout_zones):
            glPushMatrix()
            glTranslatef(keepout['translation'][0], keepout['translation'][1], keepout['translation'][2])
            glScalef(keepout['scale'], keepout['scale'], keepout['scale'])
            mode = self.cnc_properties_handler.rotation_type_combo.currentText()
            if mode == 'Euler':
                glRotatef(keepout['rotation'][2], 0, 0, 1)
                glRotatef(keepout['rotation'][1], 0, 1, 0)
                glRotatef(keepout['rotation'][0], 1, 0, 0)
            else:
                if 'quaternion' in keepout:
                    q = keepout['quaternion']
                    w, x, y, z = q
                    w = max(min(w, 1.0), -1.0)
                    angle = 2.0 * np.degrees(np.acos(w))
                    if abs(angle) > 0.0001:
                        s = np.sqrt(1.0 - w * w)
                        axis_x = x / s if s != 0 else 0
                        axis_y = y / s if s != 0 else 0
                        axis_z = z / s if s != 0 else 0
                        glRotatef(angle, axis_x, axis_y, axis_z)
            if i == self.cnc_properties_handler.selected_index:
                glColor3f(1.0, 0.0, 0.0)  # Bright red for selected
            else:
                glColor3f(0.5, 0.0, 0.0)  # Dim red for unselected
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
            glDisable(GL_LIGHTING)
            glLineWidth(2.0)
            if 'wireframe_list' in keepout:
                glCallList(keepout['wireframe_list'])
            glPopMatrix()
        
        # Draw Planning Visualizations
        if self.cut_volume_stl and self.toggle_cut_volume.isChecked():
            glPushMatrix()
            glColor3f(0.0, 1.0, 1.0)  # Cyan for cut volume
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
            glEnable(GL_LIGHTING)
            glCallList(self.cut_volume_stl['display_list'])
            glDisable(GL_LIGHTING)
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
            glColor3f(0.1, 0.1, 0.1)
            glLineWidth(2.0)
            glCallList(self.cut_volume_stl['wireframe_list'])
            glPopMatrix()
        
        if self.unreachable_stl and self.toggle_unreachable.isChecked():
            glPushMatrix()
            glColor3f(1.0, 0.0, 0.0)  # Red for unreachable areas
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
            glEnable(GL_LIGHTING)
            glCallList(self.unreachable_stl['display_list'])
            glDisable(GL_LIGHTING)
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
            glColor3f(0.1, 0.1, 0.1)
            glLineWidth(2.0)
            glCallList(self.unreachable_stl['wireframe_list'])
            glPopMatrix()
        
        if self.path_handler.path_points and self.toggle_tool_path.isChecked():
            glPushMatrix()
            glColor3f(0.0, 0.75, 0.0)  # Green for tool path
            glLineWidth(1.0)
            glBegin(GL_LINE_STRIP)
            for point in self.path_handler.path_points:
                xyz_normal = point['xyz_normal']
                glVertex3f(xyz_normal['x'], xyz_normal['y'], xyz_normal['z'])
            glEnd()
            glPopMatrix()
        
        glPopMatrix()
        
        # Draw visual indicator for intersection and cutting state
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, self.stl_viewer.width(), 0, self.stl_viewer.height(), -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        glDisable(GL_DEPTH_TEST)  # Disable depth test for 2D overlay
        inside_raw_material = self.cutting_tool_handler.check_tool_inside_raw_material()
        if self.intersection_occurred:
            glColor3f(1.0, 0.0, 0.0)  # Red
            text = b"Intersection"
        elif inside_raw_material:
            glColor3f(1.0, 0.5, 0.0)  # Orange
            text = b"Cutting"
        else:
            glColor3f(0.0, 1.0, 0.0)  # Green
            text = b"Okay"
        glRasterPos2f(10, self.stl_viewer.height() - 20)  # Position at bottom left
        for char in text:
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, char)  # Now defined
        glEnable(GL_DEPTH_TEST)
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)

    def resizeGL(self, width, height):
        glViewport(0, 0, width, height)

    def draw_triad(self, size=10.0):
        glColor3f(1.0, 0.0, 0.0)
        glBegin(GL_LINES)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(size, 0.0, 0.0)
        glEnd()
        glColor3f(0.0, 1.0, 0.0)
        glBegin(GL_LINES)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, size, 0.0)
        glEnd()
        glColor3f(0.0, 0.0, 1.0)
        glBegin(GL_LINES)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, size)
        glEnd()

    def draw_build_plate(self):
        size = self.get_build_plate_size()
        zoom_threshold = 5.0
        zoom_threshold2 = 0.5
        zoom_threshold3 = 0.05
        
        if self.current_unit == 'MM' or self.current_unit == 'CM':
            if self.zoom < zoom_threshold3:
                grid_size = size / 20000
                coarse_grid_size = size / 2000
            elif self.zoom < zoom_threshold2:
                grid_size = size / 2000
                coarse_grid_size = size / 200
            elif self.zoom < zoom_threshold:
                grid_size = size / 200
                coarse_grid_size = size / 20
            else:
                grid_size = size / 20
                coarse_grid_size = size / 20
        elif self.current_unit == 'IN' or self.current_unit == 'MIL':
            if self.zoom < zoom_threshold3:
                grid_size = size / 7874.0157480315
                coarse_grid_size = size / 787.40157480315
            elif self.zoom < zoom_threshold2:
                grid_size = size / 787.40157480315
                coarse_grid_size = size / 78.740157480315
            elif self.zoom < zoom_threshold:
                grid_size = size / 78.740157480315
                coarse_grid_size = size / 7.8740157480315
            else:
                grid_size = size / 7.8740157480315
                coarse_grid_size = size / 7.8740157480315

        # Draw the build plate grid with offsets
        glPushMatrix()
        glTranslatef(self.cnc_properties_handler.build_offsets[0], 
                     self.cnc_properties_handler.build_offsets[1], 
                     self.cnc_properties_handler.build_offsets[2])
        glColor3f(0.3, 0.3, 0.3)
        glLineWidth(3.0)
        glBegin(GL_LINES)
        for x in range(int(-size/coarse_grid_size), int(size/coarse_grid_size) + 1):
            glVertex3f(x * coarse_grid_size, -size, 0)
            glVertex3f(x * coarse_grid_size, size, 0)
        for y in range(int(-size/coarse_grid_size), int(size/coarse_grid_size) + 1):
            glVertex3f(-size, y * coarse_grid_size, 0)
            glVertex3f(size, y * coarse_grid_size, 0)
        glEnd()
        glLineWidth(1.0)
        glBegin(GL_LINES)
        for x in range(int(-size/grid_size), int(size/grid_size) + 1):
            if x * grid_size % coarse_grid_size != 0:
                glVertex3f(x * grid_size, -size, 0)
                glVertex3f(x * grid_size, size, 0)
        for y in range(int(-size/grid_size), int(size/grid_size) + 1):
            if y * grid_size % coarse_grid_size != 0:
                glVertex3f(-size, y * grid_size, 0)
                glVertex3f(size, y * grid_size, 0)
        glEnd()
        glPopMatrix()

        # Draw the triad at the origin without offsets
        triad_intensity = 0.7 if self.stl_handler.selected_index >= 0 else 1.0
        glLineWidth(5.0)
        glBegin(GL_LINES)
        glColor3f(1.0 * triad_intensity, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(size/2, 0.0, 0.0)
        glColor3f(0.0, 1.0 * triad_intensity, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, size/2, 0.0)
        glColor3f(0.0, 0.0, 1.0 * triad_intensity)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, size/2)
        glEnd()

    def draw_cutting_tool(self):
        glPushMatrix()
        
        current_system = self.coord_system_combo.currentText()
        if current_system == 'XYZ + Normal':
            # translate first when using normals
            glTranslatef(self.cutting_tool_handler.cutting_tool['material_translation'][0], 
                         self.cutting_tool_handler.cutting_tool['material_translation'][1], 
                         self.cutting_tool_handler.cutting_tool['material_translation'][2])
            x, y, z = self.cutting_tool_handler.cutting_tool['material_translation']
            nx, ny, nz = self.cutting_tool_handler.cutting_tool['rotation']
            a_deg = self.cutting_tool_handler.cutting_tool['ab_rotation'][0]
            b_deg = self.cutting_tool_handler.cutting_tool['ab_rotation'][1]
            elbowUp = a_deg >= 0.0
            # Compute rotation to align tool with normal vector
            # Default tool orientation is along Z-axis (0,0,1)
            # We need to rotate to match the normal vector (nx, ny, nz) in build plate frame
            if abs(nz) < 0.999999:  # Avoid gimbal lock or extreme cases
                # Compute yaw (rotation around Y) to align with X-Z plane projection
                self.planning_handler.material_to_cnc(x, y, z, nx, ny, nz, b_deg, elbowUp)
                yaw = self.cutting_tool_handler.cutting_tool['ab_rotation'][1]
                pitch = self.cutting_tool_handler.cutting_tool['ab_rotation'][0]
                #yaw = np.degrees(np.arctan2(nx, nz))
                # Compute pitch (rotation around X) to align with the normal's Y component
                #pitch = np.degrees(np.arctan2(-ny, np.sqrt(nx*nx + nz*nz)))
            else:
                yaw = b_deg
                pitch = 0.0  # Straight up, no rotation needed
            # Apply rotations in the correct order: yaw then pitch
            glRotatef(yaw, 0, 0, -1)  # Rotate around Y-axis for yaw
            glRotatef(pitch, -1, 0, 0)  # Then rotate around X-axis for pitch
        else:
            # Apply B rotation (around Z axis) first, as it spins the build plate
            glRotatef(self.cutting_tool_handler.cutting_tool['ab_rotation'][1], 0, 0, -1)
            # Then apply A rotation (around X axis) to tilt the tool
            glRotatef(self.cutting_tool_handler.cutting_tool['ab_rotation'][0], -1, 0, 0)
            # Apply the translation to position the tool in world space    
            glTranslatef(self.cutting_tool_handler.cutting_tool['cnc_translation'][0], 
                         self.cutting_tool_handler.cutting_tool['cnc_translation'][1], 
                         self.cutting_tool_handler.cutting_tool['cnc_translation'][2])
        
        if self.cutting_tool_handler.cutting_tool['stl_model']:
            if self.cutting_tool_handler.cutting_tool['render_mode'] == 'wireframe':
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
                glDisable(GL_LIGHTING)
                glColor3f(0.8, 0.2, 0.2)
                glLineWidth(2.0)
                glCallList(self.cutting_tool_handler.cutting_tool['wireframe_list'])
            else:
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                glEnable(GL_LIGHTING)
                glColor3f(0.8, 0.2, 0.2)
                glCallList(self.cutting_tool_handler.cutting_tool['display_list'])
                glDisable(GL_LIGHTING)
                glColor3f(0.1, 0.1, 0.1)
                glLineWidth(2.0)
                glCallList(self.cutting_tool_handler.cutting_tool['wireframe_list'])
        else:
            if self.cutting_tool_handler.cutting_tool['render_mode'] == 'wireframe':
                glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
                glDisable(GL_LIGHTING)
                glLineWidth(2.0)
                glCallList(self.cutting_tool_handler.cutting_tool['wireframe_list'])
            else:
                glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)
                glEnable(GL_LIGHTING)
                glColor3f(0.8, 0.2, 0.2)
                glCallList(self.cutting_tool_handler.cutting_tool['display_list'])
        
        glDisable(GL_LIGHTING)
        glLineWidth(1.0)
       
        self.draw_triad(2.5)
        glPopMatrix()
        self.cutting_tool_handler.check_tool_keepout_intersection()

    def update_sliders(self):
        self.stl_handler.update_sliders()

    def change_unit(self, unit):
        original_translations = {}
        if self.stl_handler.selected_index >= 0:
            original_translations['stl'] = self.stl_handler.stl_models[self.stl_handler.selected_index]['translation'].copy()
        if self.raw_material_handler.raw_material:
            original_translations['raw'] = self.raw_material_handler.raw_material['translation'].copy()
        if self.cutting_tool_handler.cutting_tool:
            current_system = self.coord_system_combo.currentText()
            if current_system == 'XYZ + Normal':
                original_translations['tool'] = self.cutting_tool_handler.cutting_tool['material_translation'].copy()
            else:
                original_translations['tool'] = self.cutting_tool_handler.cutting_tool['cnc_translation'].copy()
        if self.cnc_properties_handler.selected_index >= 0:
            original_translations['keepout'] = self.cnc_properties_handler.keepout_zones[self.cnc_properties_handler.selected_index]['translation'].copy()
        
        self.current_unit = unit
        
        self.inflate_slider_ranges()
        self.update_slider_values(unit)
        self.set_final_slider_ranges(unit)
        
        if self.stl_handler.selected_index >= 0 and 'stl' in original_translations:
            self.stl_handler.stl_models[self.stl_handler.selected_index]['translation'] = original_translations['stl']
        if self.raw_material_handler.raw_material and 'raw' in original_translations:
            self.raw_material_handler.raw_material['translation'] = original_translations['raw']
        if self.cutting_tool_handler.cutting_tool and 'tool' in original_translations:
            current_system = self.coord_system_combo.currentText()
            if current_system == 'XYZ + Normal':
                self.cutting_tool_handler.cutting_tool['material_translation'] = original_translations['tool']
            else:
                self.cutting_tool_handler.cutting_tool['cnc_translation'] = original_translations['tool']
        if self.cnc_properties_handler.selected_index >= 0 and 'keepout' in original_translations:
            self.cnc_properties_handler.keepout_zones[self.cnc_properties_handler.selected_index]['translation'] = original_translations['keepout']
        
        if self.raw_material_handler.raw_material:
            suffix = self.get_unit_suffix(unit)
            self.material_length.setSuffix(suffix)
            self.material_width.setSuffix(suffix)
            self.material_height.setSuffix(suffix)
            self.material_diameter.setSuffix(suffix)
            self.tool_diameter.setSuffix(suffix)
            self.tool_length.setSuffix(suffix)
            self.tool_cone_length.setSuffix(suffix)
            self.x_min_limit.setSuffix(suffix)
            self.x_max_limit.setSuffix(suffix)
            self.y_min_limit.setSuffix(suffix)
            self.y_max_limit.setSuffix(suffix)
            self.z_min_limit.setSuffix(suffix)
            self.z_max_limit.setSuffix(suffix)
            self.build_x_offset.setSuffix(suffix)
            self.build_y_offset.setSuffix(suffix)
            self.build_z_offset.setSuffix(suffix)
            temp_max = 1000000.0
            self.material_length.setRange(0.0, temp_max)
            self.material_width.setRange(0.0, temp_max)
            self.material_height.setRange(0.0, temp_max)
            self.material_diameter.setRange(0.0, temp_max)
            self.update_raw_material_dimensions_display(unit)
            self.update_spinbox_ranges(unit)
            self.cnc_properties_handler.update_limits_display(unit)
            self.cnc_properties_handler.update_keepout_dimensions_display(unit)  # Corrected to pass unit parameter
            self.cnc_properties_handler.update_build_offsets_display(unit)
            if self.material_type_combo.currentText() == 'Cylinder':
                self.raw_material_handler.create_cylinder_wireframe()
            else:
                self.raw_material_handler.create_raw_material_wireframe()
        
        # Recreate wireframes for keepout zones after unit change
        for keepout in self.cnc_properties_handler.keepout_zones:
            if keepout['type'] == 'shape':
                scaled_dimensions = [dim * keepout.get('scale', 1.0) for dim in keepout['dimensions']]
                if 'wireframe_list' in keepout:
                    glDeleteLists(keepout['wireframe_list'], 1)
                keepout['wireframe_list'] = self.cnc_properties_handler.create_keepout_shape_wireframe(*scaled_dimensions)
        
        self.stl_viewer.update()

    def inflate_slider_ranges(self):
        wide_range = (-1000000, 1000000)
        self.x_slider.setRange(*wide_range)
        self.y_slider.setRange(*wide_range)
        self.z_slider.setRange(*wide_range)
        self.raw_x_slider.setRange(*wide_range)
        self.raw_y_slider.setRange(*wide_range)
        self.raw_z_slider.setRange(*wide_range)
        self.tool_x_slider.setRange(*wide_range)
        self.tool_y_slider.setRange(*wide_range)
        self.tool_z_slider.setRange(*wide_range)
        self.cnc_properties_handler.keepout_x_slider.setRange(*wide_range)
        self.cnc_properties_handler.keepout_y_slider.setRange(*wide_range)
        self.cnc_properties_handler.keepout_z_slider.setRange(*wide_range)

    def update_slider_values(self, unit):
        scaling_factor = 10000.0 if self.current_unit in ['IN', 'CM'] else 1000.0 if self.current_unit == 'MM' else 10.0
        if self.stl_handler.selected_index >= 0:
            stl = self.stl_handler.stl_models[self.stl_handler.selected_index]
            x_val = self.helpers.convert_from_cm(stl['translation'][0], unit)
            y_val = self.helpers.convert_from_cm(stl['translation'][1], unit)
            z_val = self.helpers.convert_from_cm(stl['translation'][2], unit)
            self.x_slider.blockSignals(True)
            self.y_slider.blockSignals(True)
            self.z_slider.blockSignals(True)
            self.x_slider.setValue(int(round(x_val*scaling_factor)))
            self.y_slider.setValue(int(round(y_val*scaling_factor)))
            self.z_slider.setValue(int(round(z_val*scaling_factor)))
            self.x_slider.blockSignals(False)
            self.y_slider.blockSignals(False)
            self.z_slider.blockSignals(False)
            self.x_entry.setText(f"{x_val:.4f}" if unit == 'IN' else f"{x_val:.2f}")
            self.y_entry.setText(f"{y_val:.4f}" if unit == 'IN' else f"{y_val:.2f}")
            self.z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")
        if self.raw_material_handler.raw_material:
            x_val = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['translation'][0], unit)
            y_val = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['translation'][1], unit)
            z_val = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['translation'][2], unit)
            self.raw_x_slider.blockSignals(True)
            self.raw_y_slider.blockSignals(True)
            self.raw_z_slider.blockSignals(True)
            self.raw_x_slider.setValue(int(round(x_val*scaling_factor)))
            self.raw_y_slider.setValue(int(round(y_val*scaling_factor)))
            self.raw_z_slider.setValue(int(round(z_val*scaling_factor)))
            self.raw_x_slider.blockSignals(False)
            self.raw_y_slider.blockSignals(False)
            self.raw_z_slider.blockSignals(False)
            self.raw_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' else f"{x_val:.2f}")
            self.raw_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' else f"{y_val:.2f}")
            self.raw_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")
        if self.cutting_tool_handler.cutting_tool:
            current_system = self.coord_system_combo.currentText()
            if current_system == 'XYZ + Normal':
                x_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][2], unit)
            else:  # Stepper (XYZAB)
                x_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][2], unit)
            self.tool_x_slider.blockSignals(True)
            self.tool_y_slider.blockSignals(True)
            self.tool_z_slider.blockSignals(True)
            self.tool_x_slider.setValue(int(round(x_val*scaling_factor)))
            self.tool_y_slider.setValue(int(round(y_val*scaling_factor)))
            self.tool_z_slider.setValue(int(round(z_val*scaling_factor)))
            self.tool_x_slider.blockSignals(False)
            self.tool_y_slider.blockSignals(False)
            self.tool_z_slider.blockSignals(False)
            self.tool_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' else f"{x_val:.2f}")
            self.tool_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' else f"{y_val:.2f}")
            self.tool_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")
        if self.cnc_properties_handler.selected_index >= 0:
            keepout = self.cnc_properties_handler.keepout_zones[self.cnc_properties_handler.selected_index]
            x_val = self.helpers.convert_from_cm(keepout['translation'][0], unit)
            y_val = self.helpers.convert_from_cm(keepout['translation'][1], unit)
            z_val = self.helpers.convert_from_cm(keepout['translation'][2], unit)
            self.cnc_properties_handler.keepout_x_slider.blockSignals(True)
            self.cnc_properties_handler.keepout_y_slider.blockSignals(True)
            self.cnc_properties_handler.keepout_z_slider.blockSignals(True)
            self.cnc_properties_handler.keepout_x_slider.setValue(int(round(x_val*scaling_factor)))
            self.cnc_properties_handler.keepout_y_slider.setValue(int(round(y_val*scaling_factor)))
            self.cnc_properties_handler.keepout_z_slider.setValue(int(round(z_val*scaling_factor)))
            self.cnc_properties_handler.keepout_x_slider.blockSignals(False)
            self.cnc_properties_handler.keepout_y_slider.blockSignals(False)
            self.cnc_properties_handler.keepout_z_slider.blockSignals(False)
            self.cnc_properties_handler.keepout_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' else f"{x_val:.2f}")
            self.cnc_properties_handler.keepout_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' else f"{y_val:.2f}")
            self.cnc_properties_handler.keepout_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")

    def set_final_slider_ranges(self, unit):
        scaling_factor = 10000.0 if self.current_unit in ['IN', 'CM'] else 1000.0 if self.current_unit == 'MM' else 10.0
        limits = self.cnc_properties_handler.limits
        
        if unit == 'MM' or unit == 'CM':
            base_range_x = (-300000, 300000)  # Original ranges for other sliders
            base_range_y = (-300000, 300000)
            base_range_z = (-300000, 300000)
        elif unit == 'IN' or unit == 'MIL':
            base_range_x = (-120000, 120000)
            base_range_y = (-120000, 120000)
            base_range_z = (-120000, 120000)
        
        self.x_slider.setRange(*base_range_x)  # Unchanged for STL
        self.y_slider.setRange(*base_range_y)
        self.z_slider.setRange(*base_range_z)
        self.raw_x_slider.setRange(*base_range_x)  # Unchanged for raw material
        self.raw_y_slider.setRange(*base_range_y)
        self.raw_z_slider.setRange(*base_range_y)  # Note: Original code has raw_z_slider range as base_range_y, assuming typo in provided code
        self.cnc_properties_handler.keepout_x_slider.setRange(*base_range_x)  # Unchanged for keepout
        self.cnc_properties_handler.keepout_y_slider.setRange(*base_range_y)
        self.cnc_properties_handler.keepout_z_slider.setRange(*base_range_z)
        
        current_system = self.coord_system_combo.currentText()
        if current_system == 'Stepper (XYZAB)':
            tool_range_x = (int(self.helpers.convert_from_cm(limits['x_min'], self.current_unit) * scaling_factor), int(self.helpers.convert_from_cm(limits['x_max'], self.current_unit) * scaling_factor))
            tool_range_y = (int(self.helpers.convert_from_cm(limits['y_min'], self.current_unit )* scaling_factor), int(self.helpers.convert_from_cm(limits['y_max'], self.current_unit) * scaling_factor))
            tool_range_z = (int(self.helpers.convert_from_cm(limits['z_min'], self.current_unit) * scaling_factor), int(self.helpers.convert_from_cm(limits['z_max'], self.current_unit) * scaling_factor))
            self.tool_x_slider.setRange(*tool_range_x)
            self.tool_y_slider.setRange(*tool_range_y)
            self.tool_z_slider.setRange(*tool_range_z)
        else:
            self.tool_x_slider.setRange(*base_range_x)  # Original default ranges
            self.tool_y_slider.setRange(*base_range_y)
            self.tool_z_slider.setRange(*base_range_z)
        
        if self.stl_handler.selected_index >= 0:
            stl = self.stl_handler.stl_models[self.stl_handler.selected_index]
            x_val = self.helpers.convert_from_cm(stl['translation'][0], unit)
            y_val = self.helpers.convert_from_cm(stl['translation'][1], unit)
            z_val = self.helpers.convert_from_cm(stl['translation'][2], unit)
            self.x_slider.blockSignals(True)
            self.y_slider.blockSignals(True)
            self.z_slider.blockSignals(True)
            clamped_x = max(self.x_slider.minimum(), min(self.x_slider.maximum(), x_val * scaling_factor))
            clamped_y = max(self.y_slider.minimum(), min(self.y_slider.maximum(), y_val * scaling_factor))
            clamped_z = max(self.z_slider.minimum(), min(self.z_slider.maximum(), z_val * scaling_factor))
            self.x_slider.setValue(int(round(clamped_x)))
            self.y_slider.setValue(int(round(clamped_y)))
            self.z_slider.setValue(int(round(clamped_z)))
            self.x_slider.blockSignals(False)
            self.y_slider.blockSignals(False)
            self.z_slider.blockSignals(False)
            self.x_entry.setText(f"{x_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{x_val:.3f}" if unit == 'MM' else f"{x_val:.1f}")
            self.y_entry.setText(f"{y_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{y_val:.3f}" if unit == 'MM' else f"{y_val:.1f}")
            self.z_entry.setText(f"{z_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{z_val:.3f}" if unit == 'MM' else f"{z_val:.1f}")
        
        if self.raw_material_handler.raw_material:
            x_val = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['translation'][0], unit)
            y_val = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['translation'][1], unit)
            z_val = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['translation'][2], unit)
            self.raw_x_slider.blockSignals(True)
            self.raw_y_slider.blockSignals(True)
            self.raw_z_slider.blockSignals(True)
            clamped_x = max(self.raw_x_slider.minimum(), min(self.raw_x_slider.maximum(), x_val * scaling_factor))
            clamped_y = max(self.raw_y_slider.minimum(), min(self.raw_y_slider.maximum(), y_val * scaling_factor))
            clamped_z = max(self.raw_z_slider.minimum(), min(self.raw_z_slider.maximum(), z_val * scaling_factor))
            self.raw_x_slider.setValue(int(round(clamped_x)))
            self.raw_y_slider.setValue(int(round(clamped_y)))
            self.raw_z_slider.setValue(int(round(clamped_z)))
            self.raw_x_slider.blockSignals(False)
            self.raw_y_slider.blockSignals(False)
            self.raw_z_slider.blockSignals(False)
            self.raw_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{x_val:.3f}" if unit == 'MM' else f"{x_val:.1f}")
            self.raw_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{y_val:.3f}" if unit == 'MM' else f"{y_val:.1f}")
            self.raw_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{z_val:.3f}" if unit == 'MM' else f"{z_val:.1f}")
        
        if self.cutting_tool_handler.cutting_tool:
            if current_system == 'Stepper (XYZAB)':
                x_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][2], unit)
            else:
                x_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][2], unit)
            self.tool_x_slider.blockSignals(True)
            self.tool_y_slider.blockSignals(True)
            self.tool_z_slider.blockSignals(True)
            clamped_x = max(self.tool_x_slider.minimum(), min(self.tool_x_slider.maximum(), x_val * scaling_factor))
            clamped_y = max(self.tool_y_slider.minimum(), min(self.tool_y_slider.maximum(), y_val * scaling_factor))
            clamped_z = max(self.tool_z_slider.minimum(), min(self.tool_z_slider.maximum(), z_val * scaling_factor))
            self.tool_x_slider.setValue(int(round(clamped_x)))
            self.tool_y_slider.setValue(int(round(clamped_y)))
            self.tool_z_slider.setValue(int(round(clamped_z)))
            self.tool_x_slider.blockSignals(False)
            self.tool_y_slider.blockSignals(False)
            self.tool_z_slider.blockSignals(False)
            self.tool_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{x_val:.3f}" if unit == 'MM' else f"{x_val:.1f}")
            self.tool_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{y_val:.3f}" if unit == 'MM' else f"{y_val:.1f}")
            self.tool_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{z_val:.3f}" if unit == 'MM' else f"{z_val:.1f}")
        
        if self.cnc_properties_handler.selected_index >= 0:
            keepout = self.cnc_properties_handler.keepout_zones[self.cnc_properties_handler.selected_index]
            x_val = self.helpers.convert_from_cm(keepout['translation'][0], unit)
            y_val = self.helpers.convert_from_cm(keepout['translation'][1], unit)
            z_val = self.helpers.convert_from_cm(keepout['translation'][2], unit)
            self.cnc_properties_handler.keepout_x_slider.blockSignals(True)
            self.cnc_properties_handler.keepout_y_slider.blockSignals(True)
            self.cnc_properties_handler.keepout_z_slider.blockSignals(True)
            clamped_x = max(self.cnc_properties_handler.keepout_x_slider.minimum(), min(self.cnc_properties_handler.keepout_x_slider.maximum(), x_val * scaling_factor))
            clamped_y = max(self.cnc_properties_handler.keepout_y_slider.minimum(), min(self.cnc_properties_handler.keepout_y_slider.maximum(), y_val * scaling_factor))
            clamped_z = max(self.cnc_properties_handler.keepout_z_slider.minimum(), min(self.cnc_properties_handler.keepout_z_slider.maximum(), z_val * scaling_factor))
            self.cnc_properties_handler.keepout_x_slider.setValue(int(round(clamped_x)))
            self.cnc_properties_handler.keepout_y_slider.setValue(int(round(clamped_y)))
            self.cnc_properties_handler.keepout_z_slider.setValue(int(round(clamped_z)))
            self.cnc_properties_handler.keepout_x_slider.blockSignals(False)
            self.cnc_properties_handler.keepout_y_slider.blockSignals(False)
            self.cnc_properties_handler.keepout_z_slider.blockSignals(False)
            self.cnc_properties_handler.keepout_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{x_val:.3f}" if unit == 'MM' else f"{x_val:.1f}")
            self.cnc_properties_handler.keepout_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{y_val:.3f}" if unit == 'MM' else f"{y_val:.1f}")
            self.cnc_properties_handler.keepout_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' or unit == 'CM' else f"{z_val:.3f}" if unit == 'MM' else f"{z_val:.1f}")

    def get_unit_suffix(self, unit):
        if unit == 'MM':
            return ' mm'
        elif unit == 'CM':
            return ' cm'
        elif unit == 'IN':
            return ' in'
        elif unit == 'MIL':
            return ' mil'
        return ' cm'

    def update_raw_material_dimensions_display(self, unit):
        if self.raw_material_handler.raw_material:
            length = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['dimensions'][0], unit)
            width = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['dimensions'][1], unit)
            height = self.helpers.convert_from_cm(self.raw_material_handler.raw_material['dimensions'][2], unit)
            self.material_length.setDecimals(6)
            self.material_width.setDecimals(6)
            self.material_height.setDecimals(6)
            self.material_diameter.setDecimals(6)
            if self.material_type_combo.currentText() == 'Rectangular Cube':
                self.material_length.blockSignals(True)
                self.material_width.blockSignals(True)
                self.material_height.blockSignals(True)
                self.material_length.setValue(length)
                self.material_width.setValue(width)
                self.material_height.setValue(height)
                self.material_length.blockSignals(False)
                self.material_width.blockSignals(False)
                self.material_height.blockSignals(False)
            else:
                self.material_diameter.blockSignals(True)
                self.material_length.blockSignals(True)
                self.material_diameter.setValue(length)
                self.material_length.setValue(width)
                self.material_diameter.blockSignals(False)
                self.material_length.blockSignals(False)

    def update_spinbox_ranges(self, unit):
        if unit == 'MM':
            base_min, base_max = 0.01, 300.0
            tool_min, tool_max = 0.01, 1000.0
        elif unit == 'CM':
            base_min, base_max = 0.001, 30.0
            tool_min, tool_max = 0.001, 100.0
        elif unit == 'IN':
            base_min, base_max = 0.0001, 11.81
            tool_min, tool_max = 0.0001, 39.37
        elif unit == 'MIL':
            base_min, base_max = 0.1, 11811.02
            tool_min, tool_max = 0.1, 39370.08

        self.material_length.setRange(base_min, base_max)
        self.material_width.setRange(base_min, base_max)
        self.material_height.setRange(base_min, base_max)
        self.material_diameter.setRange(base_min, base_max)
        self.tool_diameter.setRange(tool_min, tool_max)
        self.tool_length.setRange(tool_min, tool_max)
        self.tool_cone_length.setRange(tool_min, tool_max)

    def update_material_ui_from_cnc(self):
        """
        Update UI sliders and entry boxes with the current material coordinates after CNC to material conversion.
        """
        if self.cutting_tool_handler.cutting_tool:
            current_system = self.coord_system_combo.currentText()
            if current_system == 'XYZ + Normal':
                unit = self.current_unit
                x_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][2], unit)
                
                self.tool_x_slider.blockSignals(True)
                self.tool_y_slider.blockSignals(True)
                self.tool_z_slider.blockSignals(True)
                clamped_x = max(self.tool_x_slider.minimum(), min(self.tool_x_slider.maximum(), x_val))
                clamped_y = max(self.tool_y_slider.minimum(), min(self.tool_y_slider.maximum(), y_val))
                clamped_z = z_val  # No clamping for Z in material frame to allow negative values
                self.tool_x_slider.setValue(int(round(clamped_x)))
                self.tool_y_slider.setValue(int(round(clamped_y)))
                self.tool_z_slider.setValue(int(round(clamped_z)))
                self.tool_x_slider.blockSignals(False)
                self.tool_y_slider.blockSignals(False)
                self.tool_z_slider.blockSignals(False)
                self.tool_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' else f"{x_val:.2f}")
                self.tool_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' else f"{y_val:.2f}")
                self.tool_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")
                
                nx = self.cutting_tool_handler.cutting_tool['rotation'][0]
                ny = self.cutting_tool_handler.cutting_tool['rotation'][1]
                nz = self.cutting_tool_handler.cutting_tool['rotation'][2]
                self.tool_rx_slider.blockSignals(True)
                self.tool_ry_slider.blockSignals(True)
                self.tool_rz_slider.blockSignals(True)
                self.tool_rx_slider.setValue(int(round(nx * 1000000)))
                self.tool_ry_slider.setValue(int(round(ny * 1000000)))
                self.tool_rz_slider.setValue(int(round(nz * 1000000)))
                self.tool_rx_slider.blockSignals(False)
                self.tool_ry_slider.blockSignals(False)
                self.tool_rz_slider.blockSignals(False)
                self.tool_rx_entry.setText(f"{nx:.6f}")
                self.tool_ry_entry.setText(f"{ny:.6f}")
                self.tool_rz_entry.setText(f"{nz:.6f}")
            else:  # Stepper (XYZAB)
                unit = self.current_unit
                x_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][2], unit)
                
                self.tool_x_slider.blockSignals(True)
                self.tool_y_slider.blockSignals(True)
                self.tool_z_slider.blockSignals(True)
                clamped_x = max(self.tool_x_slider.minimum(), min(self.tool_x_slider.maximum(), x_val))
                clamped_y = max(self.tool_y_slider.minimum(), min(self.tool_y_slider.maximum(), y_val))
                clamped_z = max(self.tool_z_slider.minimum(), min(self.tool_z_slider.maximum(), z_val))
                self.tool_x_slider.setValue(int(round(clamped_x)))
                self.tool_y_slider.setValue(int(round(clamped_y)))
                self.tool_z_slider.setValue(int(round(clamped_z)))
                self.tool_x_slider.blockSignals(False)
                self.tool_y_slider.blockSignals(False)
                self.tool_z_slider.blockSignals(False)
                self.tool_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' else f"{x_val:.2f}")
                self.tool_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' else f"{y_val:.2f}")
                self.tool_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")
                
                a_val = self.cutting_tool_handler.cutting_tool['ab_rotation'][0]
                b_val = self.cutting_tool_handler.cutting_tool['ab_rotation'][1]
                if self.rotation_unit == 'DEG':
                    self.tool_rx_slider.blockSignals(True)
                    self.tool_ry_slider.blockSignals(True)
                    self.tool_rx_slider.setValue(int(round(a_val * 1000.0)))
                    self.tool_ry_slider.setValue(int(round(b_val * 1000.0)))
                    self.tool_rx_slider.blockSignals(False)
                    self.tool_ry_slider.blockSignals(False)
                    self.tool_rx_entry.setText(f"{a_val:.3f}")
                    self.tool_ry_entry.setText(f"{b_val:.3f}")
                else:
                    a_rad = np.radians(a_val)
                    b_rad = np.radians(b_val)
                    self.tool_rx_slider.blockSignals(True)
                    self.tool_ry_slider.blockSignals(True)
                    self.tool_rx_slider.setValue(int(round(a_rad * 1000000.0)))
                    self.tool_ry_slider.setValue(int(round(b_rad * 1000000.0)))
                    self.tool_rx_slider.blockSignals(False)
                    self.tool_ry_slider.blockSignals(False)
                    self.tool_rx_entry.setText(f"{a_rad:.3f}")
                    self.tool_ry_entry.setText(f"{b_rad:.3f}")

    def update_tool_sliders_for_system(self, system):
        """
        Update tool sliders and entry fields based on the current coordinate system.
        This method ensures sliders are updated with correct values during coordinate system transformations.
        """
        if self.cutting_tool_handler.cutting_tool:
            unit = self.current_unit
            
            if system == 'XYZ + Normal':
                x_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['material_translation'][2], unit)
                nx = self.cutting_tool_handler.cutting_tool['rotation'][0]
                ny = self.cutting_tool_handler.cutting_tool['rotation'][1]
                nz = self.cutting_tool_handler.cutting_tool['rotation'][2]
                
                self.tool_x_slider.blockSignals(True)
                self.tool_y_slider.blockSignals(True)
                self.tool_z_slider.blockSignals(True)
                self.tool_rx_slider.blockSignals(True)
                self.tool_ry_slider.blockSignals(True)
                self.tool_rz_slider.blockSignals(True)
                
                self.tool_x_slider.setValue(int(round(x_val)))
                self.tool_y_slider.setValue(int(round(y_val)))
                self.tool_z_slider.setValue(int(round(z_val)))
                self.tool_rx_slider.setValue(int(round(nx * 1000000)))
                self.tool_ry_slider.setValue(int(round(ny * 1000000)))
                self.tool_rz_slider.setValue(int(round(nz * 1000000)))
                
                self.tool_x_slider.blockSignals(False)
                self.tool_y_slider.blockSignals(False)
                self.tool_z_slider.blockSignals(False)
                self.tool_rx_slider.blockSignals(False)
                self.tool_ry_slider.blockSignals(False)
                self.tool_rz_slider.blockSignals(False)
                
                self.tool_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' else f"{x_val:.2f}")
                self.tool_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' else f"{y_val:.2f}")
                self.tool_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")
                self.tool_rx_entry.setText(f"{nx:.6f}")
                self.tool_ry_entry.setText(f"{ny:.6f}")
                self.tool_rz_entry.setText(f"{nz:.6f}")
            else:  # Stepper (XYZAB)
                x_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][0], unit)
                y_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][1], unit)
                z_val = self.helpers.convert_from_cm(self.cutting_tool_handler.cutting_tool['cnc_translation'][2], unit)
                a_val = self.cutting_tool_handler.cutting_tool['ab_rotation'][0]
                b_val = self.cutting_tool_handler.cutting_tool['ab_rotation'][1]
                
                self.tool_x_slider.blockSignals(True)
                self.tool_y_slider.blockSignals(True)
                self.tool_z_slider.blockSignals(True)
                self.tool_rx_slider.blockSignals(True)
                self.tool_ry_slider.blockSignals(True)
                
                self.tool_x_slider.setValue(int(round(x_val)))
                self.tool_y_slider.setValue(int(round(y_val)))
                self.tool_z_slider.setValue(int(round(z_val)))
                if self.rotation_unit == 'DEG':
                    self.tool_rx_slider.setValue(int(round(a_val * 1000.0)))
                    self.tool_ry_slider.setValue(int(round(b_val * 1000.0)))
                    self.tool_rx_entry.setText(f"{a_val:.3f}")
                    self.tool_ry_entry.setText(f"{b_val:.3f}")
                else:
                    a_rad = np.radians(a_val)
                    b_rad = np.radians(b_val)
                    self.tool_rx_slider.setValue(int(round(a_rad * 1000000.0)))
                    self.tool_ry_slider.setValue(int(round(b_rad * 1000000.0)))
                    self.tool_rx_entry.setText(f"{a_rad:.3f}")
                    self.tool_ry_entry.setText(f"{b_rad:.3f}")
                
                self.tool_x_slider.blockSignals(False)
                self.tool_y_slider.blockSignals(False)
                self.tool_z_slider.blockSignals(False)
                self.tool_rx_slider.blockSignals(False)
                self.tool_ry_slider.blockSignals(False)
                
                self.tool_x_entry.setText(f"{x_val:.4f}" if unit == 'IN' else f"{x_val:.2f}")
                self.tool_y_entry.setText(f"{y_val:.4f}" if unit == 'IN' else f"{y_val:.2f}")
                self.tool_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")
                
            if hasattr(self, 'stl_viewer') and self.stl_viewer:
                self.stl_viewer.update()

    def change_rotation_unit(self, unit):
        original_rotations = {}
        if self.stl_handler.selected_index >= 0:
            original_rotations['stl'] = self.stl_handler.stl_models[self.stl_handler.selected_index]['rotation'].copy()
        if self.raw_material_handler.raw_material:
            original_rotations['raw'] = self.raw_material_handler.raw_material['rotation'].copy()
        if self.cutting_tool_handler.cutting_tool:
            current_system = self.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                original_rotations['tool'] = self.cutting_tool_handler.cutting_tool['ab_rotation'].copy()
        
        old_unit = self.rotation_unit
        self.rotation_unit = unit
        
        self.inflate_rotation_ranges()  # Inflate ranges temporarily
        self.update_rotation_values(unit, old_unit)  # Update values based on new unit
        self.set_final_rotation_ranges(unit)  # Set final ranges and clamp values
        
        if self.stl_handler.selected_index >= 0 and 'stl' in original_rotations:
            self.stl_handler.stl_models[self.stl_handler.selected_index]['rotation'] = original_rotations['stl']
        if self.raw_material_handler.raw_material and 'raw' in original_rotations:
            self.raw_material_handler.raw_material['rotation'] = original_rotations['raw']
        if self.cutting_tool_handler.cutting_tool and 'tool' in original_rotations:
            self.cutting_tool_handler.cutting_tool['ab_rotation'] = original_rotations['tool']
        
        self.stl_viewer.update()

    def inflate_rotation_ranges(self):
        wide_range = (-100000000, 100000000)  # Wide range to prevent clamping during updates
        if self.stl_handler.selected_index >= 0:
            self.rx_slider.setRange(*wide_range)
            self.ry_slider.setRange(*wide_range)
            self.rz_slider.setRange(*wide_range)
        if self.raw_material_handler.raw_material:
            self.raw_rx_slider.setRange(*wide_range)
            self.raw_ry_slider.setRange(*wide_range)
            self.raw_rz_slider.setRange(*wide_range)
        if self.cutting_tool_handler.cutting_tool:
            current_system = self.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                self.cutting_tool_handler.gui.tool_rx_slider.setRange(*wide_range)
                self.cutting_tool_handler.gui.tool_ry_slider.setRange(*wide_range)
                # Assuming rz_slider exists for tool if needed, but based on context, focus on ab_rotation
        if self.cnc_properties_handler.selected_index >= 0:
            self.cnc_properties_handler.keepout_rx_slider.setRange(*wide_range)
            self.cnc_properties_handler.keepout_ry_slider.setRange(*wide_range)
            self.cnc_properties_handler.keepout_rz_slider.setRange(*wide_range)

    def update_rotation_values(self, unit, old_unit):
        scaling_factor = 1000 if unit == 'DEG' else 1000000  # Use 1000 for degrees, 1000000 for radians
        if self.stl_handler.selected_index >= 0:
            stl = self.stl_handler.stl_models[self.stl_handler.selected_index]
            if unit == 'DEG' and old_unit == 'RAD':
                rx_val = stl['rotation'][0]
                ry_val = stl['rotation'][1]
                rz_val = stl['rotation'][2]
            elif unit == 'RAD' and old_unit == 'DEG':
                rx_val = np.radians(stl['rotation'][0])
                ry_val = np.radians(stl['rotation'][1])
                rz_val = np.radians(stl['rotation'][2])
            
            self.rx_slider.setValue(int(round(rx_val * scaling_factor)))
            self.ry_slider.setValue(int(round(ry_val * scaling_factor)))
            self.rz_slider.setValue(int(round(rz_val * scaling_factor)))
            self.rx_entry.setText(f"{rx_val:.6f}")
            self.ry_entry.setText(f"{ry_val:.6f}")
            self.rz_entry.setText(f"{rz_val:.6f}")
        
        if self.raw_material_handler.raw_material:
            if unit == 'DEG' and old_unit == 'RAD':
                rx_val = self.raw_material_handler.raw_material['rotation'][0]
                ry_val = self.raw_material_handler.raw_material['rotation'][1]
                rz_val = self.raw_material_handler.raw_material['rotation'][2]
            elif unit == 'RAD' and old_unit == 'DEG':
                rx_val = np.radians(self.raw_material_handler.raw_material['rotation'][0])
                ry_val = np.radians(self.raw_material_handler.raw_material['rotation'][1])
                rz_val = np.radians(self.raw_material_handler.raw_material['rotation'][2])
            self.raw_rx_slider.setValue(int(round(rx_val * scaling_factor)))
            self.raw_ry_slider.setValue(int(round(ry_val * scaling_factor)))
            self.raw_rz_slider.setValue(int(round(rz_val * scaling_factor)))
            self.raw_rx_entry.setText(f"{rx_val:.6f}")
            self.raw_ry_entry.setText(f"{ry_val:.6f}")
            self.raw_rz_entry.setText(f"{rz_val:.6f}")
        
        if self.cutting_tool_handler.cutting_tool:
            current_system = self.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                if unit == 'DEG' and old_unit == 'RAD':
                    a_val = self.cutting_tool_handler.cutting_tool['ab_rotation'][0]
                    b_val = self.cutting_tool_handler.cutting_tool['ab_rotation'][1]
                elif unit == 'RAD' and old_unit == 'DEG':
                    a_val = np.radians(self.cutting_tool_handler.cutting_tool['ab_rotation'][0])
                    b_val = np.radians(self.cutting_tool_handler.cutting_tool['ab_rotation'][1])
                
                self.cutting_tool_handler.gui.tool_rx_slider.setValue(int(round(a_val * scaling_factor)))
                self.cutting_tool_handler.gui.tool_ry_slider.setValue(int(round(b_val * scaling_factor)))
        
        if self.cnc_properties_handler.selected_index >= 0:
            keepout = self.cnc_properties_handler.keepout_zones[self.cnc_properties_handler.selected_index]
            if unit == 'DEG' and old_unit == 'RAD':
                rx_val = keepout['rotation'][0]
                ry_val = keepout['rotation'][1]
                rz_val = keepout['rotation'][2]
            elif unit == 'RAD' and old_unit == 'DEG':
                rx_val = np.radians(keepout['rotation'][0])
                ry_val = np.radians(keepout['rotation'][1])
                rz_val = np.radians(keepout['rotation'][2])
            self.cnc_properties_handler.keepout_rx_slider.setValue(int(round(rx_val * scaling_factor)))
            self.cnc_properties_handler.keepout_ry_slider.setValue(int(round(ry_val * scaling_factor)))
            self.cnc_properties_handler.keepout_rz_slider.setValue(int(round(rz_val * scaling_factor)))
            self.cnc_properties_handler.keepout_rx_entry.setText(f"{rx_val:.6f}")
            self.cnc_properties_handler.keepout_ry_entry.setText(f"{ry_val:.6f}")
            self.cnc_properties_handler.keepout_rz_entry.setText(f"{rz_val:.6f}")
        self.cnc_properties_handler.update_limits_display(self.current_unit)

    def set_final_rotation_ranges(self, unit):
        if unit == 'DEG':
            self.rx_slider.setRange(-180000, 180000)  # Scaled for degrees
            self.ry_slider.setRange(-180000, 180000)
            self.rz_slider.setRange(-180000, 180000)
            if self.raw_material_handler.raw_material:
                self.raw_rx_slider.setRange(-180000, 180000)
                self.raw_ry_slider.setRange(-180000, 180000)
                self.raw_rz_slider.setRange(-180000, 180000)
            if self.cutting_tool_handler.cutting_tool:
                current_system = self.coord_system_combo.currentText()
                if current_system == 'Stepper (XYZAB)':
                    self.cutting_tool_handler.gui.tool_rx_slider.setRange(-90000, 90000)  # -90 to 90 degrees scaled
                    self.cutting_tool_handler.gui.tool_ry_slider.setRange(0, 360000)     # 0 to 360 degrees scaled
                else:
                    self.cutting_tool_handler.gui.tool_rx_slider.setRange(-1000000, 1000000)
                    self.cutting_tool_handler.gui.tool_ry_slider.setRange(-1000000, 1000000)
                    self.cutting_tool_handler.gui.tool_rz_slider.setRange(0, 1000000)
            if self.cnc_properties_handler.selected_index >= 0:
                self.cnc_properties_handler.keepout_rx_slider.setRange(-180000, 180000)
                self.cnc_properties_handler.keepout_ry_slider.setRange(-180000, 180000)
                self.cnc_properties_handler.keepout_rz_slider.setRange(-180000, 180000)
        else:  # RAD
            self.rx_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))  # Scaled for radians
            self.ry_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))
            self.rz_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))
            if self.raw_material_handler.raw_material:
                self.raw_rx_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))
                self.raw_ry_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))
                self.raw_rz_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))
            if self.cutting_tool_handler.cutting_tool:
                current_system = self.coord_system_combo.currentText()
                if current_system == 'Stepper (XYZAB)':
                    self.cutting_tool_handler.gui.tool_rx_slider.setRange(-int(np.pi/2 * 1000000), int(np.pi/2 * 1000000))  # -π/2 to π/2 radians scaled
                    self.cutting_tool_handler.gui.tool_ry_slider.setRange(0, int(2*np.pi * 1000000))  # 0 to 2π radians scaled
                else:
                    self.cutting_tool_handler.gui.tool_rx_slider.setRange(-1000000, 1000000)
                    self.cutting_tool_handler.gui.tool_ry_slider.setRange(-1000000, 1000000)
                    self.cutting_tool_handler.gui.tool_rz_slider.setRange(-0, 1000000)
            if self.cnc_properties_handler.selected_index >= 0:
                self.cnc_properties_handler.keepout_rx_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))
                self.cnc_properties_handler.keepout_ry_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))
                self.cnc_properties_handler.keepout_rz_slider.setRange(-int(np.pi * 1000000), int(np.pi * 1000000))
               
        # Clamp values after setting ranges, using the appropriate scaling factor
        scaling_factor = 1000 if unit == 'DEG' else 1000000
        if self.stl_handler.selected_index >= 0:
            stl = self.stl_handler.stl_models[self.stl_handler.selected_index]
            if unit == 'DEG':
                rx_val = stl['rotation'][0]
                ry_val = stl['rotation'][1]
                rz_val = stl['rotation'][2]
            else:
                rx_val = np.radians(stl['rotation'][0])
                ry_val = np.radians(stl['rotation'][1])
                rz_val = np.radians(stl['rotation'][2])

            self.rx_slider.setValue(int(round(max(self.rx_slider.minimum(), min(self.rx_slider.maximum(), rx_val * scaling_factor)))))
            self.ry_slider.setValue(int(round(max(self.ry_slider.minimum(), min(self.ry_slider.maximum(), ry_val * scaling_factor)))))
            self.rz_slider.setValue(int(round(max(self.rz_slider.minimum(), min(self.rz_slider.maximum(), rz_val * scaling_factor)))))
        if self.raw_material_handler.raw_material:
            if unit == 'DEG':
                rx_val = self.raw_material_handler.raw_material['rotation'][0]
                ry_val = self.raw_material_handler.raw_material['rotation'][1]
                rz_val = self.raw_material_handler.raw_material['rotation'][2]
            else:
                rx_val = np.radians(self.raw_material_handler.raw_material['rotation'][0])
                ry_val = np.radians(self.raw_material_handler.raw_material['rotation'][1])
                rz_val = np.radians(self.raw_material_handler.raw_material['rotation'][2])
            self.raw_rx_slider.setValue(int(round(max(self.raw_rx_slider.minimum(), min(self.raw_rx_slider.maximum(), rx_val * scaling_factor)))))
            self.raw_ry_slider.setValue(int(round(max(self.raw_ry_slider.minimum(), min(self.raw_ry_slider.maximum(), ry_val * scaling_factor)))))
            self.raw_rz_slider.setValue(int(round(max(self.raw_rz_slider.minimum(), min(self.raw_rz_slider.maximum(), rz_val * scaling_factor)))))
        if self.cutting_tool_handler.cutting_tool:
            current_system = self.coord_system_combo.currentText()
            if current_system == 'Stepper (XYZAB)':
                if unit == 'DEG':
                    a_val = self.cutting_tool_handler.cutting_tool['ab_rotation'][0]
                    b_val = self.cutting_tool_handler.cutting_tool['ab_rotation'][1]
                else:
                    a_val = np.radians(self.cutting_tool_handler.cutting_tool['ab_rotation'][0])
                    b_val = np.radians(self.cutting_tool_handler.cutting_tool['ab_rotation'][1])
                self.cutting_tool_handler.gui.tool_rx_slider.setValue(int(round(max(self.cutting_tool_handler.gui.tool_rx_slider.minimum(), min(self.cutting_tool_handler.gui.tool_rx_slider.maximum(), a_val * scaling_factor)))))
                self.cutting_tool_handler.gui.tool_ry_slider.setValue(int(round(max(self.cutting_tool_handler.gui.tool_ry_slider.minimum(), min(self.cutting_tool_handler.gui.tool_ry_slider.maximum(), b_val * scaling_factor)))))
        if self.cnc_properties_handler.selected_index >= 0:
            keepout = self.cnc_properties_handler.keepout_zones[self.cnc_properties_handler.selected_index]
            if unit == 'DEG':
                rx_val = keepout['rotation'][0]
                ry_val = keepout['rotation'][1]
                rz_val = keepout['rotation'][2]
            else:
                rx_val = np.radians(keepout['rotation'][0])
                ry_val = np.radians(keepout['rotation'][1])
                rz_val = np.radians(keepout['rotation'][2])
            self.cnc_properties_handler.keepout_rx_slider.setValue(int(round(max(self.cnc_properties_handler.keepout_rx_slider.minimum(), min(self.cnc_properties_handler.keepout_rx_slider.maximum(), rx_val * scaling_factor)))))
            self.cnc_properties_handler.keepout_ry_slider.setValue(int(round(max(self.cnc_properties_handler.keepout_ry_slider.minimum(), min(self.cnc_properties_handler.keepout_ry_slider.maximum(), ry_val * scaling_factor)))))
            self.cnc_properties_handler.keepout_rz_slider.setValue(int(round(max(self.cnc_properties_handler.keepout_rz_slider.minimum(), min(self.cnc_properties_handler.keepout_rz_slider.maximum(), rz_val * scaling_factor)))))

    def inflate_tool_rotation_ranges(self):
        """
        Temporarily inflate the rotation slider ranges during coordinate system transformation to prevent clamping.
        """
        wide_range = (-100000000, 100000000)
        self.rx_slider.setRange(*wide_range)
        self.ry_slider.setRange(*wide_range)
        self.rz_slider.setRange(*wide_range)
        self.raw_rx_slider.setRange(*wide_range)
        self.raw_ry_slider.setRange(*wide_range)
        self.raw_rz_slider.setRange(*wide_range)
        self.tool_rx_slider.setRange(*wide_range)
        self.tool_ry_slider.setRange(*wide_range)
        self.tool_rz_slider.setRange(*wide_range)

    def is_mouse_pressed(self):
        return QGuiApplication.mouseButtons() & Qt.LeftButton == Qt.LeftButton
        
    def on_tab_changed(self, index):
        self.set_final_slider_ranges(self.current_unit)
        tab_text = self.tab_widget.tabText(index)
        if tab_text == "Cutting Tool":
            # Deselect any selected STL
            self.stl_handler.selected_index = -1
            self.stl_list.clearSelection()
            # Deselect any selected Keepout
            self.cnc_properties_handler.selected_index = -1
            self.keepout_list.clearSelection()
            self.center_view()  # Automatically center the view on the cutting tool
            self.stl_viewer.update()
        elif tab_text == "Raw Material":
            # Deselect any selected STL
            self.stl_handler.selected_index = -1
            self.stl_list.clearSelection()
            # Deselect any selected Keepout
            self.cnc_properties_handler.selected_index = -1
            self.keepout_list.clearSelection()
            self.center_view()  # Automatically center the view on the raw material
            self.stl_viewer.update()
        elif tab_text == "STL Objects":
            # Deselect any selected Keepout
            self.cnc_properties_handler.selected_index = -1
            self.keepout_list.clearSelection()
            # Re-select the last selected STL if available
            if hasattr(self, 'last_selected_stl_index') and self.last_selected_stl_index >= 0 and self.last_selected_stl_index < len(self.stl_handler.stl_models):
                self.stl_handler.selected_index = self.last_selected_stl_index
                self.stl_list.setCurrentRow(self.last_selected_stl_index)
                self.update_sliders()
                current_mode = self.stl_handler.render_modes[self.stl_handler.selected_index]
                if current_mode == "wireframe":
                    self.stl_wireframe_button.setChecked(True)
                else:
                    self.stl_solid_button.setChecked(True)
                self.center_view()  # Center on the re-selected STL
            self.stl_viewer.update()
        elif tab_text == "CNC Properties":
            # Deselect any selected STL
            self.stl_handler.selected_index = -1
            self.stl_list.clearSelection()
            # Re-select the last selected Keepout if available
            if hasattr(self, 'last_selected_keepout_index') and self.last_selected_keepout_index >= 0 and self.last_selected_keepout_index < len(self.cnc_properties_handler.keepout_zones):
                self.cnc_properties_handler.selected_index = self.last_selected_keepout_index
                self.keepout_list.setCurrentRow(self.last_selected_keepout_index)
                self.update_sliders()
                self.center_view()  # Center on the re-selected Keepout
            self.stl_viewer.update()

    def setup_path_tab(self):
        path_tab = QWidget()
        path_layout = QVBoxLayout()
        path_tab.setLayout(path_layout)
        
        self.path_list = QListWidget()
        self.path_list.setFixedHeight(200)
        self.path_list.itemClicked.connect(self.on_path_item_selected)
        path_layout.addWidget(self.path_list)
        
        # Buttons for managing path list
        path_buttons_layout = QHBoxLayout()
        move_up_button = QPushButton('Move Up')
        move_up_button.clicked.connect(self.move_path_item_up)
        path_buttons_layout.addWidget(move_up_button)
        
        move_down_button = QPushButton('Move Down')
        move_down_button.clicked.connect(self.move_path_item_down)
        path_buttons_layout.addWidget(move_down_button)
        
        delete_button = QPushButton('Delete')
        delete_button.clicked.connect(self.delete_path_item)
        path_buttons_layout.addWidget(delete_button)
        
        path_layout.addLayout(path_buttons_layout)
        
        # Playback Speed Control
        speed_layout = QHBoxLayout()
        speed_label = QLabel('Playback Speed (steps/sec):')
        speed_layout.addWidget(speed_label)
        self.playback_speed_spinbox = QDoubleSpinBox()
        self.playback_speed_spinbox.setRange(0.1, 10.0)
        self.playback_speed_spinbox.setValue(1.0)
        self.playback_speed_spinbox.setSingleStep(0.1)
        self.playback_speed_spinbox.valueChanged.connect(self.update_playback_speed)
        speed_layout.addWidget(self.playback_speed_spinbox)
        path_layout.addLayout(speed_layout)
        
        self.tab_widget.addTab(path_tab, "Path")
        self.path_points = []  # List to store path points with XYZAB and XYZ+Normal

    def setup_planning_tab(self):
        planning_tab = QWidget()
        planning_layout = QVBoxLayout()
        planning_tab.setLayout(planning_layout)
        
        # Cutting Volume per Second
        volume_layout = QHBoxLayout()
        volume_label = QLabel('Cutting Volume per Second (cm³/s):')
        volume_layout.addWidget(volume_label)
        self.volume_spinbox = QDoubleSpinBox()
        self.volume_spinbox.setRange(0.1, 100.0)
        self.volume_spinbox.setValue(1.0)
        self.volume_spinbox.setSingleStep(0.1)
        volume_layout.addWidget(self.volume_spinbox)
        planning_layout.addLayout(volume_layout)
        
        # Speed
        speed_layout = QHBoxLayout()
        speed_label = QLabel('Speed (cm/s):')
        speed_layout.addWidget(speed_label)
        self.speed_spinbox = QDoubleSpinBox()
        self.speed_spinbox.setRange(0.1, 10.0)
        self.speed_spinbox.setValue(1.0)
        self.speed_spinbox.setSingleStep(0.1)
        speed_layout.addWidget(self.speed_spinbox)
        planning_layout.addLayout(speed_layout)
        
        # Acceleration
        accel_layout = QHBoxLayout()
        accel_label = QLabel('Acceleration (cm/s²):')
        accel_layout.addWidget(accel_label)
        self.accel_spinbox = QDoubleSpinBox()
        self.accel_spinbox.setRange(0.1, 10.0)
        self.accel_spinbox.setValue(1.0)
        self.accel_spinbox.setSingleStep(0.1)
        accel_layout.addWidget(self.accel_spinbox)
        planning_layout.addLayout(accel_layout)
        
        # Stepover Percentage
        stepover_layout = QHBoxLayout()
        stepover_label = QLabel('Stepover (%):')
        stepover_layout.addWidget(stepover_label)
        self.stepover_spinbox = QDoubleSpinBox()
        self.stepover_spinbox.setRange(0.0, 100.0)
        self.stepover_spinbox.setValue(50.0)
        self.stepover_spinbox.setSingleStep(1.0)
        stepover_layout.addWidget(self.stepover_spinbox)
        planning_layout.addLayout(stepover_layout)
        
        # Path Type Selector
        path_type_layout = QHBoxLayout()
        path_type_label = QLabel('Path Type:')
        path_type_layout.addWidget(path_type_label)
        self.path_type_combo = QComboBox()
        self.path_type_combo.addItems(['Concentric', 'Linear', 'Optimized'])
        path_type_layout.addWidget(self.path_type_combo)
        planning_layout.addLayout(path_type_layout)
        
        # Plan and Cancel Buttons
        button_layout = QHBoxLayout()
        plan_button = QPushButton('Plan')
        plan_button.clicked.connect(self.plan_path)
        button_layout.addWidget(plan_button)
        self.cancel_button = QPushButton('Cancel')
        self.cancel_button.clicked.connect(self.cancel_planning)
        self.cancel_button.setEnabled(False)
        button_layout.addWidget(self.cancel_button)
        planning_layout.addLayout(button_layout)
        
        # Progress Bar
        progress_layout = QHBoxLayout()
        progress_label = QLabel('Planning Progress:')
        progress_layout.addWidget(progress_label)
        self.planning_progress = QProgressBar()
        self.planning_progress.setRange(0, 100)
        self.planning_progress.setValue(0)
        progress_layout.addWidget(self.planning_progress)
        planning_layout.addLayout(progress_layout)
        
        # Output Text Area
        self.planning_output = QTextEdit()
        self.planning_output.setReadOnly(True)
        self.planning_output.setFixedHeight(150)
        planning_layout.addWidget(self.planning_output)
        
        # Toggle Checkboxes for Visualizations
        toggle_layout = QHBoxLayout()
        self.toggle_cut_volume = QCheckBox('Cut Volume (Cyan)')
        self.toggle_cut_volume.setChecked(True)
        self.toggle_cut_volume.stateChanged.connect(self.update_viewer)
        toggle_layout.addWidget(self.toggle_cut_volume)
        
        self.toggle_unreachable = QCheckBox('Unreachable Areas (Red)')
        self.toggle_unreachable.setChecked(True)
        self.toggle_unreachable.stateChanged.connect(self.update_viewer)
        toggle_layout.addWidget(self.toggle_unreachable)
        
        self.toggle_tool_path = QCheckBox('Tool Path (Green)')
        self.toggle_tool_path.setChecked(True)
        self.toggle_tool_path.stateChanged.connect(self.update_viewer)
        toggle_layout.addWidget(self.toggle_tool_path)
        planning_layout.addLayout(toggle_layout)
        
        planning_layout.addStretch()
        self.tab_widget.addTab(planning_tab, "Planning")
        
        # Initialize visualization objects
        self.cut_volume_stl = None
        self.unreachable_stl = None
        self.tool_path = None

    def append_to_path(self):
        if self.cutting_tool_handler.cutting_tool:
            xyzab = {
                'x': self.cutting_tool_handler.cutting_tool['cnc_translation'][0],
                'y': self.cutting_tool_handler.cutting_tool['cnc_translation'][1],
                'z': self.cutting_tool_handler.cutting_tool['cnc_translation'][2],
                'a': self.cutting_tool_handler.cutting_tool['ab_rotation'][0],
                'b': self.cutting_tool_handler.cutting_tool['ab_rotation'][1]
            }
            xyz_normal = {
                'x': self.cutting_tool_handler.cutting_tool['material_translation'][0],
                'y': self.cutting_tool_handler.cutting_tool['material_translation'][1],
                'z': self.cutting_tool_handler.cutting_tool['material_translation'][2],
                'nx': self.cutting_tool_handler.cutting_tool['rotation'][0],
                'ny': self.cutting_tool_handler.cutting_tool['rotation'][1],
                'nz': self.cutting_tool_handler.cutting_tool['rotation'][2]
            }
            self.path_handler.append_point(xyzab, xyz_normal)
            self.path_slider.setRange(0, len(self.path_handler.path_points) - 1)

    def insert_to_path(self):
        if self.cutting_tool_handler.cutting_tool:
            selected_row = self.path_list.currentRow()
            xyzab = {
                'x': self.cutting_tool_handler.cutting_tool['cnc_translation'][0],
                'y': self.cutting_tool_handler.cutting_tool['cnc_translation'][1],
                'z': self.cutting_tool_handler.cutting_tool['cnc_translation'][2],
                'a': self.cutting_tool_handler.cutting_tool['ab_rotation'][0],
                'b': self.cutting_tool_handler.cutting_tool['ab_rotation'][1]
            }
            xyz_normal = {
                'x': self.cutting_tool_handler.cutting_tool['material_translation'][0],
                'y': self.cutting_tool_handler.cutting_tool['material_translation'][1],
                'z': self.cutting_tool_handler.cutting_tool['material_translation'][2],
                'nx': self.cutting_tool_handler.cutting_tool['rotation'][0],
                'ny': self.cutting_tool_handler.cutting_tool['rotation'][1],
                'nz': self.cutting_tool_handler.cutting_tool['rotation'][2]
            }
            self.path_handler.insert_point(selected_row, xyzab, xyz_normal)
            self.path_slider.setRange(0, len(self.path_handler.path_points) - 1)

    def update_path_list(self):
        self.path_list.clear()
        for i, point in enumerate(self.path_handler.path_points):
            xyzab = point['xyzab']
            xyz_normal = point['xyz_normal']
            item_text = (f"Step {i+1}: XYZAB(X={xyzab['x']:.2f}, Y={xyzab['y']:.2f}, Z={xyzab['z']:.2f}, A={xyzab['a']:.2f}°, B={xyzab['b']:.2f}°) | "
                         f"XYZ+Normal(X={xyz_normal['x']:.2f}, Y={xyz_normal['y']:.2f}, Z={xyz_normal['z']:.2f}, "
                         f"Nx={xyz_normal['nx']:.2f}, Ny={xyz_normal['ny']:.2f}, Nz={xyz_normal['nz']:.2f})")
            self.path_list.addItem(item_text)

    def on_path_item_selected(self, item):
        selected_row = self.path_list.row(item)
        if selected_row >= 0 and selected_row < len(self.path_handler.path_points):
            self.path_slider.setValue(selected_row)
            point = self.path_handler.path_points[selected_row]
            self.cutting_tool_handler.cutting_tool['cnc_translation'] = [
                point['xyzab']['x'], point['xyzab']['y'], point['xyzab']['z']
            ]
            self.cutting_tool_handler.cutting_tool['ab_rotation'] = [
                point['xyzab']['a'], point['xyzab']['b']
            ]
            self.cutting_tool_handler.cutting_tool['material_translation'] = [
                point['xyz_normal']['x'], point['xyz_normal']['y'], point['xyz_normal']['z']
            ]
            self.cutting_tool_handler.cutting_tool['rotation'] = [
                point['xyz_normal']['nx'], point['xyz_normal']['ny'], point['xyz_normal']['nz']
            ]
            self.update_tool_sliders_for_system(self.coord_system_combo.currentText())
            self.stl_viewer.update()

    def move_path_item_up(self):
        selected_row = self.path_list.currentRow()
        if selected_row > 0:
            self.path_handler.move_point_up(selected_row)
            self.update_path_list()
            self.path_list.setCurrentRow(selected_row - 1)

    def move_path_item_down(self):
        selected_row = self.path_list.currentRow()
        if selected_row >= 0 and selected_row < len(self.path_handler.path_points) - 1:
            self.path_handler.move_point_down(selected_row)
            self.update_path_list()
            self.path_list.setCurrentRow(selected_row + 1)

    def delete_path_item(self):
        selected_row = self.path_list.currentRow()
        if selected_row >= 0:
            self.path_handler.delete_point(selected_row)
            self.update_path_list()
            self.path_slider.setRange(0, max(0, len(self.path_handler.path_points) - 1))
            if selected_row < len(self.path_handler.path_points):
                self.path_list.setCurrentRow(selected_row)
            elif len(self.path_handler.path_points) > 0:
                self.path_list.setCurrentRow(len(self.path_handler.path_points) - 1)

    def on_path_slider_changed(self, value):
        if value >= 0 and value < len(self.path_handler.path_points):
            self.path_list.setCurrentRow(value)
            point = self.path_handler.path_points[value]
            self.cutting_tool_handler.cutting_tool['cnc_translation'] = [
                point['xyzab']['x'], point['xyzab']['y'], point['xyzab']['z']
            ]
            self.cutting_tool_handler.cutting_tool['ab_rotation'] = [
                point['xyzab']['a'], point['xyzab']['b']
            ]
            self.cutting_tool_handler.cutting_tool['material_translation'] = [
                point['xyz_normal']['x'], point['xyz_normal']['y'], point['xyz_normal']['z']
            ]
            self.cutting_tool_handler.cutting_tool['rotation'] = [
                point['xyz_normal']['nx'], point['xyz_normal']['ny'], point['xyz_normal']['nz']
            ]
            self.update_tool_sliders_for_system(self.coord_system_combo.currentText())
            self.stl_viewer.update()

    def play_path(self):
        if len(self.path_handler.path_points) > 0:
            current_index = self.path_slider.value()
            if current_index < 0:
                current_index = 0
            self.path_slider.setValue(current_index)
            interval = 1000 / self.playback_speed_spinbox.value()  # Convert speed (steps/sec) to milliseconds interval
            self.path_timer.start(int(interval))

    def pause_path(self):
        self.path_timer.stop()

    def stop_path(self):
        self.path_timer.stop()
        if len(self.path_handler.path_points) > 0:
            self.path_slider.setValue(0)
            self.path_list.setCurrentRow(0)
            point = self.path_handler.path_points[0]
            self.cutting_tool_handler.cutting_tool['cnc_translation'] = [
                point['xyzab']['x'], point['xyzab']['y'], point['xyzab']['z']
            ]
            self.cutting_tool_handler.cutting_tool['ab_rotation'] = [
                point['xyzab']['a'], point['xyzab']['b']
            ]
            self.cutting_tool_handler.cutting_tool['material_translation'] = [
                point['xyz_normal']['x'], point['xyz_normal']['y'], point['xyz_normal']['z']
            ]
            self.cutting_tool_handler.cutting_tool['rotation'] = [
                point['xyz_normal']['nx'], point['xyz_normal']['ny'], point['xyz_normal']['nz']
            ]
            self.update_tool_sliders_for_system(self.coord_system_combo.currentText())
            self.stl_viewer.update()

    def advance_path(self):
        current_index = self.path_slider.value()
        if current_index < len(self.path_handler.path_points) - 1:
            self.path_slider.setValue(current_index + 1)
        else:
            self.path_timer.stop()

    def plan_path(self, path_type=None, cutting_volume_rate=None, speed=None, acceleration=None, stepover=None, update_progress_callback=None, update_output_callback=None, cancel_check_callback=None, update_tool_position_callback=None):
        from PyQt5.QtWidgets import QProgressBar
        from PyQt5.QtCore import Qt, QThread, pyqtSignal

        class PlanningThread(QThread):
            update_progress = pyqtSignal(float)
            update_output = pyqtSignal(str)
            planning_finished = pyqtSignal(dict)
            update_phase = pyqtSignal(str)
            update_tool_position = pyqtSignal(dict, dict)
            cutting_tool_handler = self.cutting_tool_handler

            def __init__(self, planner, path_type, cutting_volume_rate, speed, acceleration, stepover, initial_to_be_cut_volume):
                super().__init__()
                self.planner = planner
                self.path_type = path_type
                self.cutting_volume_rate = cutting_volume_rate
                self.speed = speed
                self.acceleration = acceleration
                self.stepover = stepover
                self.initial_to_be_cut_volume = initial_to_be_cut_volume
                self.is_canceled = False
                
            def run(self):
                if self.is_canceled:
                    self.update_output.emit("Planning canceled before starting.")
                    return
                
                self.update_phase.emit("Generating tool path...")
                result = self.planner.plan_path(
                    self.path_type, 
                    self.cutting_volume_rate, 
                    self.speed, 
                    self.acceleration,
                    self.stepover,
                    update_progress_callback=self.update_progress_callback,
                    update_output_callback=self.update_output_callback,
                    cancel_check_callback=self.check_canceled,
                    update_tool_position_callback=self.update_tool_position_callback
                )
                
                if self.is_canceled:
                    self.update_output.emit("Planning canceled during path generation.")
                    
                
                self.update_phase.emit("Generating cut volume visualization...")
                if 'cut_volume_stl' in result and not result['cut_volume_stl']:
                    self.update_output.emit("Creating cut volume STL...")
                    result['cut_volume_stl'] = self.planner.mesh_utils.mesh_to_stl(
                        self.planner.mesh_utils.create_cut_volume_mesh(
                    result['tool_path']), name='cut_volume'
                    )
                    self.update_output.emit("Cut volume STL creation completed.")
                    
                
                self.update_phase.emit("Generating unreachable areas visualization if applicable...")
                if 'unreachable_volume' in result and result['unreachable_volume'] > 0 and not result['unreachable_stl']:
                    self.update_output.emit("Processing unreachable areas visualization...")
                    result['unreachable_stl'] = self.planner.create_unreachable_stl(
                        self.planner.raw_material_handler.get_transformed_raw_material_mesh()[0],
                        result['total_volume']
                    )
                    self.update_output.emit("Completed unreachable areas visualization.")
                else:
                    self.update_output.emit("Skipping unreachable areas visualization (no unreachable volume detected).")
                
                    
                
                self.update_phase.emit("Finalizing planning results...")
                self.update_output.emit("Preparing to send planning results to GUI...")
                self.planning_finished.emit(result)
                self.update_output.emit("Planning results sent to GUI for processing.")

            def update_progress_callback(self, progress):
                self.update_progress.emit(progress)

            def update_output_callback(self, text):
                self.update_output.emit(text)

            def update_tool_position_callback(self, xyzab, xyz_normal):
                self.update_tool_position.emit(xyzab, xyz_normal)

            def check_canceled(self):
                return self.is_canceled

            def cancel(self):
                self.is_canceled = True

        planner = self.planning_handler
        # Use provided arguments or fetch from GUI elements if not provided
        path_type = path_type if isinstance(path_type,str) else self.path_type_combo.currentText()
        cutting_volume_rate = self.volume_spinbox.value()
        speed = self.speed_spinbox.value()
        acceleration = self.accel_spinbox.value()
        stepover = self.stepover_spinbox.value() / 100.0
        
        # Calculate initial to be cut volume for progress calculation
        raw_material = self.raw_material_handler.raw_material
        initial_to_be_cut_volume = 0.0
        if raw_material:
            raw_mesh = self.raw_material_handler.get_transformed_raw_material_mesh()[0]
            to_be_cut = raw_mesh
            protected_meshes = []
            for keepout in self.cnc_properties_handler.keepout_zones:
                keepout_mesh = self.cnc_properties_handler.get_transformed_keepout_mesh(keepout)[0]
                protected_meshes.append(keepout_mesh)
            for stl in self.stl_handler.stl_models:
                stl_mesh = self.stl_handler.get_transformed_stl_mesh(stl)[0]
                protected_meshes.append(stl_mesh)
            for protected_mesh in protected_meshes:
                if protected_mesh.volume > 0 and protected_mesh.is_volume:
                    try:
                        to_be_cut = to_be_cut.difference(protected_mesh)
                        if to_be_cut.volume == 0:
                            break
                    except Exception as e:
                        if update_output_callback:
                            update_output_callback(f"Warning: Difference operation failed with protected mesh: {str(e)}")
                        continue
            initial_to_be_cut_volume = to_be_cut.volume
        
        # Reset progress bar and output
        self.planning_progress.setValue(0)
        self.planning_output.clear()
        
        # Disable plan button and enable cancel button during planning
        planning_tab_index = self.tab_widget.indexOf(self.tab_widget.widget(self.tab_widget.count() - 1))  # Assuming Planning is the last tab
        planning_tab = self.tab_widget.widget(planning_tab_index)
        plan_button = None
        for btn in planning_tab.findChildren(QPushButton):
            if btn.text() == "Plan":
                plan_button = btn
                break
        if plan_button:
            plan_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        
        # Clear existing path
        self.path_handler.clear_path()
        self.update_path_list()
        
        # Start planning in a separate thread
        self.planning_thread = PlanningThread(planner, path_type, cutting_volume_rate, speed, acceleration, stepover, initial_to_be_cut_volume)
        
        def on_update_progress(progress):
            self.planning_progress.setValue(int(min(100.0, max(0.0, progress))))
        
        def on_update_output(text):
            self.planning_output.append(text)
            self.planning_output.ensureCursorVisible()  # Ensure the latest output is visible
        
        def on_update_tool_position(xyzab, xyz_normal):
            self.update_tool_position_for_plan(xyzab, xyz_normal)

        def on_update_phase(phase_text):
            self.planning_output.append(f"Current Phase: {phase_text}")
            self.planning_output.ensureCursorVisible()  # Ensure the phase update is visible
        
        def on_planning_finished(result):
            self.planning_output.append("Received planning results, processing path data...")
            self.planning_output.ensureCursorVisible()
            self.path_handler.set_path(result['path'])
            self.update_path_list()
            self.path_slider.setRange(0, max(0, len(self.path_handler.path_points) - 1))
            
            # Update final output
            output_text = (
                f"Planning Complete:\n"
                f"Total Volume to Cut: {result['total_volume']:.2f} cm³\n"
                f"Total Time: {result['total_time']:.2f} seconds\n"
                f"Percentage Removed: {result['percentage_removed']:.2f}%"
            )
            if 'num_steps' in result:
                output_text += f"\nNumber of Steps: {result['num_steps']}"
            if 'path_length' in result:
                output_text += f"\nPath Length: {result['path_length']:.2f} cm"
            if 'unreachable_volume' in result:
                output_text += f"\nUnreachable Volume: {result['unreachable_volume']:.2f} cm³"
            self.planning_output.append(output_text)
            self.planning_output.ensureCursorVisible()  # Ensure final output is visible
            
            # Update visualization objects by creating OpenGL lists
            self.cut_volume_stl = None
            self.unreachable_stl = None
            self.planning_output.append("Creating visualization for cut volume...")
            self.planning_output.ensureCursorVisible()
            if 'cut_volume_stl' in result and result['cut_volume_stl']:
                self.cut_volume_stl = self.create_display_lists(result['cut_volume_stl']['mesh'])
            self.planning_output.append("Cut volume visualization created.")
            self.planning_output.ensureCursorVisible()
            self.planning_output.append("Creating visualization for unreachable areas if applicable...")
            self.planning_output.ensureCursorVisible()
            if 'unreachable_stl' in result and result['unreachable_stl']:
                self.unreachable_stl = self.create_display_lists(result['unreachable_stl']['mesh'])
            self.planning_output.append("Unreachable areas visualization created.")
            self.planning_output.ensureCursorVisible()
            self.tool_path = result['tool_path']
            self.planning_output.append("Updating viewer with new visualizations...")
            self.planning_output.ensureCursorVisible()
            self.stl_viewer.update()
            self.planning_output.append("Viewer updated with new visualizations.")
            self.planning_output.ensureCursorVisible()
            
            # Reset progress bar and re-enable plan button, disable cancel button
            self.planning_progress.setValue(100)
            self.planning_output.append("Planning process fully completed.")
            self.planning_output.ensureCursorVisible()
            if plan_button:
                plan_button.setEnabled(True)
            self.cancel_button.setEnabled(False)
        
        self.planning_thread.update_progress.connect(on_update_progress)
        self.planning_thread.update_output.connect(on_update_output)
        self.planning_thread.update_phase.connect(on_update_phase)
        self.planning_thread.planning_finished.connect(on_planning_finished)
        self.planning_thread.update_tool_position.connect(on_update_tool_position)
        self.planning_thread.start()

    def update_viewer(self):
        if hasattr(self, 'stl_viewer') and self.stl_viewer:
            self.stl_viewer.update()

    def create_display_lists(self, mesh):
        display_list = glGenLists(1)
        wireframe_list = glGenLists(1)
        
        glNewList(display_list, GL_COMPILE)
        glBegin(GL_TRIANGLES)
        for face in mesh.faces:
            for vertex in mesh.vertices[face]:
                glVertex3f(vertex[0], vertex[1], vertex[2])
        glEnd()
        glEndList()
        
        glNewList(wireframe_list, GL_COMPILE)
        glBegin(GL_LINES)
        for edge in mesh.edges:
            for vertex in mesh.vertices[edge]:
                glVertex3f(vertex[0], vertex[1], vertex[2])
        glEnd()
        glEndList()
        
        return {'display_list': display_list, 'wireframe_list': wireframe_list}

    def update_playback_speed(self, value):
        if self.path_timer.isActive():
            interval = 1000 / value  # Convert speed (steps/sec) to milliseconds interval
            self.path_timer.setInterval(int(interval))

    def cancel_planning(self):
        if hasattr(self, 'planning_thread') and self.planning_thread.isRunning():
            self.planning_thread.cancel()
            self.planning_output.append("Canceling planning process...")
            self.cancel_button.setEnabled(False)
            planning_tab_index = self.tab_widget.indexOf(self.tab_widget.widget(self.tab_widget.count() - 1))
            planning_tab = self.tab_widget.widget(planning_tab_index)
            plan_button = None
            for btn in planning_tab.findChildren(QPushButton):
                if btn.text() == "Plan":
                    plan_button = btn
                    break
            if plan_button:
                plan_button.setEnabled(True)
            self.planning_progress.setValue(0)

    def update_tool_position_for_plan(self, xyzab, xyz_normal):
        """
        Update the cutting tool's position and orientation for rendering during path planning.
        This method updates the tool's CNC and material coordinates without directly triggering GUI updates.
        Instead, it sets a flag and stores the data for the main thread to process during a timer update.
        
        Parameters:
        - xyzab (dict): Dictionary with CNC coordinates and angles {'x', 'y', 'z', 'a', 'b'}.
        - xyz_normal (dict): Dictionary with material coordinates and normal {'x', 'y', 'z', 'nx', 'ny', 'nz'}.
        """
        self.pending_tool_update = True
        self.pending_xyzab = xyzab
        self.pending_xyz_normal = xyz_normal
        
    def check_pending_tool_update(self):
        """
        Check if there is a pending tool position update from planning and apply it.
        This method runs in the main thread via a timer, ensuring thread-safe GUI updates.
        """
        if self.pending_tool_update:
            self.cutting_tool_handler.cutting_tool['cnc_translation'] = [
                self.pending_xyzab['x'], self.pending_xyzab['y'], self.pending_xyzab['z']
            ]
            self.cutting_tool_handler.cutting_tool['ab_rotation'] = [
                self.pending_xyzab['a'], self.pending_xyzab['b']
            ]
            self.cutting_tool_handler.cutting_tool['material_translation'] = [
                self.pending_xyz_normal['x'], self.pending_xyz_normal['y'], self.pending_xyz_normal['z']
            ]
            self.cutting_tool_handler.cutting_tool['rotation'] = [
                self.pending_xyz_normal['nx'], self.pending_xyz_normal['ny'], self.pending_xyz_normal['nz']
            ]
            self.pending_tool_update = False
            self.stl_viewer.update()
