from cnc_usb import USBCommunicator

class CNCController:
    def __init__(self):
        self.usb = USBCommunicator()
        self.connected = False

    def connect(self):
        self.usb.connect()
        self.connected = True

    def disconnect(self):
        self.usb.disconnect()
        self.connected = False

    def is_connected(self):
        return self.usb.is_connected()


    def move_axis(self, axis, value):
        if self.is_connected():
            command = f'MOVE {axis} {value}'
            self.usb.send_command(command)

    def start_operation(self):
        if self.is_connected():
            self.usb.send_command('START')

    def stop_operation(self):
        if self.is_connected():
            self.usb.send_command('STOP')


