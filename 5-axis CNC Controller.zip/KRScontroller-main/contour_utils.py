import trimesh
import numpy as np
import matplotlib as mpl
import cv2
import networkx
from shapely.geometry import LineString
import io
from PIL import Image



class ContourUtils:
    def __init__(self, param_dict):
        """
        Initialize the ContourUtils class with parameters and cutting tool handler.
        param_dict: Dictionary containing parameters for the contour operations.
        cutting_tool_handler: Instance of the cutting tool handler to manage tool operations.
        """
        self.param_dict = param_dict
        self.cutting_tool_handler = param_dict['handlers']['cutting_tool_handler']
        self.param_dict['utils']['contour_utils'] = self
        self.mesh_utils = None
        self.layer_counter = 0

    def offset_contour(self, contour, offset_distance):
        """
        Offset a 2D contour inward or outward by a given distance.
        Returns the new contour as a list of [x, y] points.
        """
        #print(f"CONTOUR OFFSET: Offsetting contour by {offset_distance}")
        if len(contour) == 0:
            return []
        elif len(contour) < 3:
            print("CONTOUR OFFSET: Contour has less than 3 points, returning original contour.")
            return contour
        line_width = self.param_dict['line_width']
        from shapely.geometry import Polygon
        extents = self.param_dict['material_space_meshes']['raw_mesh'].extents
        # if the first point and the last point are the same, remove the end point
        poly = Polygon(contour)
        if not np.array_equal(contour[0], contour[-1]):
            poly = Polygon(np.vstack((contour, contour[0])))
        
        poly = poly.normalize()
        if not poly.is_valid:
            # If the polygon is not valid, return the original contour
            print("CONTOUR OFFSET: Polygon is not valid, returning original contour.")
            return contour
        
        # Perform the offset operation
        offset_poly = poly.buffer(offset_distance, join_style='mitre', mitre_limit=0.0001, cap_style='square', single_sided=False)
        # check if it has more than 5 points, if not, return the original contour
        if len(contour) > 4:
            offset_poly = offset_poly.simplify(tolerance=0.001, preserve_topology=True)
        
        if offset_poly is None or offset_poly.is_empty:
            print("CONTOUR OFFSET: Offset polygon is empty or invalid.")
            return []
        
        # Extract the exterior coordinates of the offset polygon
        new_contour = np.array(offset_poly.exterior.coords)  # Exclude the last point which is a repeat of the first
            
        return new_contour

    def extract_2d_contours(self, mesh, origin=[0.0000,0.0000,0.0000], normal=[0.000000,0.000000,1.000000], subdivide=False):
        """
        Extract 2D contours from a 3D mesh at a specific origin by intersecting with a plane.
        The plane normal is based on the provided normal or current tool orientation.
        Returns a list of 2D contours (lists of [x, y] points), including all inner contours (holes).
        Optionally subdivides the mesh to increase resolution for better contour detection.
        """
        print(f"CONTOUR EXTRACT: Extracting 2D contours at origin={origin}")
        if not isinstance(mesh, trimesh.Trimesh):
            print(f"CONTOUR EXTRACT: Error - Input is not a Trimesh object: {type(mesh)}")
            return []
        line_width = self.param_dict['line_width']   

        # Use the provided normal or current tool normal for the plane orientation
        if normal is None:
            tool_normal = np.array(self.cutting_tool_handler.cutting_tool['rotation'])
            if np.linalg.norm(tool_normal) == 0:
                tool_normal = np.array([0, 0, 1])
            else:
                tool_normal = tool_normal / np.linalg.norm(tool_normal)
        else:
            tool_normal = np.array(normal)
            if np.linalg.norm(tool_normal) == 0:
                tool_normal = np.array([0, 0, 1])
            else:
                tool_normal = tool_normal / np.linalg.norm(tool_normal)
        
        # Define the plane origin and normal for sectioning
        if origin is None:
            plane_origin = mesh.centroid
        else:
            plane_origin = np.array(origin)
        plane_normal = tool_normal
        
        bounds = mesh.bounds
        min_bounds = np.min(bounds, axis=0)
        max_bounds = np.max(bounds, axis=0)
        box_contour = []
        box_contour.append([min_bounds[0], min_bounds[1]])
        box_contour.append([max_bounds[0], min_bounds[1]])
        box_contour.append([max_bounds[0], max_bounds[1]])
        box_contour.append([min_bounds[0], max_bounds[1]])
        box_contour = np.array(box_contour)
        contours = []
        
        
        slices = self.mesh_utils.get_2D_slice(plane_origin, plane_normal)
        if slices is None:
                print("CONTOUR EXTRACT: No slice found, returning None")
                return None
        elif isinstance(slices, trimesh.path.Path2D):
            slices = [slices]
        outer_count = 0
        inner_count = 0
        for slice2D in slices:
            if slice2D is None:
                print("CONTOUR EXTRACT: No slice found, returning empty contours")
                return None
            
            print(f"CONTOUR EXTRACT: Slice created with {len(slice2D.vertices)} vertices")
            if slice2D is None or len(slice2D.entities) == 0:
                print("CONTOUR EXTRACT: No 2D slice entities found, returning empty contours")
                return None
            
            
            if slice2D.polygons_full is not None and len(slice2D.polygons_full) > 0:
                print(f"CONTOUR EXTRACT: Processing {len(slice2D.polygons_full)} full polygons")
                for idx, polygon in enumerate(slice2D.polygons_full):
                    print(f"CONTOUR EXTRACT: Processing polygon {idx+1}/{len(slice2D.polygons_full) } with centroid {polygon.centroid}")
                    # Extract exterior contour
                    exterior_points = list(polygon.exterior.coords)
                    if len(exterior_points) > 0:
                        contours.append(np.array(exterior_points))
                        outer_count += 1
                        print(f"CONTOUR EXTRACT: Added outer contour {idx+1}/{len(slice2D.polygons_full)} with {len(exterior_points)} points")
                    else:
                        print(f"CONTOUR EXTRACT: Outer contour {idx+1}/{len(slice2D.polygons_full)} has no points, skipped")
                    # Extract inner contours (holes)
                    inner_contours = polygon.interiors
                    print(f"CONTOUR EXTRACT: Polygon {idx+1} has {len(inner_contours)} inner contours")
                    for inner_idx, interior in enumerate(inner_contours):
                        interior_points = list(interior.coords)
                        if len(interior_points) > 0:
                            contours.append(np.array(interior_points))
                            inner_count += 1
                            print(f"CONTOUR EXTRACT: Added inner contour {inner_idx+1}/{len(inner_contours)} for polygon {idx+1} with {len(interior_points)} points")
                        else:
                            print(f"CONTOUR EXTRACT: Inner contour {inner_idx+1}/{len(inner_contours)} for polygon {idx+1} has no points, skipped")
            else:
                print(f"CONTOUR EXTRACT: No full polygons, processing {len(slice2D.entities)} entities")
                for idx, entity in enumerate(slice2D.entities):
                    if hasattr(entity, 'points'):
                        points = np.array(entity.points)
                        if points.ndim == 1:
                            contours.append(points.reshape(-1, 3)[:, :2])
                            outer_count += 1
                            print(f"CONTOUR EXTRACT: Added entity contour {idx+1}/{len(slice2D.entities)} with {len(points)} points (reshaped)")
                        elif points.ndim == 2:
                            contours.append(points[:, :2])  # Extract only x, y coordinates
                            outer_count += 1
                            print(f"CONTOUR EXTRACT: Added entity contour {idx+1}/{len(slice2D.entities)} with {len(points)} points")
                        else:
                            print(f"CONTOUR EXTRACT: Unexpected points dimension for entity {idx+1}: {points.ndim}")
                    else:
                        print(f"CONTOUR EXTRACT: Unexpected entity type for entity {idx+1}: {type(entity)}")
            
        print(f"CONTOUR EXTRACT: Extracted {len(contours)} contours (Outer: {outer_count}, Inner: {inner_count})")
        return contours if contours else None
       
    def is_point_inside_contour(self, x, y, contour):
        """
        Determine if a point (x, y) is inside a 2D contour using the ray-casting algorithm.
        Returns True if inside, False otherwise.
        """
        num_vertices = len(contour)
        inside = False
        j = num_vertices - 1

        for i in range(num_vertices):
            if (((contour[i][1] > y) != (contour[j][1] > y)) and
                (x < (contour[j][0] - contour[i][0]) * (y - contour[i][1]) /
                 (contour[j][1] - contour[i][1]) + contour[i][0])):
                inside = not inside
            j = i

        return inside

    def contours_to_mesh(self, contours, origin=[0.0000,0.0000,0.0000], normal=[0.000000,0.000000,1.000000]):
        """
        Convert a list of 2D contours back to a 3D mesh at the given Z level.
        Returns a Trimesh object with non-zero volume by extruding the contours.
        """
        if contours is None or not isinstance(contours, (list, np.ndarray)):
            print("CONTOUR MESH: No valid contours provided, returning empty mesh")
            return trimesh.Trimesh()
        
        from shapely.geometry import LineString
        layer_height = self.param_dict['layer_height']
        line_width = self.param_dict['line_width']
        raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
        points_3d = []
        faces = []
        vertex_offset = 0
        
        if origin is None:
            origin = [0, 0, 0]
        if normal is None:
            normal = [0, 0, 1]

        # Handle both single contour and list of contours
        if contours is not None and isinstance(contours, (list, np.ndarray)) and len(contours) > 0:
            contour_list = contours
        elif contours is None:
            return trimesh.Trimesh()
        else:
            contour_list = [contours]

        for contour in contour_list:
            if len(contour) < 3:
                continue
                
            if len(contour) > 4:
                # Simplify contour using Douglas-Peucker algorithm
                line = LineString(contour)
                simplified_line = line.simplify(tolerance=0.001, preserve_topology=True)  # Adjust tolerance as needed
                simplified_contour = np.array(simplified_line.coords)
                if len(simplified_contour) < 3:
                    simplified_contour = contour  # Fallback to original if simplification results in too few points
            else:
                simplified_contour = contour
            num_points = len(simplified_contour)
            # Create top and bottom layers of vertices for extrusion
            for point in simplified_contour:
                if hasattr(point, '__len__') and len(point) >= 2:
                    # Bottom layer at z_level
                    points_3d.append([point[0], point[1], 0])
                    # Top layer at z_level + extrusion_height
                    points_3d.append([point[0], point[1], layer_height])
            
            # Create faces for the bottom layer (fan triangulation)
            for i in range(1, num_points - 1):
                faces.append([vertex_offset, vertex_offset + i * 2, vertex_offset + (i + 1) * 2])
            
            # Create faces for the top layer (fan triangulation, reversed order for correct orientation)
            top_offset = vertex_offset + 1
            for i in range(1, num_points - 1):
                faces.append([top_offset, top_offset + (i + 1) * 2, top_offset + i * 2])
            
            # Create side faces to connect top and bottom layers
            for i in range(num_points):
                bottom1 = vertex_offset + i * 2
                bottom2 = vertex_offset + ((i + 1) % num_points) * 2
                top1 = bottom1 + 1
                top2 = bottom2 + 1
                # Two triangles per side face
                faces.append([bottom1, bottom2, top1])
                faces.append([bottom2, top2, top1])
            
            vertex_offset += num_points * 2
        
        if not points_3d:
            print("CONTOUR MESH: No valid points in contours, returning empty mesh")
            return trimesh.Trimesh()
            
        mesh = trimesh.Trimesh(vertices=points_3d, faces=faces if faces else [])
        transform = self.cutting_tool_handler.get_test_cutting_tool_mesh('XYZ + Normal', origin[0], origin[1], origin[2], normal[0], normal[1], normal[2], b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], elbow_up=self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000)[1]
        mesh.apply_transform(transform)
        # Attempt to repair the mesh to ensure it's a valid volume
        
        
        print(f"CONTOUR MESH: Created mesh with {mesh.extents} extents and {len(mesh.vertices)} vertices of volume {mesh.volume}")
        return mesh

    def get_contour_origin(self, contour, origin=[0.0000,0.0000,0.0000], normal=[0.000000,0.000000,1.000000]):
        """
        Get the origin of the bounding box of the mesh.
        Returns a 3D point representing the center of the bounding box.
        """
        if not self.contour_is_valid(contour):
            return None
        if len(contour) < 3:
            if len(contour)==1:
                contour_origin = contour[0]
                nearest_stl = self.mesh_utils.get_nearest_stl(contour_origin, normal)
                in_interior = self.cutting_tool_handler.is_valid_cut('XYZ + Normal', contour_origin[0], contour_origin[1], contour_origin[2], normal[0], normal[1], normal[2], b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], elbow_up=(self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000))
                is_convex = True
                return contour_origin, nearest_stl, in_interior, is_convex
            elif len(contour)==2:
                contour_origin = np.mean(np.array(contour), axis=0)
                nearest_stl = self.mesh_utils.get_nearest_stl(contour_origin, normal)
                in_interior = self.cutting_tool_handler.is_valid_cut('XYZ + Normal', contour_origin[0], contour_origin[1], contour_origin[2], normal[0], normal[1], normal[2], b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], elbow_up=(self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0))
                is_convex = True
                return contour_origin, nearest_stl, in_interior, is_convex
                
        #print(f"CONTOUR ORIGIN: Getting contour origin for contour with {len(contour)} points")
        #if len(contour) < 5:
            #print(f"Points: {contour}")
        # if the first and last points are the same, remove the last point for the centroid calculation
        check_contour = self.remove_duplicate_points(contour)
        if check_contour is None:
            check_contour = contour.copy()
        contour_centroid = np.mean(np.round(check_contour,4), axis=0)
        #print(f"CONTOUR ORIGIN: Contour centroid is {contour_centroid}")
        #print(f"CONTOUR ORIGIN: Origin used for transformation is {origin}")
        # Determine if the shape is convex or concave (simplified check based on centroid)
        if contour_centroid is None or np.isnan(contour_centroid).any():
            print("CONTOUR ORIGIN: Contour centroid is NaN, returning None")
            nearest_stl = self.mesh_utils.get_nearest_stl(origin, normal)
            return origin, nearest_stl, True, True
        # Reconstruct 3D centroid for containment check
        
        v1, v2 = self.get_v1_v2(normal)
        
        contour_origin = origin + v1 * contour_centroid[0] + v2 * contour_centroid[1]
       
        nearest_stl = self.mesh_utils.get_nearest_stl(contour_origin, normal)
        
        in_interior = self.cutting_tool_handler.is_valid_cut('XYZ + Normal', contour_origin[0], contour_origin[1], contour_origin[2], normal[0], normal[1], normal[2], b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], elbow_up=(self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000))
        is_convex = self.is_point_inside_contour(contour_origin[0], contour_origin[1], contour)
        return contour_origin, nearest_stl, in_interior, is_convex

    def calculate_contour_area(self, contour):
        """
        Calculate the area of a contour.
        Args:
            contour (numpy.ndarray): Contour points.
        Returns:
            float: Area of the contour.
        """
        
        
        if not self.contour_is_valid(contour):
            #print("CONTOUR AREA: Invalid contour, returning 0 area")
            return -1, contour
        
        test_contour = np.array(contour.copy())
        # Calculate the area of the polygon
        area = 0.5 * np.sum(np.cross(test_contour[1:] - test_contour[:-1], np.roll(test_contour[1:] - test_contour[:-1], 1)))

        if area < 0:
            area = -area
            test_contour = np.flip(test_contour, axis=0)

        return area, test_contour.copy()

    def find_path_points_inside_contour(self, contour, path_line, tool_path):
        path_points_inside = []
        tool_path_points_inside = []
        contour_poly = mpl.path.Path(contour)
        for i in range(len(tool_path)):
            
           
            if contour_poly.contains_points([(path_line[i]['xyz_normal']['x'], path_line[i]['xyz_normal']['y'])]):
                #print("FOUND CONTOUR PATH: Point inside contour:", path_line[i])
                path_points_inside.append(path_line[i])
                tool_path_points_inside.append(tool_path[i])
        return path_points_inside, tool_path_points_inside

    def set_mesh_utils(self, mesh_utils):
        """
        Set the mesh_utils attribute for the ContourUtils instance.
        mesh_utils: Instance of the mesh utilities class to handle mesh operations.
        """
        self.mesh_utils = mesh_utils

    def slice_to_contours(self, slice2D):
        """
        Convert a slice object to contours.
        Returns a list of 2D contours (lists of [x, y] points).
        """
        
        if slice2D is None:
            print("SLICE TO CONTOUR: No slice found, returning empty contours")
            return None
        
        #print(f"SLICE TO CONTOUR: Processing slice with {len(slice2D.vertices)} vertices")
        if slice2D is None or len(slice2D.entities) == 0:
            print("SLICE TO CONTOUR: No 2D slice entities found, returning empty contours")
            return None
        #scene = slice2D.scene()
        #bytes_ = scene.save_image()

        #image = Image.open(io.BytesIO(bytes_))
        #image.save(f"image{self.layer_counter}.png")
        #self.layer_counter += 1
        outer_count = 0
        inner_count = 0
        extents = self.param_dict['material_space_meshes']['raw_mesh'].extents
        tool_diameter = self.param_dict['tool_diameter']
        layer_height = self.param_dict['layer_height']
        line_width = self.param_dict['line_width']
        contours = []
        _ = slice2D.polygons_full
        if slice2D.polygons_full is not None and len(slice2D.polygons_full) > 0:
            for idx, polygon in enumerate(slice2D.polygons_full):
                #print(f"SLICE TO CONTOUR: Polygon {idx+1}/{len(slice2D.polygons_full) } has centroid {np.round(polygon.centroid,4)} and area {np.round(polygon.area,8)}")
                # Extract exterior contour
                exterior_points = list(polygon.exterior.coords)
                if len(exterior_points) > 4:
                    line = LineString(exterior_points)
                    simplified_line = line.simplify(tolerance=0.001, preserve_topology=True)
                    if isinstance(simplified_line, LineString) and not simplified_line.is_empty and len(simplified_line.coords) > 0:
                        exterior_points = list(simplified_line.coords)
                if len(exterior_points) > 2:
                    contours.append(np.array(exterior_points))
                    outer_count += 1
                    #print(f"SLICE TO CONTOUR: Added outer contour {idx+1}/{len(slice2D.polygons_full)} with {len(exterior_points.coords)} points")
                #else:
                  #  print(f"SLICE TO CONTOUR: Outer contour {idx+1}/{len(slice2D.polygons_full)} has no points, skipped")
                # Extract inner contours (holes)
                inner_contours = polygon.interiors
                #print(f"SLICE TO CONTOUR: Polygon {idx+1} has {len(inner_contours)} inner contours")
                for inner_idx, interior in enumerate(inner_contours):
                    #print(f"SLICE TO CONTOUR: Inner contour {inner_idx+1}/{len(inner_contours)} has centroid {np.round(interior.centroid,4)}")
                    interior_points = list(interior.coords)
                    if len(interior_points) > 4:
                        line = LineString(interior_points)
                        simplified_line = line.simplify(tolerance=0.001, preserve_topology=True)  # Adjust tolerance as needed
                        if isinstance(simplified_line, LineString) and not simplified_line.is_empty and len(simplified_line.coords) > 0:
                            interior_points = list(simplified_line.coords)
                        contours.append(np.array(interior_points))
                        inner_count += 1
                        #print(f"SLICE TO CONTOUR: Added inner contour {inner_idx+1}/{len(inner_contours)} for polygon {idx+1} with {len(interior_points.coords)} points")
                    else:
                        if len(interior_points) > 0:
                            contours.append(np.array(interior_points))
                            inner_count += 1
                        #else:
                            #print(f"SLICE TO CONTOUR: Inner contour {inner_idx+1}/{len(inner_contours)} for polygon {idx+1} has no points, skipped")
        
        #print(f"SLICE TO CONTOUR: {len(contours)} contours: Extracted (Outer: {outer_count}, Inner: {inner_count}) contours.")
        return contours if contours else None
    
    def contour_is_valid(self, contour):
        """
        Check if a contour is valid (not empty and has at least 3 points).
        Returns True if valid, False otherwise.
        """
        if contour is None:
            #print("CONTOUR VALID: Contour is None")
            return False
        if isinstance(contour, list):
            if len(contour) == 0:
                #print("CONTOUR VALID: Contour contains no points")
                return False
            #print(f"CONTOUR VALID: Contour contains {len(contour)} points")
            #return True
        if isinstance(contour, np.ndarray):
            if contour.ndim==1:
                contour = contour.reshape(-1, 2)
            if contour.shape[0] < 2:
                #print("CONTOUR VALID: Contour contains no points")
                return False
            #print(f"CONTOUR VALID: Contour contains {contour.shape[0]} points, shape: {contour.shape}")
        return True
    
    def contours_are_equal(self, contour1, contour2, tolerance=0.001):
        """
        Check if two contours are approximately equal, accounting for rotation and flipping.
        Returns True if equal within tolerance, False otherwise.
        """
        if contour1 is None or contour2 is None:
            return False
        if len(contour1) != len(contour2):
            return False
        
        # Convert to numpy arrays if not already
        c1 = np.array(contour1)
        c2 = np.array(contour2)
        
        # If contours have less than 3 points, compare directly
        if len(c1) < 3:
            return np.allclose(c1, c2, atol=tolerance)
        
        # Find the index of the point with the smallest x-coordinate (then smallest y if tied)
        def find_starting_point(contour):
            min_idx = 0
            min_val = contour[0][0]  # Start with x-coordinate
            min_y = contour[0][1]
            for i in range(1, len(contour)):
                if contour[i][0] < min_val or (contour[i][0] == min_val and contour[i][1] < min_y):
                    min_val = contour[i][0]
                    min_y = contour[i][1]
                    min_idx = i
            return min_idx
        
        start1 = find_starting_point(c1)
        start2 = find_starting_point(c2)
        
        # Roll the contours to start from the chosen point
        c1_rolled = np.roll(c1, -start1, axis=0)
        c2_rolled = np.roll(c2, -start2, axis=0)
        
        # Check both forward and reverse order (to handle flipping)
        if np.allclose(c1_rolled, c2_rolled, atol=tolerance):
            return True
        if np.allclose(c1_rolled, np.flip(c2_rolled, axis=0), atol=tolerance):
            return True
        
        # If not matching yet, try all cyclic shifts for c2 to be thorough (in case starting point logic differs)
        n = len(c2)
        for shift in range(n):
            c2_shifted = np.roll(c2, shift, axis=0)
            if np.allclose(c1_rolled, c2_shifted, atol=tolerance) or np.allclose(c1_rolled, np.flip(c2_shifted, axis=0), atol=tolerance):
                return True
        
        return False

    def make_contours_unique(self, contours, unique_contours=[], tolerance=0.001):
        """
        Make a list of contours unique by removing duplicates.
        Returns a list of unique contours.
        """
        if contours is None:
            return contours, unique_contours, False
        
        check_contours = unique_contours.copy()
        local_unique_contours = []
        for contour in contours:
            if not any(self.contours_are_equal(np.round(contour,4), np.round(uc, 4), tolerance=tolerance) for uc in check_contours):
                if contour is not None and len(contour) > 0:
                    local_unique_contours.append(contour)
                    check_contours.append(contour)
        if len(check_contours) == len(unique_contours):
            #print("MAKE CONTOURs UNIQUE: No unique contours found")
            return local_unique_contours.copy(), check_contours.copy(), False
        #print(f"MAKE CONTOURS UNIQUE: Found {len(unique_contours)} unique contours")
        return local_unique_contours.copy(), check_contours.copy(), True
    
    def get_contour_graph(self, contours):
        """
        Create a graph from a list of contours.
        Returns a networkx graph object.
        """
        if contours is None:
            return None
        G = networkx.Graph()
        for contour in contours:
            if len(contour) < 3:
                continue
            for i in range(len(contour)):
                p1 = tuple(np.round(contour[i], 4))
                p2 = tuple(np.round(contour[(i + 1) % len(contour)], 4))
                G.add_edge(p1, p2)
        return G
    
    def sort_contours_smallest_to_largest(self, contours):
        """
        Sort a list of contours from smallest to largest based on their area.
        Returns a sorted list of contours.
        """
        if contours is None:
            return None
        
        if isinstance(contours, (list,list)):
            new_contours = []
            for sub_contours in contours:
                contour_areas = [self.calculate_contour_area(c)[0] for c in sub_contours]
                sorted_indices = np.argsort(contour_areas)
                sorted_contours = [sub_contours[i] for i in sorted_indices]
                new_contours.append(sorted_contours.copy())
            return new_contours

        contour_areas = [self.calculate_contour_area(c)[0] for c in contours]
        sorted_indices = np.argsort(contour_areas)
        sorted_contours = [contours[i] for i in sorted_indices]
        return sorted_contours
    
    def get_contour_from_point(self, point, normal=[0,0,1], offset_distance=0.1):
        """
        Create a contour from a single point.
        Returns a list of points representing the contour.
        """
        if point is None:
            return None
        
        point1 = point.copy()
        point2 = point.copy()
        point3 = point.copy()
        point4 = point.copy()
        dim = len(point)
        Z_DOWN = self.param_dict['Z_DOWN'] 
        if Z_DOWN:
            point1[1] = point1[1] - offset_distance
            point2[0] = point2[0] - offset_distance
            point3[1] = point3[1] + offset_distance
            point4[0] = point4[0] + offset_distance
        else:
            # make the points into a square on the normal plane around the point with the offset distance as the length of the square
            v1, v2 = self.get_v1_v2(normal)
            if v1 is None or v2 is None:
                point1[1] = point1[1] - offset_distance
                point2[0] = point2[0] - offset_distance
                point3[1] = point3[1] + offset_distance
                point4[0] = point4[0] + offset_distance
            else:
                point1 = point + offset_distance * v1 + offset_distance * v2
                point2 = point + offset_distance * v1 - offset_distance * v2
                point3 = point - offset_distance * v1 - offset_distance * v2
                point4 = point - offset_distance * v1 + offset_distance * v2
                

        return [point1, point2, point3, point4, point1]
    
    def contour_is_unique(self, contour, contours=[]):
        """
        Check if a contour is unique in a list of contours.
        Returns True if unique, False otherwise.
        """
        if contours is None or len(contours) == 0:
            return True
        for c in contours:
            if self.contours_are_equal(np.round(contour,3), np.round(c, 3)):
                print(f"CONTOUR IS UNIQUE: Contour is not unique, found in contours")
                return False
        print(f"CONTOUR IS UNIQUE: Contour is unique")
        return True
    
    def get_v1_v2(self, normal=[0.000000, 0.000000, 1.000000]):
        """
        Get two orthogonal vectors (v1, v2) in the plane defined by the normal vector.
        Returns two orthogonal vectors.
        """
        if normal is None:
            return None, None
        normal = np.array(normal)
        if np.linalg.norm(normal) == 0:
            return None, None
        normal = normal / np.linalg.norm(normal)
        Z_DOWN = self.param_dict['Z_DOWN']
        if Z_DOWN:
            v1 = [1.000000, 0.000000, 0.000000]
            v2 = [0.000000, 1.000000, 0.000000]
        else:
            # define the z axis for v1 and v2
            if abs(normal[2]) > 0.999999:
                u = np.array([0.000000, 1.000000, 0.000000]) # if A tilts, z axis moves to y axis
            else:
                u = np.array([0.000000, 0.000000, 1.000000])
            v1 = np.cross(normal, u)
            if np.linalg.norm(v1) < 0.000001:
                u = np.array([1.000000, 0.000000, 0.000000]) # if B moves while A is tilted, z axis moves to x axis
                v1 = np.cross(normal, u)
            v1 = np.array(v1) / np.linalg.norm(v1)
            v2 = np.cross(normal, v1)
            v2 = np.array(v2) / np.linalg.norm(v2)
        return np.array(v1), np.array(v2)
    
    def remove_duplicate_points(self, contour):
        """
        Remove duplicate points from a contour.
        Returns a new contour with duplicates removed.
        """
        if contour is None:
            return None
        if len(contour) < 3:
            return contour
        unique_contour = np.unique(contour, axis=0)
            
        return np.array(unique_contour).copy()
        
    def is_clockwise(contour):
        """
        Checks if a contour is oriented clockwise.

        Args:
            contour: A NumPy array of shape (N, 2) where each row represents a point
                    in the contour.

        Returns:
            True if the contour is clockwise, False otherwise.
        """
        if contour is None or len(contour) < 3:
            return False
        test_contour = np.array(contour.copy())
        # Calculate the area of the polygon
        area = 0.5 * np.sum(np.cross(test_contour[1:] - test_contour[:-1], np.roll(test_contour[1:] - test_contour[:-1], 1)))
        
        # Check if the area is negative (clockwise)
        return area < 0

    def reverse_contour(self, contour):
        """
        Reverse the direction of a contour.
        Returns the reversed contour.
        """
        if contour is None or len(contour) < 2:
            return contour
        print("CONTOUR REVERSE: Reversing contour")             
        return list(np.flip((contour.copy()), axis=0))


