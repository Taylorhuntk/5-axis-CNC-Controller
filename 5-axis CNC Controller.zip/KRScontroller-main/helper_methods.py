from decimal import Decimal, getcontext
import numpy as np
import math

class Helpers:
    def __init__(self):
        pass

    def convert_to_cm(self, value, unit):
        if unit == 'MM':
            return float(Decimal(value)/Decimal(10.0))
        elif unit == 'CM':
            return float(value)
        elif unit == 'IN':
            return float(Decimal(value)*Decimal(2.54))
        elif unit == 'MIL':
            return float(Decimal(value)*Decimal(0.00254))
        return value

    def convert_from_cm(self, value, unit):
        if unit == 'MM':
            return value * 10.0
        elif unit == 'CM':
            return value
        elif unit == 'IN':
            return value / 2.54  # Use exact value for inches
        elif unit == 'MIL':
            return value / 0.00254  # Use exact value for mils
        return value

    def quaternion_multiply(self, q1, q2):
        """Multiply two quaternions (w, x, y, z)."""
        w1, x1, y1, z1 = q1
        w2, x2, y2, z2 = q2
        w = w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2
        x = w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2
        y = w1 * y2 - x1 * z2 + y1 * w2 + z1 * x2
        z = w1 * z2 + x1 * y2 - y1 * x2 + z1 * w2
        return [w, x, y, z]

    def quaternion_from_euler(self, roll, pitch, yaw):
        """Convert Euler angles (degrees) to quaternion (w, x, y, z)."""
        roll = np.radians(roll)
        pitch = np.radians(pitch)
        yaw = np.radians(yaw)
        cr = np.cos(roll * 0.5)
        sr = np.sin(roll * 0.5)
        cp = np.cos(pitch * 0.5)
        sp = np.sin(pitch * 0.5)
        cy = np.cos(yaw * 0.5)
        sy = np.sin(yaw * 0.5)
        w = cr * cp * cy + sr * sp * sy
        x = sr * cp * cy - cr * sp * sy
        y = cr * sp * cy + sr * cp * sy
        z = cr * cp * sy - sr * sp * cy
        return [w, x, y, z]

    def euler_from_quaternion(self, q):
        """Convert quaternion (w, x, y, z) to Euler angles (degrees)."""
        w, x, y, z = q
        t0 = 2.0 * (w * x + y * z)
        t1 = 1.0 - 2.0 * (x * x + y * y)
        roll = np.degrees(np.atan2(t0, t1))
        t2 = 2.0 * (w * y - z * x)
        t2 = 1.0 if t2 > 1.0 else t2
        t2 = -1.0 if t2 < -1.0 else t2
        pitch = np.degrees(np.asin(t2))
        t3 = 2.0 * (w * z + x * y)
        t4 = 1.0 - 2.0 * (y * y + z * z)
        yaw = np.degrees(np.atan2(t3, t4))
        return [roll, pitch, yaw]

