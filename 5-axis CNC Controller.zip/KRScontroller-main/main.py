import sys
from PyQt5.QtWidgets import QApplication
from cnc_gui import CNCGUI

def main():
    app = QApplication(sys.argv)
    gui = CNCGUI()
    gui.resize(800,600)
    gui.showMaximized()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()