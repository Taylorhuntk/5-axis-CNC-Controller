# File: opengl_utils.py
from OpenGL.GL import *
from OpenGL.GLU import *
import numpy as np


def normalize_vector(vector):
    """Normalize a vector to unit length, handling zero magnitude case."""
    normal = np.array(vector, dtype=np.float32)
    norm = np.linalg.norm(normal)
    if norm > 0:  # Avoid division by zero
        normal = normal / norm
    return normal

def compute_face_normal(v0, v1, v2):
    """Compute the normal vector of a face defined by three vertices."""
    edge1 = v1 - v0
    edge2 = v2 - v0
    normal = np.cross(edge1, edge2)
    norm = np.linalg.norm(normal)
    if norm > 0:  # Avoid division by zero
        normal = normal / norm
    return normal


def create_stl_display_lists(stl_model):
    # Create display list for solid rendering
    display_list = glGenLists(1)
    glNewList(display_list, GL_COMPILE)
    glBegin(GL_TRIANGLES)
    for triangle in stl_model.vectors:
        normal = compute_face_normal(triangle[0], triangle[1], triangle[2])
        normal = normalize_vector(normal)
        glNormal3fv(normal)
        for vertex in triangle:
            glVertex3fv(vertex)
    glEnd()
    glEndList()

    # Create display list for wireframe rendering
    edge_to_triangles = {}
    triangle_normals = []
    for i, triangle in enumerate(stl_model.vectors):
        normal = np.cross(triangle[1] - triangle[0], triangle[2] - triangle[0])
        normal = normalize_vector(normal)
        triangle_normals.append(normal)
        edges = [
            tuple(sorted((tuple(triangle[0]), tuple(triangle[1])))),
            tuple(sorted((tuple(triangle[1]), tuple(triangle[2])))),
            tuple(sorted((tuple(triangle[2]), tuple(triangle[0])))),
        ]
        for edge in edges:
            if edge not in edge_to_triangles:
                edge_to_triangles[edge] = []
            edge_to_triangles[edge].append(i)

    boundary_edges = []
    for edge, triangles in edge_to_triangles.items():
        if len(triangles) == 1 or (len(triangles) == 2 and not np.allclose(
                triangle_normals[triangles[0]], triangle_normals[triangles[1]], atol=1e-6)):
            boundary_edges.append(edge)

    wireframe_list = glGenLists(1)
    glNewList(wireframe_list, GL_COMPILE)
    glBegin(GL_LINES)
    for edge in boundary_edges:
        glVertex3fv(edge[0])
        glVertex3fv(edge[1])
    glEnd()
    glEndList()

    return display_list, wireframe_list
