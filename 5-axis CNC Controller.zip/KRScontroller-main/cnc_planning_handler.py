# File: cnc_planning_handler.py
import numpy as np
import trimesh
from mesh_utils import MeshUtils as mesh_utils
from contour_utils import ContourUtils as contour_utils

class CNCPlanningHandler:
    def __init__(self, gui):
        self.gui = gui
        self.raw_material_handler = gui.raw_material_handler
        self.cutting_tool_handler = gui.cutting_tool_handler
        self.update_cut_volume = False
        self.cnc_properties_handler = gui.cnc_properties_handler
        self.stl_handler = gui.stl_handler
        self.stepover = 0.5  # Default stepover percentage
        self.mesh_utils = None
        self.contour_utils = None
        self.has_path = False
        self.has_tool_path = False
        self.found_stl = False
        self.x_found_STL = 0
        self.z_retraction_point = 30.0  # Default Z retraction point
        self.cached_limits = None  # Cache limits to avoid GUI access in worker thread
        self.param_dict = {
            'path': [],
            'tool_path': [],
            'path_type': 'concentric',
            'cutting_volume_rate': 1.0,
            'initial_to_be_cut_volume': 0.0,
            'current_to_be_cut_volume': 0.0,
            'unreachable_volume': 0.0,
            'finished': False,
            'total_volume': 0.0,
            'total_time': 0,
            'percentage_removed': 0.0,
            'speed': 1.0,
            'acceleration': 1.0,
            'stepover': 0.5,
            'layer_height': 0.1,
            'tool_diameter': self.cutting_tool_handler.cutting_tool['dimensions'][0],
            'tool_radius': self.cutting_tool_handler.cutting_tool['dimensions'][0]/2.0,
            'tool_area': np.pi*(self.cutting_tool_handler.cutting_tool['dimensions'][0]/2.0)**2,  # Cross-sectional area of the tool
            'stepover_radius': self.cutting_tool_handler.cutting_tool['dimensions'][0]/4.0,
            'stepover_area': np.pi*(self.cutting_tool_handler.cutting_tool['dimensions'][0]/4.0)**2,  # Cross-sectional area of the stepover circle
            'cut_area': np.pi*(self.cutting_tool_handler.cutting_tool['dimensions'][0]/2.0)**2 - np.pi*(self.cutting_tool_handler.cutting_tool['dimensions'][0]/4.0)**2,  # Area of the cut circle
            'line_width': self.cutting_tool_handler.cutting_tool['dimensions'][0]/4.0,
            'tolerance': 0.001,
            'cnc_translation': self.cutting_tool_handler.cutting_tool['cnc_translation'].copy(),
            'ab_rotation': self.cutting_tool_handler.cutting_tool['ab_rotation'].copy(),
            'translation': self.cutting_tool_handler.cutting_tool['material_translation'].copy(),
            'rotation': self.cutting_tool_handler.cutting_tool['rotation'].copy(),
            'cspace_matrix' : np.eye(3),
            'contours': {
                'unique_contours': [],
                'unique_cuts': []
            },
            'material_space_meshes': {
                'cut_volume_mesh': trimesh.Trimesh(),
                'unreachable_mesh': trimesh.Trimesh(),
                'protected_meshes': [],
                'stl_meshes': [],
                'raw_mesh': trimesh.Trimesh(),
                'to_be_cut': trimesh.Trimesh()},
            'cspace_meshes': {
                'cut_volume_mesh': trimesh.Trimesh(),
                'unreachable_mesh': trimesh.Trimesh(),
                'protected_meshes': [],
                'stl_meshes': [],
                'raw_mesh': trimesh.Trimesh(),
                'to_be_cut': trimesh.Trimesh()},
            'callbacks': {
                'update_progress_callback': None,
                'update_output_callback': None,
                'cancel_check_callback': None,
                'update_tool_position_callback': None},
            'global_step_count': 0,
            'Z_DOWN': True,
            'handlers': {
            'planning_handler': self,
            'raw_material_handler': self.raw_material_handler,
            'cutting_tool_handler': self.cutting_tool_handler,
            'cnc_properties_handler': self.cnc_properties_handler,
            'stl_handler': self.stl_handler
            },
            'gui': self.gui,
            'utils': {
                'mesh_utils': None,
                'contour_utils': None
            }
        }
              
    def plan_path(self, path_type, cutting_volume_rate, speed, acceleration, stepover, update_progress_callback=None, update_output_callback=None, cancel_check_callback=None, update_tool_position_callback=None):
        # Step 1: Collect protected meshes (keepouts and STL objects) and create "to be cut" volume
        self.param_dict['handlers'] = {
            'planning_handler': self,
            'mesh_utils': None,
            'contour_utils': None,
            'raw_material_handler': self.raw_material_handler,
            'cutting_tool_handler': self.cutting_tool_handler,
            'cnc_properties_handler': self.cnc_properties_handler,
            'stl_handler': self.stl_handler
            }
        self.param_dict['callbacks'] = {
            'update_progress_callback': update_progress_callback,
            'update_output_callback': update_output_callback,
            'cancel_check_callback': cancel_check_callback,
            'update_tool_position_callback': update_tool_position_callback
            }

        self.contour_utils = contour_utils(param_dict=self.param_dict)
        self.param_dict['utils']['contour_utils'] = self.contour_utils
        self.mesh_utils = mesh_utils(param_dict=self.param_dict)
        self.param_dict['utils']['mesh_utils'] = self.mesh_utils
        self.contour_utils.set_mesh_utils(self.mesh_utils)
        self.cutting_tool_handler.set_param_dict(self.param_dict)
        if update_output_callback:
            update_output_callback("Initializing planner...")# Ensure path_type is a string; if it's a boolean, default to 'optimized'

        tool_diameter = self.cutting_tool_handler.cutting_tool['dimensions'][0]
        tool_radius = tool_diameter / 2.0
        tool_area = np.pi * (tool_radius ** 2)  # Cross-sectional area of the tool
        stepover_radius = tool_radius * stepover
        stepover_area = np.pi * (stepover_radius ** 2)  # Cross-sectional area of the stepover circle
        cut_area = tool_area - stepover_area  # Area of the cut circle
        line_width = tool_radius - stepover_radius  # Effective width of the cut
        vertical_step_layer_height = cutting_volume_rate / (cut_area*speed)
        horizontal_step_layer_height = cutting_volume_rate / (line_width*speed)  # Horizontal step based on cutting volume rate
        layer_height = np.max([0.0001, np.min([line_width, vertical_step_layer_height, horizontal_step_layer_height])]) # Layer height based on stepover percentage of tool diameter
        tolerance = np.min([line_width, layer_height]) * 0.5  # Tolerance for contouring

        if not isinstance(path_type, str):
            if update_output_callback:
                update_output_callback("Warning: path_type is not a string; defaulting to concentric.")
            path_type = 'concentric'
        self.param_dict['tolerance'] = tolerance
        success, message = self.mesh_utils.initialize_meshes()

        if not success:
            if update_output_callback:
                update_output_callback(f"Mesh failed to initialize. Error: {message}")
            return {'path': [], 'total_volume': 0, 'total_time': 0, 'percentage_removed': 0,
                    'cut_volume_stl': None, 'unreachable_stl': None, 'tool_path': None,
                    'num_steps': 0, 'path_length': 0.0, 'unreachable_volume': 0.0}
        else:
            if update_output_callback:
                update_output_callback(f"{message}")
        # Store stepover value
        self.stepover = stepover/100.0  # Convert to decimal

        # Store original tool position to restore after planning
        original_cnc_translation = self.cutting_tool_handler.cutting_tool['cnc_translation'].copy()
        original_ab_rotation = self.cutting_tool_handler.cutting_tool['ab_rotation'].copy()
        original_material_translation = self.cutting_tool_handler.cutting_tool['material_translation'].copy()
        original_rotation = self.cutting_tool_handler.cutting_tool['rotation'].copy()

        # Cache limits before planning to avoid GUI access in worker thread
        self.cached_limits = {
            'x_min': round(self.cnc_properties_handler.limits['x_min'], 4),
            'x_max': round(self.cnc_properties_handler.limits['x_max'], 4),
            'y_min': round(self.cnc_properties_handler.limits['y_min'], 4),
            'y_max': round(self.cnc_properties_handler.limits['y_max'], 4),
            'z_min': round(self.cnc_properties_handler.limits['z_min'], 4),
            'z_max': round(self.cnc_properties_handler.limits['z_max'], 4),
            'a_min': round(self.cnc_properties_handler.limits['a_min'], 3),
            'a_max': round(self.cnc_properties_handler.limits['a_max'], 3),
            'b_min': round(self.cnc_properties_handler.limits['b_min'], 3),
            'b_max': round(self.cnc_properties_handler.limits['b_max'], 3)
        }
        self.cutting_tool_handler.cached_limits = self.cached_limits

        

        
        print(f"Layer height: {layer_height:.4f}, Line width: {line_width:.4f}")
        if update_output_callback:
            update_output_callback(f"Layer height: {layer_height:.4f}, Line width: {line_width:.4f}")
        
        
        if cancel_check_callback and cancel_check_callback():
            self.cutting_tool_handler.cutting_tool['cnc_translation'] = original_cnc_translation
            self.cutting_tool_handler.cutting_tool['ab_rotation'] = original_ab_rotation
            self.cutting_tool_handler.cutting_tool['material_translation'] = original_material_translation
            self.cutting_tool_handler.cutting_tool['rotation'] = original_rotation
            return {'path': [], 'total_volume': 0, 'total_time': 0, 'percentage_removed': 0,
                    'cut_volume_stl': None, 'unreachable_stl': None, 'tool_path': None,
                    'num_steps': 0, 'path_length': 0.0, 'unreachable_volume': 0.0}

        # Step 2: Initialize path and start from current tool position
        path = []
        tool_path = []
        global_step_count = 0
        cspace_matrix = np.eye(3)
        
        # Load up the param dict 
        self.param_dict['path'] = path
        self.param_dict['tool_path'] = tool_path
        self.param_dict['path_type'] = path_type
        self.param_dict['cutting_volume_rate'] = cutting_volume_rate
        self.param_dict['finished'] = False
        self.param_dict['total_time'] = 0
        self.param_dict['percentage_removed'] = 0
        self.param_dict['speed'] = speed
        self.param_dict['acceleration'] = acceleration
        self.param_dict['stepover'] = stepover
        self.param_dict['layer_height'] = layer_height
        self.param_dict['tool_diameter'] = tool_diameter
        self.param_dict['tool_radius'] = tool_radius
        self.param_dict['tool_area'] = tool_area
        self.param_dict['stepover_radius'] = stepover_radius
        self.param_dict['stepover_area'] = stepover_area
        self.param_dict['cut_area'] = cut_area
        self.param_dict['line_width'] = line_width
        self.param_dict['cnc_translation'] = original_cnc_translation
        self.param_dict['ab_rotation'] = original_ab_rotation
        self.param_dict['translation'] = original_material_translation
        self.param_dict['rotation'] = original_rotation
        self.param_dict['cspace_matrix'] = cspace_matrix
        
        
        self.param_dict['global_step_count'] = global_step_count
        self.param_dict['Z_DOWN'] = True
        
        self.param_dict['gui'] = self.gui
        self.param_dict['utils'] = {
            'mesh_utils': self.mesh_utils,
            'contour_utils': self.contour_utils
        }
        

        if self.get_Z_down_plan():
            self.param_dict['Z_DOWN'] = False
            if update_output_callback:
                update_output_callback("Z-down path planning finished.")
        else:
            if update_output_callback:
                update_output_callback("Z-down path planning failed.")
        #unpack the dict
        if self.has_path: path = self.param_dict['path'].copy()
        if self.has_tool_path: tool_path = self.param_dict['tool_path'].copy()
        path, tool_path = self.remove_triples(path, tool_path)
        total_time = self.param_dict['total_time']
        percentage_removed = self.param_dict['percentage_removed']
        global_step_count = self.param_dict['global_step_count']
        

        # Step 6: Calculate metrics and unreachable volumes
        if update_output_callback:
            update_output_callback("Step 6: Calculating final metrics and visualizations...")
        path_length = self.calculate_path_length(tool_path)
        total_time = path_length/self.param_dict['speed']  # Rough estimate based on steps
        num_steps = len(tool_path)
        # Restore original tool position after planning is complete
        self.cutting_tool_handler.cutting_tool['cnc_translation'] = original_cnc_translation
        self.cutting_tool_handler.cutting_tool['ab_rotation'] = original_ab_rotation
        self.cutting_tool_handler.cutting_tool['material_translation'] = original_material_translation
        self.cutting_tool_handler.cutting_tool['rotation'] = original_rotation
        
        if update_output_callback:
            update_output_callback(f"Path planning completed with {global_step_count} steps.")
        
        unreachable_stl = self.mesh_utils.get_unreachable_stl()
        cut_volume_stl = self.mesh_utils.get_cut_volume_stl(tool_path)
        cut_volume = cut_volume_stl['mesh'].volume if cut_volume_stl else 0.0
        initial_to_be_cut_volume = self.param_dict['initial_to_be_cut_volume']
        percentage_removed = (cut_volume / initial_to_be_cut_volume) * 100 if initial_to_be_cut_volume > 0 else 0
        return {
            'path': path,
            'total_volume': cut_volume,
            'total_time': total_time,
            'percentage_removed': percentage_removed,
            'cut_volume_stl': cut_volume_stl,
            'unreachable_stl': unreachable_stl,
            'tool_path': tool_path,
            'num_steps': num_steps,
            'path_length': path_length,
            'unreachable_volume': self.param_dict['unreachable_volume']
        }

    def calculate_path_length(self, tool_path):
        if len(tool_path) < 2:
            return 0.0
        length = 0.0
        for i in range(len(tool_path) - 1):
            p1 = np.array(tool_path[i])
            p2 = np.array(tool_path[i + 1])
            segment_length = np.linalg.norm(p2 - p1)
            length += segment_length
        return length

    def generate_concentric_path_for_slice(self, contours, origin=[0.0000,0.0000,0.0000], normal=[0.000000,0.000000,1.000000], bounds=None, unique_contours=[], unique_cuts=[]):
        """
        Generate a concentric cutting path for a specific slice mesh using contour-based offsetting.
        Moves outside-outward for convex shapes (start at boundary, move outward) and inside-inward for concave shapes (start at boundary, move inward).
        Ensures paths for convex shapes do not extend beyond raw material boundaries.
        Uses step size as tool_diameter * stepover and limits iterations to prevent hanging.
        Returns a tuple of (path, tool_path).
        """
        print("CONCENTRIC: Entering generate_concentric_path_for_slice")
        
        if contours is None or not isinstance(contours, list) or len(contours) == 0:
            if isinstance(contours, np.ndarray):
                if contours.dim == 2:
                    contours = [contours]
                else:
                    print("CONCENTRIC: Error: Slice is not valid.")
                    return False
        
        bounds = self.param_dict['material_space_meshes']['raw_mesh'].bounds
        extents = self.param_dict['material_space_meshes']['raw_mesh'].extents
        if bounds is None:
            print("Error: Raw material mesh is not valid.")
            return False
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        update_progress_callback = self.param_dict['callbacks']['update_progress_callback']
        cancel_check_callback = self.param_dict['callbacks']['cancel_check_callback']
        update_tool_position_callback = self.param_dict['callbacks']['update_tool_position_callback']
        Z_DOWN = self.param_dict['Z_DOWN']
        line_height = self.param_dict['layer_height']
        line_width = self.param_dict['line_width']
        tolerance = self.param_dict['tolerance']
        tool_diameter = self.param_dict['tool_diameter']
        tool_radius = self.param_dict['tool_radius']    
        cut_area = self.param_dict['cut_area']
        local_step_count = 0

        # Use provided normal or default to tool normal
        if Z_DOWN:
            normal = np.array([0.000000, 0.000000, 1.000000])
        elif normal is None:
                normal = self.cutting_tool_handler.cutting_tool['rotation']
                if np.linalg.norm(normal) == 0:
                    normal = np.array([0.000000, 0.000000, 1.000000])
                else:
                    normal = normal / np.linalg.norm(normal)
        normal = normal/ np.linalg.norm(normal) if np.linalg.norm(normal) > 0 else np.array([0.000000, 0.000000, 1.000000])
        # Find nearest STL for normal-based orientation if not provided
        
        max_offset = min(extents[:2])/2 + tool_diameter
        print(f"CONCENTRIC: Max offset: {max_offset}")
        # Offset step based on tool diameter and stepover percentage
        offset_step = line_width 
        #print(f"CONCENTRIC: Offset step size: {offset_step}")
        #contours = self.contour_utils.sort_contours_smallest_to_largest(contours)[0]
        #contours = self.contour_utils.make_contours_unique(contours)[0]
        print('CONCENTRIC: Found ', len(contours), ' unique contours')
        iteration_count = 0
        for contour in contours:
            if isinstance(contour, (list, list)) and len(contour) < 3:
                print("CONCENTRIC: Contour is a list of contours.")
                for sub_contour in contour:
                    if isinstance(sub_contour, (list, np.ndarray)) and len(sub_contour) > 2:
                        print("CONCENTRIC: Found sub-contour, processing")
                        contours.append(sub_contour)
                    elif isinstance(sub_contour, np.ndarray):
                        print("CONCENTRIC: Found point, making into sub-contour")  
                        contours.append([sub_contour])
                continue
            if self.contour_utils.contour_is_unique(contour, unique_cuts) and contour is not None:
                print("CONCENTRIC: Found unique cut, processing")
                contour_u, unique_contours, has_unique = self.contour_utils.make_contours_unique([contour], unique_contours=unique_cuts, tolerance=tolerance)
                if not has_unique:
                    print("CONCENTRIC: Contour isn't unique, but has not been processed yet")
                      
            else:
                print(f"CONCENTRIC: Contour {iteration_count} already processed or invalid, skipping")
                continue

            if cancel_check_callback and cancel_check_callback():
                print("CONCENTRIC: Cancel requested during contour processing")
                return False
            if not self.contour_utils.contour_is_valid(contour):
                print("CONCENTRIC: Contour is not valid. type: ", type(contour))
                continue
            
            contour_area, current_contour = self.contour_utils.calculate_contour_area(contour)
            #print(f"CONCENTRIC: Contour area: {contour_area:.8f}")
            if contour_area is None or contour_area <= 0.0:
                print("CONCENTRIC: Contour area is invalid, skipping contour")
                continue
            contour_origin, nearest_stl, in_interior, is_convex = self.contour_utils.get_contour_origin(current_contour, origin, normal)
            
            print(f"CONCENTRIC: Contour origin: {np.round(contour_origin,4)} convex: {is_convex}, interior: {in_interior}, with area: {contour_area:.8f}")
            # Convert the initial boundary contour to path points
        

            
            
            # Outward (negative offset), inward (positive offsest)
            '''
            if in_interior:
                if is_convex:
                    direction = -1 
                else:
                    direction = -1
            else:
                if is_convex:
                    direction = -1
                else:
                    direction = -1
            '''
            direction = -1
            total_offset = 0.0
            
            contour_path, contour_tool_path = self.contour_to_path(current_contour, contour_origin, normal=normal)
            offset_distance = offset_step*direction
        
            if in_interior and (not contour_path or len(contour_path)==0):
                iters = 0
                if update_output_callback:
                    update_output_callback("Fitting the contour...")
                while (not contour_path or len(contour_path)==0 or len(contour_path)!=len(current_contour)) and contour_area > 0.0 and iters<tool_radius/0.0001:
                    current_contour = self.contour_utils.offset_contour(current_contour, offset_distance)
                    contour_area, current_contour = self.contour_utils.calculate_contour_area(current_contour)
                    contour_path, contour_tool_path = self.contour_to_path(current_contour, origin, normal=normal)
                    offset_distance = 0.0001*direction
                    iters += 1
                    if update_progress_callback:
                        update_progress_callback(100.0*iters/(tool_radius/0.0001))
                    if cancel_check_callback and cancel_check_callback():
                        print("CONCENTRIC: Cancel requested during offset processing")
                        return False
            #local_step_count = 0
            contour_area, current_contour = self.contour_utils.calculate_contour_area(current_contour)
            
            if contour_path and len(contour_path) > 0:
                print(f"CONCENTRIC: Contour tool path length: {len(contour_tool_path)}")
                start_position = contour_path[0]
                start_point = [start_position['xyz_normal']['x'], start_position['xyz_normal']['y'], start_position['xyz_normal']['z']]
                start_normal = [start_position['xyz_normal']['nx'], start_position['xyz_normal']['ny'], start_position['xyz_normal']['nz']]
                start_position, start_tool_position = self.position_tool_above_point(start_point, start_normal)
                # insert the point at the start of the path
                self.update_cut_progress([start_position], [start_tool_position])
                self.update_cut_progress(contour_path, contour_tool_path)
            else:
                unique_cuts.append(contour)
                print(f"CONCENTRIC: No valid tool path found in contour, skipping.")
                continue
            offset_distance = offset_step*direction
            local_path = contour_path.copy()
            local_tool_path = contour_tool_path.copy()
            iteration_count = 0
            reached_the_middle = False
            #print(f"CONCENTRIC: Starting offsetting process with offset distance: {offset_distance}")
            iteration_count += 1
            while not reached_the_middle and len(current_contour) > 0:
                if cancel_check_callback and cancel_check_callback():
                    print("CONCENTRIC: Cancel requested during offset processing")
                    return False
                
                total_offset = total_offset + offset_distance
                print(f"CONCENTRIC: Offsetting contour by {offset_distance} (total offset: {total_offset})")
                if (in_interior and not is_convex and total_offset < -max_offset) or (not in_interior and total_offset > max_offset):
                    print("CONCENTRIC: Max offset reached, stopping")
                    break
                current_contour = self.contour_utils.offset_contour(current_contour, offset_distance)
                area, current_contour = self.contour_utils.calculate_contour_area(current_contour)
                if area is None or area < 0.0:
                    print("CONCENTRIC: Contour area is invalid, stopping offset")
                    break
                print(f"CONCENTRIC: Contour origin: {contour_origin} is convex: {is_convex}, in_interior: {in_interior}, with area: {area:.8f}")
                
                # For growing shapes, check if the new contour is still within raw material bounds
                # Convert the initial boundary contour to path points
                '''
                if len(current_contour) > 1:
                    contour_min = np.min(current_contour, axis=0)
                    contour_max = np.max(current_contour, axis=0)
                    if (contour_min[0] < bounds[0][0] or contour_min[1] < bounds[0][1] or 
                        contour_max[0] > bounds[1][0] or contour_max[1] > bounds[1][1]):
                        print("CONCENTRIC: Contour exceeds raw material bounds, stopping offset.")
                        break
                '''
                if len(current_contour)> 0:
                    contour_path, contour_tool_path = self.contour_to_path(current_contour, origin, normal=normal)
                iteration_count += 1
                if len(contour_tool_path) > 0:
                    print(f"CONCENTRIC: Updating cut progress...")
                    print(f"CONCENTRIC: Contour tool path length: {len(contour_tool_path)}")
                    print(f"CONCENTRIC: Contour path length: {len(contour_path)}")
                    print(f"CONCENTRIC: Contour area: {contour_area}")
                    self.update_cut_progress(contour_path, contour_tool_path)
                    local_tool_path.extend(contour_tool_path)
                    local_path.extend(contour_path)
                else:
                    print(f"CONCENTRIC: No contour tool path found, stopping offset")
                    print(f"CONCENTRIC: local path length: {len(local_tool_path)}")
                    break
                print(f"CONCENCTRIC: checking next contour, iteration: {iteration_count}")
            print(f"CONCENTRIC: Finished offsetting contour, found {len(local_path)} path points")     
            if len(local_tool_path) > 0:
                if self.x_found_STL>1:           # Project the path points to the STL surface
                    print(f"CONCENTRIC: Projecting path points downward...")
                    self.project_contour_path_downward(contour, local_path, local_tool_path)
                    unique_cuts.append(contour)
                last_position = local_path[-1]
                last_point = [last_position['xyz_normal']['x'], last_position['xyz_normal']['y'], last_position['xyz_normal']['z']]
                last_normal = [last_position['xyz_normal']['nx'], last_position['xyz_normal']['ny'], last_position['xyz_normal']['nz']]
                self.retract_z(last_point, normal=last_normal)
                local_path = []
                local_tool_path = [] 
                # get the last point in the path
            
                
                
        print(f"CONCENTRIC: Exiting concentric planner.")
        print(f"CONCENTRIC: Total path length: {self.param_dict['global_step_count']} steps") 
        self.param_dict['contours']['unique_contours'] = unique_contours.copy()
        self.param_dict['contours']['unique_cuts'] = unique_cuts.copy()
        return True   

    def generate_linear_path_for_slice(self, slice_mesh, origin=[0.0000,0.0000,0.0000], normal=[0.000000,0.000000,1.000000]):
        """
        Generate a linear sweep cutting path for a specific slice mesh.
        Fills every shape in the slice with a sweeping linear pattern.
        Uses step size as tool_diameter * stepover to avoid overly fine paths.
        Returns a tuple of (path, tool_path).
        """
        print("LINEAR: Entering generate_linear_path_for_slice")
        slice_mesh_is_valid, slice_mesh = self.mesh_utils.mesh_is_valid(slice_mesh)
        if not slice_mesh_is_valid:
            print("Error: Slice mesh is not valid.")
            return None
        Z_DOWN = self.param_dict['Z_DOWN']
        line_width = self.param_dict['line_width']
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        update_tool_position_callback = self.param_dict['callbacks']['update_tool_position_callback']
        cancel_check_callback = self.param_dict['callbacks']['cancel_check_callback']
        global_step_count = self.param_dict['global_step_count']
        bounds = slice_mesh.bounds
        if bounds is not None: 
            print(f"LINEAR: Slice bounds - Min: {bounds[0]}, Max: {bounds[1]}")
        else: 
            return None
        path = []
        tool_path = []
        local_step_count = 0
        # Use provided normal or default to tool normal
        if Z_DOWN:
            normal = np.array([0, 0, 1])
        else:
            if normal is None:
                normal = self.cutting_tool_handler.cutting_tool['rotation']
                if np.linalg.norm(normal) == 0:
                    normal = np.array([0, 0, 1])
                else:
                    normal = normal / np.linalg.norm(normal)

        # Find nearest STL for normal-based orientation if not provided
        nearest_stl = None
        if normal is None or np.allclose(normal, [0, 0, 1]) and not Z_DOWN:
            print("LINEAR: Searching for nearest STL for normal-based orientation")
            min_dist = float('inf')
            min_norm_dist = float('inf')
            slice_center = slice_mesh.centroid
            print(f"LINEAR: Slice center: {slice_center}")
            for stl in self.stl_handler.stl_models:
                stl_mesh = self.stl_handler.get_transformed_stl_mesh(stl)[0]
                dist = np.linalg.norm(slice_center - stl_mesh.centroid)
                for face_normal in stl_mesh.face_normals:
                    if np.linalg.norm(face_normal) > 0.000000:
                        face_normal = face_normal / np.linalg.norm(face_normal)
                        if np.allclose(face_normal, normal, atol=0.1):
                            norm_dist = 0
                            break
                        else:
                            norm_dist = np.linalg.norm(face_normal - normal)
                
                if dist < min_dist or (dist <= min_dist and norm_dist < min_norm_dist):
                    min_dist = dist
                    min_norm_dist = norm_dist
                    nearest_stl = stl_mesh
            print(f"LINEAR: Nearest STL found: {nearest_stl is not None}, Min distance: {min_dist}")

        # contour_utils.extract 2D contours from the slice mesh at the given origin with the given normal
        contours = self.contour_utils.extract_2d_contours(slice_mesh, origin=origin, normal=normal)
        if not contours:
            print("LINEAR: No contours found for slice, skipping")
            return [], []

        # Step size based on tool diameter and stepover percentage
        step_size = line_width
        #print(f"LINEAR: Step size: {step_size}")

        for contour in contours:
            if cancel_check_callback and cancel_check_callback():
                print("LINEAR: Cancel requested during contour processing")
                return [], []

            # Determine bounding box of the contour for linear sweep
            contour_min = np.min(contour, axis=0)
            contour_max = np.max(contour, axis=0)
            y_range = np.arange(contour_min[1], contour_max[1] + step_size, step_size)
            direction = 1

            for y in y_range:
                if cancel_check_callback and cancel_check_callback():
                    print("LINEAR: Cancel requested during Y sweep")
                    return [], []
                if direction == 1:
                    x_range = np.arange(contour_min[0], contour_max[0] + step_size, step_size)
                else:
                    x_range = np.arange(contour_max[0], contour_min[0] - step_size, -step_size)
                for x in x_range:
                    if cancel_check_callback and cancel_check_callback():
                        print("LINEAR: Cancel requested during X sweep")
                        return [], []
                    # Check if point is inside the contour (simplified check using ray casting or winding number)
                    if self.is_point_inside_contour(x, y, contour):
                        # Reconstruct 3D point from 2D coordinates using tool normal
                        v1, v2 = self.contour_utils.get_v1_v2(normal)
                        point_3d = origin + x * v1 + y * v2
                        x_3d, y_3d, z_3d = point_3d[0], point_3d[1], point_3d[2]
                        # Determine normal, prioritizing STL surface normal
                        nx, ny, nz = normal
                        if nearest_stl:
                            test_point = np.array([x_3d, y_3d, z_3d])
                            closest_points, distances, face_indices = nearest_stl.nearest.on_surface([test_point])
                            if closest_points is not None and len(closest_points) > 0 and face_indices is not None and len(face_indices) > 0:
                                face_idx = face_indices[0]
                                if face_idx >= 0 and face_idx < len(nearest_stl.face_normals):
                                    n = nearest_stl.face_normals[face_idx]
                                    if not Z_DOWN and np.linalg.norm(n) > 0:
                                        n = n / np.linalg.norm(n)
                                        nx, ny, nz = n

                        # Convert material coordinates to CNC for collision check
                        self.cutting_tool_handler._testing = True
                        cnc_coords = self.cutting_tool_handler.material_to_cnc(x_3d, y_3d, z_3d, nx, ny, nz, self.cutting_tool_handler.cutting_tool['ab_rotation'][1], self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000)
                        
                        if self.cutting_tool_handler.is_valid_cut('XYZ + Normal', x_3d, y_3d, z_3d, nx, ny, nz, 
                                        b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], 
                                            elbow_up=(cnc_coords['a_deg'] >= 0)):
                   
                            point_data = {'xyzab': {'x': cnc_coords['x'], 'y': cnc_coords['y'], 'z': cnc_coords['z'], 'a': cnc_coords['a_deg'], 'b': cnc_coords['b_deg']},
                                          'xyz_normal': {'x': x_3d, 'y': y_3d, 'z': z_3d, 'nx': nx, 'ny': ny, 'nz': nz}}
                            path.append(point_data)
                            tool_path.append([cnc_coords['x'], cnc_coords['y'], cnc_coords['z'], cnc_coords['a_deg'], cnc_coords['b_deg']])
                            if update_tool_position_callback:
                                update_tool_position_callback(point_data['xyzab'], point_data['xyz_normal'])
                            if update_output_callback:
                                xyzab = point_data['xyzab']
                                xyz_normal = point_data['xyz_normal']
                                current_step = global_step_count + local_step_count + 1
                                update_output_callback(f"Step {current_step}: (7) XYZAB({xyzab['x']:.2f}, {xyzab['y']:.2f}, {xyzab['z']:.2f}, {xyzab['a']:.2f}, {xyzab['b']:.2f}) | XYZ+Normal({xyz_normal['x']:.2f}, {xyz_normal['y']:.2f}, {xyz_normal['z']:.2f}, {xyz_normal['nx']:.2f}, {xyz_normal['ny']:.2f}, {xyz_normal['nz']:.2f})")

                            local_step_count += 1
                        self.cutting_tool_handler._testing = False
                direction *= -1  # Alternate direction for each row to maintain continuity

        print("LINEAR: Exiting generate_linear_path_for_slice")
        return path, tool_path

    def generate_optimized_path_for_slice(self, slice_mesh, origin=[0.0000,0.0000,0.0000], normal=[0.000000,0.000000,1.000000]):
        """
        Generate an optimized cutting path for a specific slice mesh.
        Attempts to find an optimal path to remove as much reachable raw material as possible.
        Uses a simplified spiral pattern starting from the center for efficiency with step size as tool_diameter * stepover.
        The largest ring now reaches the farthest point in the slice_mesh.
        Returns a tuple of (path, tool_path).
        """
        slice_mesh_is_valid, slice_mesh = self.mesh_utils.mesh_is_valid(slice_mesh)
        if not slice_mesh_is_valid:
            print("Error: Slice mesh is not valid.")
            return [],[]
        
        Z_DOWN = self.param_dict['Z_DOWN']
        line_width = self.param_dict['line_width']
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        update_tool_position_callback = self.param_dict['callbacks']['update_tool_position_callback']
        cancel_check_callback = self.param_dict['callbacks']['cancel_check_callback']
        layer_height = self.param_dict['layer_height']
        global_step_count = self.param_dict['global_step_count']
        print("OPTIMIZED: Entering generate_optimized_path_for_slice")
        bounds = slice_mesh.bounds
        print(f"OPTIMIZED: Slice bounds - Min: {bounds[0]}, Max: {bounds[1]}")
        path = []
        tool_path = []
        local_step_count = 0
        # Use provided normal or default to tool normal
        if Z_DOWN:
            normal = np.array([0, 0, 1])
        else:
            if normal is None:
                normal = self.cutting_tool_handler.cutting_tool['rotation']
                if np.linalg.norm(normal) == 0:
                    normal = np.array([0, 0, 1])
                else:
                    normal = normal / np.linalg.norm(normal)
        normal = normal / np.linalg.norm(normal) if np.linalg.norm(normal) > 0 else np.array([0, 0, 1])

        # contour_utils.extract 2D contours from the slice mesh at the given origin with the given normal
        contours = self.contour_utils.extract_2d_contours(slice_mesh, origin, normal)
        if not contours:
            print("OPTIMIZED: No contours found for slice, skipping")
            return [], []

        # Step size based on tool diameter and stepover percentage
        step_size = line_width
        print(f"OPTIMIZED: Step size: {step_size}")

        # Calculate max_radius as the farthest distance from center to any point in the contours
        max_radius = 0
        for contour in contours:
            contour_center, nearest_stl, in_interior, is_convex = self.contour_utils.get_contour_origin(contour, slice_mesh, origin, normal)
            distances = np.linalg.norm(contour - np.array([contour_center[0], contour_center[1]]), axis=1)
            if len(distances) > 0:
                max_radius = max(max_radius, np.max(distances))

        print(f"OPTIMIZED: Adjusted max_radius to reach farthest point: {max_radius}")

        radius = 0
        # Get tool normal for plane reconstruction
        v1, v2 = self.contour_utils.get_v1_v2(normal)
        while radius < max_radius:
            if cancel_check_callback and cancel_check_callback():
                print("OPTIMIZED: Cancel requested during spiral processing")
                return [], []
            num_points = max(8, int(2 * np.pi * radius / step_size))  # Ensure enough points for smooth spiral
            angles = np.linspace(0, 2 * np.pi, num_points, endpoint=False)
            for angle in angles:
                if cancel_check_callback and cancel_check_callback():
                    print("OPTIMIZED: Cancel requested during angle processing")
                    return [], []
                x_2d = radius * np.cos(angle)
                y_2d = radius * np.sin(angle)
                # Reconstruct 3D point from 2D spiral coordinates
                point_3d = origin + (contour_center[0] + x_2d) * v1 + (contour_center + y_2d) * v2
                x, y, z = point_3d[0], point_3d[1], point_3d[2]
                # Check if within extended bounds (approximate check in 3D space)
                if x < bounds[0][0] or x > bounds[1][0] or y < bounds[0][1] or y > bounds[1][1]:
                    continue
                # Determine normal, prioritizing STL surface normal
                nx, ny, nz = normal
                if nearest_stl:
                    test_point = np.array([x, y, z])
                    closest_points, distances, face_indices = nearest_stl.nearest.on_surface([test_point])
                    if closest_points is not None and len(closest_points) > 0 and face_indices is not None and len(face_indices) > 0:
                        face_idx = face_indices[0]
                        if face_idx >= 0 and face_idx < len(nearest_stl.face_normals):
                            n = nearest_stl.face_normals[face_idx]
                            if not Z_DOWN and np.linalg.norm(n) >= 0.000001:
                                n = n / np.linalg.norm(n)
                                nx, ny, nz = n

                # Convert material coordinates to CNC for collision check
                self.cutting_tool_handler._testing = True
                cnc_coords = self.cutting_tool_handler.material_to_cnc(x, y, z, nx, ny, nz, self.cutting_tool_handler.cutting_tool['ab_rotation'][1], self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000)
               

                # Check for collisions
                if self.cutting_tool_handler.is_valid_cut('XYZ + Normal', x, y, z, nx, ny, nz, 
                                    b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], 
                                    elbow_up=(cnc_coords['a_deg'] >= 0)):
                
                
                    point_data = {'xyzab': {'x': cnc_coords['x'], 'y': cnc_coords['y'], 'z': cnc_coords['z'], 'a': cnc_coords['a_deg'], 'b': cnc_coords['b_deg']},
                                  'xyz_normal': {'x': x, 'y': y, 'z': z, 'nx': nx, 'ny': ny, 'nz': nz}}
                    path.append(point_data)
                    tool_path.append([cnc_coords['x'], cnc_coords['y'], cnc_coords['z'], cnc_coords['a_deg'], cnc_coords['b_deg']])
                    if update_tool_position_callback:
                        update_tool_position_callback(point_data['xyzab'], point_data['xyz_normal'])
                    if update_output_callback:
                        xyzab = point_data['xyzab']
                        xyz_normal = point_data['xyz_normal']
                        current_step = global_step_count + local_step_count + 1
                        update_output_callback(f"Step {current_step}: XYZAB({xyzab['x']:.2f}, {xyzab['y']:.2f}, {xyzab['z']:.2f}, {xyzab['a']:.2f}, {xyzab['b']:.2f}) | XYZ+Normal({xyz_normal['x']:.2f}, {xyz_normal['y']:.2f}, {xyz_normal['z']:.2f}, {xyz_normal['nx']:.2f}, {xyz_normal['ny']:.2f}, {xyz_normal['nz']:.2f})")

                    local_step_count += 1
                self.cutting_tool_handler._testing = False
            radius += step_size  # Increment radius to expand outward

        print("OPTIMIZED: Exiting generate_optimized_path_for_slice")
        return path, tool_path

    def update_cut_progress(self, path, tool_path):

        if len(tool_path) == 0:
            print("PROGRESS: No tool path provided, skipping progress update")
            return
        self.has_tool_path = True
        self.param_dict['global_step_count'] += len(tool_path)
        self.param_dict['tool_path'].extend(tool_path)
        self.param_dict['path'].extend(path)
        if self.update_cut_volume:
            new_cut_volume = self.mesh_utils.create_cut_volume_mesh(tool_path)
            if new_cut_volume is not None:
                to_be_cut = self.mesh_utils.get_to_be_cut_mesh(new_cut_volume)  
                if to_be_cut is not None:
                    print(f"Cut volume mesh updated, volume left to cut: {to_be_cut.volume:.6f} cm^3")
                    if self.mesh_utils.has_cut_volume_mesh:
                        print(f"Cut volume mesh updated, volume cut: {to_be_cut.volume:.6f} cm^3")
          
    def get_Z_down_plan(self):
        # Step 3: First cut with A=0 (Normal=[0,0,1]) using Z slices, ignoring STL normals
        # unpack needed parameters
        if self.param_dict is None:
            print("Z_DOWN: No param_dict found.")
            return False
        current_cnc_pos = self.param_dict['cnc_translation'].copy()
        current_ab_rotation = self.param_dict['ab_rotation'].copy()
        tool_path = self.param_dict['tool_path'].copy()
        layer_height = self.param_dict['layer_height']
        line_width = self.param_dict['line_width']
        tolerance = self.param_dict['tolerance']
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        update_progress_callback = self.param_dict['callbacks']['update_progress_callback']
        cancel_check_callback = self.param_dict['callbacks']['cancel_check_callback']
        path_type = self.param_dict['path_type']

    
        tool_path.append([current_cnc_pos[0], current_cnc_pos[1], current_cnc_pos[2], current_ab_rotation[0], current_ab_rotation[1]])
        if update_output_callback:
            update_output_callback("Processing raw material Z-down path...")
        
        extents = self.param_dict['material_space_meshes']['raw_mesh'].extents
        bounds = self.param_dict['material_space_meshes']['raw_mesh'].bounds
        if extents is None or bounds is None:
            print("Z_DOWN: No extents or bounds found for raw mesh.")
            if update_output_callback:
                update_output_callback("Error: No bounds found for raw mesh.")
            return False

        steps = int((bounds[1][2]-bounds[0][2]) / layer_height) - 1
        print(f"Z DOWN: Getting Z slices for raw mesh with extents: {extents} and bounds: {bounds}, with steps: {steps} and layer height: {layer_height}")
        z_slices = self.mesh_utils.get_z_slices(steps, layer_height, origin=[0,0,bounds[0][2]], normal =[0,0,1])
        
        if not self.found_stl:
            return False
        
        if z_slices is None:
            print("Z_DOWN: No Z slices found.")
            if update_output_callback:
                update_output_callback("Error: No Z slices found.")
            return False
        unique_contours = []
        unique_cuts = []
        z_steps = len(z_slices)
        success = False
        hit_bottom = False
        for i, z_slice in enumerate(z_slices):
            if z_slice is None or len(z_slice) == 0:
                print("Z DOWN: Z slice is None or empty, skipping")
                continue
            unique_z_slice, unique_z_contours, has_unique = self.contour_utils.make_contours_unique(z_slice, unique_cuts, tolerance=tolerance)
            if not has_unique:
                continue
            else:
                z_slice = unique_z_slice.copy()
            z = bounds[0][2] + layer_height * (steps - i)
            print(f"Z DOWN: current z is {z:.4f}")
            if z<bounds[0][2] or z>bounds[1][2]:
                if not hit_bottom:
                    if z > bounds[0][2] - layer_height and z<bounds[0][2]:
                        print(f"Z DOWN: Z slice {z:.4f} is out of bounds, setting to top")
                        
                        print(f"Z DOWN: Z slice {z:.4f} is out of bounds, setting to bottom")
                        hit_bottom = True
                        z = bounds[0][2]
                    else:
                        hit_bottom = True
                        print(f"Z DOWN: Z slice {z:.4f} is out of bounds, breaking")
                        break
                else:
                    print(f"Z DOWN: Z slice {z:.4f} is out of bounds, breaking")
                    break
                
                
            if cancel_check_callback and cancel_check_callback():
                print("Z_DOWN: Cancel requested during Z slice processing")
                success = False
                break
            if z_slice is None:
                print("Z_DOWN: Z slice is None, skipping")
                continue
            
            sub_slices = self.mesh_utils.get_z_slices(9, layer_height/10.000000, origin=[0.000000,0.000000,z], normal=[0.000000,0.000000,1.000000])  
            if not self.found_stl:
                sub_slices = [z_slice]
            else:
                self.x_found_STL += 1
            next_subslice = z_slice.copy()
            if len(sub_slices) > 1: 
                next_subslice = sub_slices[1].copy()
            for j, sub_slice in enumerate(sub_slices):
                #sub_slice = self.contour_utils.sort_contours_smallest_to_largest(sub_slice)
                if j!= len(sub_slices)-1: 
                    #sub_slice = self.contour_utils.make_contours_unique(sub_slice, z_slice)[0]
                    sub_slice = self.contour_utils.make_contours_unique(sub_slice, next_subslice, tolerance=tolerance)[0]
                    next_subslice = sub_slices[j+1].copy()
                if sub_slice is None or len(sub_slice) == 0:
                    print("Z DOWN: Sub-slice is None or empty, skipping")
                    continue
                sub_z = z + ((layer_height/10.000000) *(9-j))
                if sub_z<bounds[0][2] and not hit_bottom and sub_z>bounds[0][2] - layer_height:
                    print(f"Z DOWN: Sub-slice {sub_z:.4f} is out of bounds, setting to bottom")
                    sub_z = bounds[0][2]
                    hit_bottom = True
                elif sub_z<bounds[0][2] and hit_bottom:
                    print(f"Z DOWN: Sub-slice {sub_z:.4f} is out of bounds, breaking")
                    self.param_dict['finished'] = True
                    success = True
                    break
                    
                
                if cancel_check_callback and cancel_check_callback():
                    print("Z_DOWN: Cancel requested during sub-slice processing")
                    success = False
                    break
                if len(sub_slices) == 1:
                        sub_z = z
                if path_type.lower() == 'concentric':
                    print(f"Z DOWN: Generating concentric path for subslice at Z={sub_z:.4f}, step {i}")
                    
                    success = self.generate_concentric_path_for_slice(sub_slice, origin=[0,0,sub_z], normal=[0,0,1], unique_contours=unique_contours, unique_cuts=unique_cuts)
                    if success: 
                        unique_contours = self.param_dict['contours']['unique_contours']
                        unique_cuts = self.param_dict['contours']['unique_cuts']   
                        print(f"Z DOWN: Successfully processed subslice at Z={sub_z:.4f}, step {i}")                     
                    if cancel_check_callback and cancel_check_callback():
                        success = False
                        print("Z_DOWN: Cancel requested during concentric path generation")
                        break
                   
                elif path_type.lower() == 'linear':
                
                    success = self.generate_linear_path_for_slice(sub_slice, origin=[0,0,sub_z], normal=[0,0,1])
                    if cancel_check_callback and cancel_check_callback():
                        print("Z_DOWN: Cancel requested during linear path generation")
                        success = False
                        break
                   
                else: 
                    
                    success = self.generate_optimized_path_for_slice(sub_slice, origin=[0,0,sub_z], normal=[0,0,1])
                    if cancel_check_callback and cancel_check_callback():
                        print("Z_DOWN: Cancel requested during optimized path generation")
                        success = False
                        break
                if success:
                    print(f"Z DOWN: Successfully processed sub-slice at Z={sub_z:.4f}, step {i}")
                    if update_output_callback:
                        update_output_callback(f"Processed slice at Z={sub_z:.4f}, step {i}") 
                else:
                    print(f"Z DOWN: Failed to process slice at Z={sub_z:.4f}, step {i}")
                    if update_output_callback:
                        update_output_callback(f"Failed to process slice at Z={sub_z:.4f}, step {i}")
                        break
                
                if update_progress_callback:
                    update_progress_callback((j* 1.0/10.0)*100.0)
            if cancel_check_callback and cancel_check_callback():
                print("Z_DOWN: Cancel requested during Z slice processing")
                success = False
                break    
            
            if update_progress_callback:
                update_progress_callback((i* 1.0/z_steps)*100.0)
        # After processing all Z levels, use stored concave contours to adjust unreachable volumes if necessary
        
        return success

    def get_cspace_Z_down_plan(self):
        # unpack the param dict
        if self.param_dict is None:
            return False
        current_cnc_pos = self.param_dict['cnc_translation'].copy()
        current_ab_rotation = self.param_dict['ab_rotation'].copy()
        XYZn = self.param_dict['translation'].copy()
        normal = self.param_dict['rotation'].copy()
        tool_path = self.param_dict['tool_path'].copy()
        path = self.param_dict['path'].copy()
        path_type = self.param_dict['path_type']
        unreachable_mesh = self.param_dict['material_space_meshes']['unreachable_mesh'].copy()
        line_width = self.param_dict['line_width']
        layer_height = self.param_dict['layer_height']
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        cancel_check_callback = self.param_dict['callbacks']['cancel_check_callback']
        cutting_volume_rate = self.param_dict['cutting_volume_rate']
     
        # Step 5: Handle remaining volumes with spherical shells and unique normals
        if update_output_callback:
            update_output_callback("Step 5: Processing remaining volumes with spherical shells...")

        shell_radii = set()  # Track shell radii to avoid duplicates
        min_volume_reduction = cutting_volume_rate/10.0  # Minimum volume reduction to continue processing
        min_shell_radius = line_width/8.0  # Lower limit on shell radius to prevent singularity near zero
        reachedCenter = False  # Flag to indicate if the center has been reached
        raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
        distances = np.linalg.norm(raw_mesh.vertices, axis=1)
        farthest_point = np.max(distances) if distances.size > 0 else 0
        shell_radius = farthest_point
        success = True
       
        while success and not reachedCenter:
            if cancel_check_callback and cancel_check_callback():
                success = False
                break
            
            if shell_radius <= min_shell_radius:
                if update_output_callback:
                    update_output_callback(f"Shell radius {shell_radius:.4f} below minimum {min_shell_radius:.4f}, marking remaining as unreachable.")

            #create shell radii
            while shell_radius in shell_radii:
                shell_radius -= layer_height
            shell_radii.add(shell_radius)

            
            


        return False

    def contour_to_path(self, contour, origin=[0.0000,0.0000,1.0000], normal=[0.000000,0.000000,1.000000]):
        """
        Convert a 2D contour to a 3D tool path at the given origin.
        Reconstructs 3D points from 2D contour using the tool normal as the plane orientation.
        Checks unique normals from STL faces for orientation.
        Returns a tuple of (path, tool_path).
        """
        update_tool_position_callback = self.param_dict['callbacks']['update_tool_position_callback']
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        step_count = self.param_dict['global_step_count']
        Z_DOWN = self.param_dict['Z_DOWN']
        #print(f"CONTOUR PATH: Converting contour to path at origin={origin}")
        path = []
        tool_path = []
        local_step_count = 0
        # Get the tool normal to reconstruct 3D points
        if Z_DOWN:
            tool_normal = np.array([0.000000, 0.000000, 1.000000])
        else:
            tool_normal = np.array(normal)
            if np.linalg.norm(tool_normal) == 0:
                tool_normal = np.array([0.000000, 0.000000, 1.000000])
            else:
                tool_normal = tool_normal / np.linalg.norm(tool_normal)
        plane_origin = np.array(origin)
        #print(f"CONTOUR PATH: Plane origin: {plane_origin}, Tool normal: {tool_normal}")
        # Create basis vectors for the plane
        v1, v2 = self.contour_utils.get_v1_v2(tool_normal)
        nx, ny, nz = tool_normal
        for point_2d in contour:
            # Reconstruct 3D point from 2D coordinates using plane basis
            x_2d, y_2d = point_2d[0], point_2d[1]
            point_3d = plane_origin + x_2d * v1 + y_2d * v2
            x, y, z = point_3d[0], point_3d[1], point_3d[2]

            self.cutting_tool_handler._testing = True
            #print(f"CONTOUR PATH: Processing point: ({x}, {y}, {z}) with normal ({nx}, {ny}, {nz})")
        
            cnc_coords = self.cutting_tool_handler.material_to_cnc(x, y, z, nx, ny, nz, self.cutting_tool_handler.cutting_tool['ab_rotation'][1], self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000)
            
            if self.cutting_tool_handler.is_valid_cut('XYZ + Normal', x, y, z, nx, ny, nz, 
                                b_deg=self.cutting_tool_handler.cutting_tool['ab_rotation'][1], 
                                elbow_up=(cnc_coords['a_deg'] >= 0)):
           

                point_data = {'xyzab': {'x': cnc_coords['x'], 'y': cnc_coords['y'], 'z': cnc_coords['z'], 'a': cnc_coords['a_deg'], 'b': cnc_coords['b_deg']},
                            'xyz_normal': {'x': x, 'y': y, 'z': z, 'nx': nx, 'ny': ny, 'nz': nz}}
                path.append(point_data)
                tool_path.append([cnc_coords['x'], cnc_coords['y'], cnc_coords['z'], cnc_coords['a_deg'], cnc_coords['b_deg']])
                if update_tool_position_callback:
                    update_tool_position_callback(point_data['xyzab'], point_data['xyz_normal'])
                if update_output_callback:
                    xyzab = point_data['xyzab']
                    xyz_normal = point_data['xyz_normal']
                    current_step = step_count + local_step_count + 1
                    update_output_callback(f"Step {current_step}: (6) XYZAB({xyzab['x']:.2f}, {xyzab['y']:.2f}, {xyzab['z']:.2f}, {xyzab['a']:.2f}, {xyzab['b']:.2f}) | XYZ+Normal({xyz_normal['x']:.2f}, {xyz_normal['y']:.2f}, {xyz_normal['z']:.2f}, {xyz_normal['nx']:.2f}, {xyz_normal['ny']:.2f}, {xyz_normal['nz']:.2f})")

                local_step_count += 1
            else:
                #print(f"CONTOUR PATH: Invalid cut at point ({x}, {y}, {z}), breaking.")
                break
            self.cutting_tool_handler._testing = False
        # add the first point to the end of the path to close the loop
        if len(path) > 0:
            #print(f"CONTOUR PATH: Path length: {len(path)} points, Tool path length: {len(tool_path)} points.")
            if path[0] != path[-1]:
                #print(f"CONTOUR PATH: Closing loop by adding first point to end of path.")
                path.append(path[0])
                tool_path.append(tool_path[0])  
            #print(f"CONTOUR PATH: Path length: {len(path)} points, Tool path length: {len(tool_path)} points.")  
        
        return path.copy(), tool_path.copy()
  
    def project_contour_path_downward(self, contour, path, tool_path):
        if contour is None or path is None or tool_path is None:
            print("Error: Contour, path, or tool_path is None.")
            return [], []
        Z_DOWN = self.param_dict['Z_DOWN']
        layer_height = self.param_dict['layer_height']
        print(f"Z DOWN: Projecting paths downward...")
        raw_mesh = self.param_dict['material_space_meshes']['raw_mesh'].copy()
        cut_volume_mesh = self.param_dict['material_space_meshes']['cut_volume_mesh'].copy()
        update_output_callback = self.param_dict['callbacks']['update_output_callback']
        cancel_check_callback = self.param_dict['callbacks']['cancel_check_callback']
        update_tool_position_callback = self.param_dict['callbacks']['update_tool_position_callback']
        update_progress_callback = self.param_dict['callbacks']['update_progress_callback']
        global_step_count = self.param_dict['global_step_count']
        tool_radius = self.param_dict['tool_radius']
        tool_diameter = self.param_dict['tool_diameter']
        point_data = path[0]
        bounds = raw_mesh.bounds
        current_step = 0
        contour_path_points, contour_tool_path_points = self.contour_utils.find_path_points_inside_contour(contour, path, tool_path)
        
        contour_tool_path = []
        contour_path = []
        contour_centroid = np.mean(np.round(contour, 4), axis=0)
        if np.array_equal(contour[0] ,contour[-1]):
            contour_centroid = np.mean(np.round(contour[:-1],4), axis=0)

        
        z_offset = 0.000000
        self.cutting_tool_handler._testing = True
        if Z_DOWN:
            original_z = bounds[1][2]
        else:
            original_z = tool_path[0][2]
        is_valid = True
        while is_valid and z_offset < original_z+layer_height:
            is_valid = False
            
            layer_path = []
            layer_tool_path = []
            if update_output_callback:
                update_output_callback(f"Processing Z offset {z_offset:.4f} for contour path.")
            print(f"Z PROJECT: Processing Z offset: {z_offset:.4f}")
            for path_point in path:
                if cancel_check_callback and cancel_check_callback():
                        break
                if Z_DOWN:
                    
                    original_z = path_point['xyz_normal']['z']
                    is_valid = self.cutting_tool_handler.is_valid_cut(
                        'XYZ + Normal', 
                        path_point['xyz_normal']['x'],
                        path_point['xyz_normal']['y'],
                        original_z - z_offset+0.0001,
                        0.000000,
                        0.000000,
                        1.000000,
                        0.000,
                        True, 
                        threshold=0.005
                    )
                    if not is_valid:
                        break
                else: 
                    original_z = path_point['xyzab']['z']
                    is_valid = self.cutting_tool_handler.is_valid_cut(
                        'XYZAB', 
                        path_point['xyzab']['x'],
                        path_point['xyzab']['y'],
                        original_z-z_offset+0.0001,
                        path_point['xyzab']['a'],
                        path_point['xyzab']['b'],
                        threshold=0.005
                    )
                    if not is_valid:
                        break
                if is_valid:
                    if Z_DOWN:
                        contour_tool_path.append([path_point['xyzab']['x'], path_point['xyzab']['y'], original_z-z_offset, path_point['xyzab']['a'], path_point['xyzab']['b']])
                        layer_tool_path.append([path_point['xyzab']['x'], path_point['xyzab']['y'], original_z-z_offset, path_point['xyzab']['a'], path_point['xyzab']['b']])
                        point_data = {
                            'xyzab': {
                                'x': path_point['xyzab']['x'],
                                'y': path_point['xyzab']['y'],
                                'z': original_z - z_offset + 0.0001,
                                'a': 0.000000,
                                'b': 0.000000
                            },
                            'xyz_normal': {
                                'x': path_point['xyz_normal']['x'],
                                'y': path_point['xyz_normal']['y'],
                                'z': original_z - z_offset + 0.0001,
                                'nx': 0.000000,
                                'ny': 0.000000,
                                'nz': 1.000000
                            }
                        } 
                        contour_path.append( point_data )
                        layer_path.append(point_data)
                        if update_tool_position_callback:
                            update_tool_position_callback(point_data['xyzab'], point_data['xyz_normal'])
                        if update_output_callback:
                            xyzab = point_data['xyzab']
                            xyz_normal = point_data['xyz_normal']
                            current_step = current_step + 1
                            update_output_callback(f"Step {global_step_count+current_step}: (6) XYZAB({xyzab['x']:.2f}, {xyzab['y']:.2f}, {xyzab['z']:.2f}, {xyzab['a']:.2f}, {xyzab['b']:.2f}) | XYZ+Normal({xyz_normal['x']:.2f}, {xyz_normal['y']:.2f}, {xyz_normal['z']:.2f}, {xyz_normal['nx']:.2f}, {xyz_normal['ny']:.2f}, {xyz_normal['nz']:.2f})")
                    else:
                        contour_tool_path.append([path_point['xyzab']['x'], path_point['xyzab']['y'], original_z-z_offset + 0.0001, path_point['xyzab']['a'], path_point['xyzab']['b']])
                        layer_tool_path.append([path_point['xyzab']['x'], path_point['xyzab']['y'], original_z-z_offset + 0.0001, path_point['xyzab']['a'], path_point['xyzab']['b']])
                        mat_coords = self.cutting_tool_handler.cnc_to_material(path_point['xyzab']['x'], path_point['xyzab']['y'], original_z-z_offset + 0.0001, path_point['xyzab']['a'], path_point['xyzab']['b'])
                        point_data = {
                            'xyzab': {
                                'x': path_point['xyzab']['x'],
                                'y': path_point['xyzab']['y'],
                                'z': original_z - z_offset + 0.0001,
                                'a': path_point['xyzab']['a'],
                                'b': path_point['xyzab']['b']
                            },
                            'xyz_normal': {
                                'x': mat_coords['x'],
                                'y': mat_coords['y'],
                                'z': mat_coords['z'],
                                'nx': mat_coords['u_x'],
                                'ny': mat_coords['u_y'],
                                'nz': mat_coords['u_z']
                            }
                        } 
                        contour_path.append( point_data )
                        layer_path.append( point_data )
                        if update_tool_position_callback:
                            update_tool_position_callback(point_data['xyzab'], point_data['xyz_normal'])
                        if update_output_callback:
                            xyzab = point_data['xyzab']
                            xyz_normal = point_data['xyz_normal']
                            current_step = current_step + 1
                            update_output_callback(f"Step {global_step_count+current_step}: (6) XYZAB({xyzab['x']:.2f}, {xyzab['y']:.2f}, {xyzab['z']:.2f}, {xyzab['a']:.2f}, {xyzab['b']:.2f}) | XYZ+Normal({xyz_normal['x']:.2f}, {xyz_normal['y']:.2f}, {xyz_normal['z']:.2f}, {xyz_normal['nx']:.2f}, {xyz_normal['ny']:.2f}, {xyz_normal['nz']:.2f})")
                else:
                    print(f"Z PROJECT: Invalid cut at Z offset {z_offset:.4f}, breaking loop.")
                    break
            z_offset = z_offset + layer_height
            if update_progress_callback:
                update_progress_callback((z_offset / original_z) * 100.0)
            if len(layer_tool_path) > 0:
                self.update_cut_progress(layer_path, layer_tool_path)
            if not is_valid:
                break
            if cancel_check_callback and cancel_check_callback():
                print("Z PROJECT: Cancel requested during Z projection")
                break
        last_path_point = contour_path[-1]
        last_point = [last_path_point['xyz_normal']['x'], last_path_point['xyz_normal']['y'], last_path_point['xyz_normal']['z']]
        last_normal = [last_path_point['xyz_normal']['nx'], last_path_point['xyz_normal']['ny'], last_path_point['xyz_normal']['nz']]
        self.retract_z(last_point, last_normal)
        
    def remove_duplicate_path_points(self, path, tool_path):
        """
        Remove duplicate points from the path and tool_path.
        Returns a tuple of (path, tool_path) without duplicates.
        """
        if path is None or tool_path is None:
            print("Error: Path or tool_path is None.")
            return [], []
        unique_path = []
        unique_tool_path = []
        seen_points = set()
        for point, tool_point in zip(path, tool_path):
            point_tuple = (point['xyzab']['x'], point['xyzab']['y'], point['xyzab']['z'], point['xyzab']['a'], point['xyzab']['b'])
            if point_tuple not in seen_points:
                seen_points.add(point_tuple)
                unique_path.append(point)
                unique_tool_path.append(tool_point)
        return unique_path, unique_tool_path

    def remove_triples(self, path, tool_path):
        """
        Remove triples from the path and tool_path.
        Returns a tuple of (path, tool_path) without triples.
        """
        if path is None or tool_path is None:
            print("Error: Path or tool_path is None.")
            return [], []
        unique_path = []
        unique_tool_path = []
        seen_twice = set()
        seen_points = set()
        for point, tool_point in zip(path, tool_path):
            point_tuple = (point['xyzab']['x'], point['xyzab']['y'], point['xyzab']['z'], point['xyzab']['a'], point['xyzab']['b'])
            # check if the point exists more than twice in the path
            if point_tuple not in seen_points:
                seen_points.add(point_tuple)
                unique_path.append(point)
                unique_tool_path.append(tool_point)
            elif point_tuple not in seen_twice:
                seen_twice.add(point_tuple)
                unique_path.append(point)
                unique_tool_path.append(tool_point)
            
        return unique_path, unique_tool_path

    def retract_z(self, point, normal):
        """
        Retract the tool along the given normal direction from the specified point
        to a sphere that encloses the entire raw material, centered at the origin [0,0,0].
        
        Args:
            point (list or np.array): The starting point [x, y, z] in material coordinates.
            normal (list or np.array): The direction [nx, ny, nz] along which to retract the tool.
        
        Returns:
            dict: A point data dictionary with the retracted position in both CNC and material coordinates.
        """
        update_tool_position_callback = self.param_dict['callbacks']['update_tool_position_callback']
        print("RETRACT Z: Initiating Z retraction to enclosing sphere")
        raw_mesh_bounds = self.param_dict['material_space_meshes']['raw_mesh'].bounds
        if raw_mesh_bounds is None:
            print("RETRACT Z: Error - Raw material bounds not available, returning original point")
            return point
        layer_height=self.param_dict['layer_height']
        point = np.array(point)
        normal = np.array(normal)
        if np.linalg.norm(normal) == 0:
            normal = np.array([0.0, 0.0, 1.0])  # Default to Z-up if normal is invalid
        else:
            normal = normal / np.linalg.norm(normal)  # Normalize the direction vector      
        self.cutting_tool_handler._testing = True
        start_cnc_coords = self.cutting_tool_handler.material_to_cnc(point[0], point[1], point[2], normal[0], normal[1], normal[2], self.cutting_tool_handler.cutting_tool['ab_rotation'][1], self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000)
        start_path_point = {
            'xyzab': {
                'x': start_cnc_coords['x'],
                'y': start_cnc_coords['y'],
                'z': start_cnc_coords['z'].copy(),
                'a': start_cnc_coords['a_deg'],
                'b': start_cnc_coords['b_deg']
            },
            'xyz_normal': {
                'x': point[0],
                'y': point[1],
                'z': point[2],
                'nx': normal[0],
                'ny': normal[1],
                'nz': normal[2]
            }
        }
        start_tool_path_point = [start_cnc_coords['x'], start_cnc_coords['y'], start_cnc_coords['z'], start_cnc_coords['a_deg'], start_cnc_coords['b_deg']]
        cnc_coords = start_cnc_coords.copy()
        cnc_coords['z'] = self.z_retraction_point
        mat_coords = self.cutting_tool_handler.cnc_to_material(cnc_coords['x'], cnc_coords['y'], cnc_coords['z'], cnc_coords['a_deg'], cnc_coords['b_deg'])
        self.cutting_tool_handler._testing = False
        
        path_point = {
            'xyzab': {
                'x': cnc_coords['x'],
                'y': cnc_coords['y'],
                'z': cnc_coords['z'],
                'a': cnc_coords['a_deg'],
                'b': cnc_coords['b_deg']
            },
            'xyz_normal': {
                'x': mat_coords['x'],
                'y': mat_coords['y'],
                'z': mat_coords['z'],
                'nx': normal[0],
                'ny': normal[1],
                'nz': normal[2]
            }
        }
        tool_path_point = [cnc_coords['x'], cnc_coords['y'], cnc_coords['z'], cnc_coords['a_deg'], cnc_coords['b_deg']]
        path = []
        tool_path = []
        path.append(start_path_point)
        tool_path.append(start_tool_path_point)
        path.append(path_point)
        tool_path.append(tool_path_point)
        self.update_cut_progress(path, tool_path)
        if update_tool_position_callback:
            update_tool_position_callback(path_point['xyzab'], path_point['xyz_normal'])

    def position_tool_above_point(self, point, normal):
        """
        Position the tool above the specified point in material coordinates.
        
        Args:
            point (list or np.array): The target point [x, y, z] in material coordinates.
            normal (list or np.array): The direction [nx, ny, nz] along which to position the tool.
        
        Returns:
            dict: A point data dictionary with the positioned point in both CNC and material coordinates.
        """
        update_tool_position_callback = self.param_dict['callbacks']['update_tool_position_callback']
        print("POSITION TOOL: Positioning tool above point")
        self.cutting_tool_handler._testing = True
        cnc_coords = self.cutting_tool_handler.material_to_cnc(point[0], point[1], point[2], normal[0], normal[1], normal[2], self.cutting_tool_handler.cutting_tool['ab_rotation'][1], self.cutting_tool_handler.cutting_tool['ab_rotation'][0] >= 0.0000)
        cnc_coords['z'] = self.z_retraction_point
        mat_coords = self.cutting_tool_handler.cnc_to_material(cnc_coords['x'], cnc_coords['y'], cnc_coords['z'], cnc_coords['a_deg'], cnc_coords['b_deg'])
        self.cutting_tool_handler._testing = False
        path_point = {
            'xyzab': {
                'x': cnc_coords['x'],
                'y': cnc_coords['y'],
                'z': cnc_coords['z'],
                'a': cnc_coords['a_deg'],
                'b': cnc_coords['b_deg']
            },
            'xyz_normal': {
                'x': mat_coords['x'],
                'y': mat_coords['y'],
                'z': mat_coords['z'],
                'nx': normal[0],
                'ny': normal[1],
                'nz': normal[2]
            }
        }
        tool_path_point = [cnc_coords['x'], cnc_coords['y'], cnc_coords['z'], cnc_coords['a_deg'], cnc_coords['b_deg']]
        return path_point, tool_path_point
