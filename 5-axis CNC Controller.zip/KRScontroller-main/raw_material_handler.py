# File: raw_material_handler.py
from PyQt5.QtWidgets import QFileDialog
from stl import mesh
import trimesh
import numpy as np
from scipy.spatial.transform import Rotation as R

from OpenGL.GL import *
from PyQt5.QtWidgets import QHBoxLayout, QVBoxLayout, QLabel, QSlider, QLineEdit
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QComboBox

class RawMaterialHandler:
    def __init__(self, gui):
        self.gui = gui
        self.helpers = gui.helpers
        self.raw_material = None
        self.initialize_raw_material()

    def initialize_raw_material(self):
        self.raw_material = {
            'translation': [0.0, 0.0, 5.0],
            'rotation': [0.0, 0.0, 0.0],  # Euler angles for UI display
            'quaternion': [1.0, 0.0, 0.0, 0.0],  # Quaternion for actual rotation (w, x, y, z)
            'dimensions': [10.0, 20.0, 10.0],
            'centroid': [5.0, 10.0, 5.0],
            'wireframe_list': None,
            'wireframe_pending': False,
            'wireframe_type': 'rectangular'
        }
        # Do not access GUI elements here to avoid AttributeError
        # UI updates are handled in update_initial_ui_values after UI initialization

    def load_material_stl(self):
        file_name, _ = QFileDialog.getOpenFileName(self.gui, "Open Material STL File", "", "STL Files (*.stl)")
        if file_name:
            material_stl = mesh.Mesh.from_file(file_name)
            centroid = np.mean(material_stl.vectors, axis=(0, 1))
            translation = [-centroid[0], -centroid[1], -centroid[2]]
            
            edge_to_triangles = {}
            triangle_normals = []
            for i, triangle in enumerate(material_stl.vectors):
                normal = np.cross(triangle[1] - triangle[0], triangle[2] - triangle[0])
                normal = normal / np.linalg.norm(normal)
                triangle_normals.append(normal)
                edges = [
                    tuple(sorted((tuple(triangle[0]), tuple(triangle[1])))),
                    tuple(sorted((tuple(triangle[1]), tuple(triangle[2])))),
                    tuple(sorted((tuple(triangle[2]), tuple(triangle[0])))),
                ]
                for edge in edges:
                    if edge not in edge_to_triangles:
                        edge_to_triangles[edge] = []
                    edge_to_triangles[edge].append(i)
            
            boundary_edges = []
            for edge, triangles in edge_to_triangles.items():
                if len(triangles) == 1 or (len(triangles) == 2 and not np.allclose(
                    triangle_normals[triangles[0]], triangle_normals[triangles[1]], atol=1e-6)):
                    boundary_edges.append(edge)
            
            self.raw_material = {
                'model': material_stl,
                'translation': translation,
                'rotation': [0.0, 0.0, 0.0],
                'quaternion': [1.0, 0.0, 0.0, 0.0],  # Add quaternion for rotation
                'dimensions': [10.0, 10.0, 10.0],
                'centroid': centroid,
                'wireframe_list': None,
                'wireframe_pending': True,
                'wireframe_type': 'stl',
                'boundary_edges': boundary_edges
            }
            self.gui.file_info.append(f"Loaded Material: {file_name}\nVertices: {len(material_stl.vectors)}\nTriangles: {len(material_stl.vectors) // 3}")
            self.snap_raw_material_to_build_plate()
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def create_raw_material_wireframe(self):
        if not hasattr(self.gui, 'stl_viewer') or not self.gui.stl_viewer:
            print("stl_viewer is not initialized. Skipping wireframe creation.")
            return
        if not self.gui.stl_viewer.context() or not self.gui.stl_viewer.context().isValid():
            print("OpenGL context is not valid. Skipping wireframe creation.")
            return
        # Even if context is valid, defer OpenGL operations to paintGL to ensure context is active
        self.raw_material['wireframe_pending'] = True
        self.raw_material['wireframe_type'] = 'rectangular'
        if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
            self.gui.stl_viewer.update()

    def create_cylinder_wireframe(self):
        if not hasattr(self.gui, 'stl_viewer') or not self.gui.stl_viewer:
            print("stl_viewer is not initialized. Skipping wireframe creation.")
            return
        if not self.gui.stl_viewer.context() or not self.gui.stl_viewer.context().isValid():
            print("OpenGL context is not valid. Skipping wireframe creation.")
            return
        # Even if context is valid, defer OpenGL operations to paintGL to ensure context is active
        self.raw_material['wireframe_pending'] = True
        self.raw_material['wireframe_type'] = 'cylinder'
        if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
            self.gui.stl_viewer.update()

    def update_raw_material_ui(self):
        if self.gui.raw_material_stl_button.isChecked():
            self.gui.material_load_button.show()
            self.gui.material_type_combo.hide()
            self.gui.material_length.hide()
            self.gui.material_width.hide()
            self.gui.material_height.hide()
            self.gui.tool_cone_length.hide()
            self.gui.material_diameter.hide()
            self.gui.material_form_label_type.setVisible(False)
            self.gui.material_form_label_length.setVisible(False)
            self.gui.material_form_label_width.setVisible(False)
            self.gui.material_form_label_height.setVisible(False)
            self.gui.material_form_label_diameter.setVisible(False)
            file_name = self.raw_material.get('file_name', "No STL loaded")
            self.gui.raw_material_info_label.setText(f"STL File: {file_name}")
        else:
            self.gui.material_load_button.hide()
            self.gui.material_type_combo.show()
            self.gui.material_length.show()
            self.gui.material_width.show()
            self.gui.material_height.show()
            self.gui.material_diameter.show()
            self.gui.tool_cone_length.show()
            self.gui.material_form_label_type.setVisible(True)
            self.gui.material_form_label_length.setVisible(True)
            self.gui.material_form_label_width.setVisible(True)
            self.gui.material_form_label_height.setVisible(True)
            self.gui.material_form_label_diameter.setVisible(True)
            self.update_shape_fields()
            self.gui.raw_material_info_label.setText("Define raw material dimensions")

    def update_shape_fields(self):
        if hasattr(self.gui, 'dimension_row_layout'):
            for i in reversed(range(self.gui.dimension_row_layout.count())):
                widget = self.gui.dimension_row_layout.itemAt(i).widget()
                if widget:
                    widget.setParent(None)

        if self.raw_material:
            
            # Reset rotation to zero when switching shapes
            self.raw_material['rotation'] = [0.0, 0.0, 0.0]
            self.raw_material['quaternion'] = [1.0, 0.0, 0.0, 0.0]  # Identity quaternion (no rotation)
            self.update_raw_material_sliders()

        if self.gui.material_type_combo.currentText() == 'Rectangular Cube':
            self.raw_material['translation'] = [0.0, 0.0, 5.0]
            self.gui.material_form_label_length.setVisible(True)
            self.gui.material_length.show()
            self.gui.material_form_label_width.setVisible(True)
            self.gui.material_width.show()
            self.gui.material_form_label_height.setVisible(True)
            self.gui.material_height.show()
            self.gui.dimension_row_layout.addWidget(self.gui.material_form_label_length)
            self.gui.dimension_row_layout.addWidget(self.gui.material_length)
            self.gui.dimension_row_layout.addWidget(self.gui.material_form_label_width)
            self.gui.dimension_row_layout.addWidget(self.gui.material_width)
            self.gui.dimension_row_layout.addWidget(self.gui.material_form_label_height)
            self.gui.dimension_row_layout.addWidget(self.gui.material_height)
            self.gui.material_form_label_diameter.setVisible(False)
            self.gui.material_diameter.hide()
            if self.raw_material:
                # Set default dimensions in cm if not already set or if switching shapes
                if not hasattr(self, 'previous_shape') or self.previous_shape != 'Rectangular Cube':
                    self.gui.material_length.setValue(10.0 if self.gui.current_unit == 'CM' else self.helpers.convert_from_cm(10.0, self.gui.current_unit))
                    self.gui.material_width.setValue(20.0 if self.gui.current_unit == 'CM' else self.helpers.convert_from_cm(20.0, self.gui.current_unit))
                    self.gui.material_height.setValue(10.0 if self.gui.current_unit == 'CM' else self.helpers.convert_from_cm(10.0, self.gui.current_unit))
                length = self.helpers.convert_to_cm(self.gui.material_length.value(), self.gui.current_unit)
                width = self.helpers.convert_to_cm(self.gui.material_width.value(), self.gui.current_unit)
                height = self.helpers.convert_to_cm(self.gui.material_height.value(), self.gui.current_unit)
                self.raw_material['dimensions'] = [length, width, height]
                self.raw_material['centroid'] = [length / 2.0, width / 2.0, height / 2.0]
                # Defer wireframe creation to paintGL
                self.raw_material['wireframe_pending'] = True
                self.raw_material['wireframe_type'] = 'rectangular'
                
                if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                    self.gui.stl_viewer.update()
            self.previous_shape = 'Rectangular Cube'
        elif self.gui.material_type_combo.currentText() == 'Cylinder':
            self.raw_material['translation'] = [0.0, 0.0, 0.0]
            self.gui.material_form_label_diameter.setVisible(True)
            self.gui.material_diameter.show()
            self.gui.material_form_label_length.setVisible(True)
            self.gui.material_length.show()
            self.gui.dimension_row_layout.addWidget(self.gui.material_form_label_diameter)
            self.gui.dimension_row_layout.addWidget(self.gui.material_diameter)
            self.gui.dimension_row_layout.addWidget(self.gui.material_form_label_length)
            self.gui.dimension_row_layout.addWidget(self.gui.material_length)
            self.gui.material_form_label_width.setVisible(False)
            self.gui.material_width.hide()
            self.gui.material_form_label_height.setVisible(False)
            self.gui.material_height.hide()
            if self.raw_material:
                # Set default dimensions in cm if not already set or if switching shapes
                if not hasattr(self, 'previous_shape') or self.previous_shape != 'Cylinder':
                    self.gui.material_diameter.setValue(10.0 if self.gui.current_unit == 'CM' else self.helpers.convert_from_cm(10.0, self.gui.current_unit))
                    self.gui.material_length.setValue(20.0 if self.gui.current_unit == 'CM' else self.helpers.convert_from_cm(20.0, self.gui.current_unit))
                diameter = self.helpers.convert_to_cm(self.gui.material_diameter.value(), self.gui.current_unit)
                length = self.helpers.convert_to_cm(self.gui.material_length.value(), self.gui.current_unit)
                self.raw_material['dimensions'] = [diameter, length, 0.0]
                self.raw_material['centroid'] = [0.0, 0.0, length / 2.0]
                # Defer wireframe creation to paintGL
                self.raw_material['wireframe_pending'] = True
                self.raw_material['wireframe_type'] = 'cylinder'
                if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                    self.gui.stl_viewer.update()
            self.previous_shape = 'Cylinder'
        if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
            self.gui.stl_viewer.update()

    def update_material_dimensions(self, dimension, value):
        if self.raw_material:
            value_cm = self.helpers.convert_to_cm(value, self.gui.current_unit)
            if dimension == 'diameter':
                self.raw_material['dimensions'][0] = value_cm
                # Defer wireframe creation to paintGL
                self.raw_material['wireframe_pending'] = True
                self.raw_material['wireframe_type'] = 'cylinder'
            elif dimension == 'length':
                if self.gui.material_type_combo.currentText() == 'Cylinder':
                    self.raw_material['dimensions'][1] = value_cm
                else:
                    self.raw_material['dimensions'][0] = value_cm
                    self.raw_material['centroid'][0] = value_cm / 2.0
                # Defer wireframe creation to paintGL
                self.raw_material['wireframe_pending'] = True
                self.raw_material['wireframe_type'] = 'cylinder' if self.gui.material_type_combo.currentText() == 'Cylinder' else 'rectangular'
            elif dimension == 'width':
                self.raw_material['dimensions'][1] = value_cm
                self.raw_material['centroid'][1] = value_cm / 2.0
                # Defer wireframe creation to paintGL
                self.raw_material['wireframe_pending'] = True
                self.raw_material['wireframe_type'] = 'rectangular'
            elif dimension == 'height':
                self.raw_material['dimensions'][2] = value_cm
                self.raw_material['centroid'][2] = value_cm / 2.0
                # Defer wireframe creation to paintGL
                self.raw_material['wireframe_pending'] = True
                self.raw_material['wireframe_type'] = 'rectangular'
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def align_raw_material_axes(self):
        """Reset the rotation of the raw material to align its local axes with the build plate axes."""
        if self.raw_material:
            # Reset Euler angles to zero
            self.raw_material['rotation'] = [0.0, 0.0, 0.0]
            # Reset quaternion to identity (no rotation)
            self.raw_material['quaternion'] = [1.0, 0.0, 0.0, 0.0]
            # Update UI sliders and entries to reflect the reset
            if hasattr(self.gui, 'raw_rx_slider'):
                self.gui.raw_rx_slider.blockSignals(True)
                self.gui.raw_rx_slider.setValue(0)
                self.gui.raw_rx_slider.blockSignals(False)
            if hasattr(self.gui, 'raw_ry_slider'):
                self.gui.raw_ry_slider.blockSignals(True)
                self.gui.raw_ry_slider.setValue(0)
                self.gui.raw_ry_slider.blockSignals(False)
            if hasattr(self.gui, 'raw_rz_slider'):
                self.gui.raw_rz_slider.blockSignals(True)
                self.gui.raw_rz_slider.setValue(0)
                self.gui.raw_rz_slider.blockSignals(False)
            if hasattr(self.gui, 'raw_rx_entry'):
                self.gui.raw_rx_entry.setText("0.00")
            if hasattr(self.gui, 'raw_ry_entry'):
                self.gui.raw_ry_entry.setText("0.00")
            if hasattr(self.gui, 'raw_rz_entry'):
                self.gui.raw_rz_entry.setText("0.00")
            # Trigger a UI update
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def zero_raw_material_position(self):
        if self.raw_material:
            self.raw_material['translation'] = [0.0, 0.0, 0.0]
            self.update_raw_material_sliders()
            self.gui.stl_viewer.update()

    def snap_raw_material_to_build_plate(self):
        if self.raw_material:
            # Get the lowest Z point after applying rotation
            lowest_z = self.find_lowest_point()
            # Adjust the translation so that the lowest point is at z=build_z_offset
            self.raw_material['translation'][2] = -lowest_z + self.gui.cnc_properties_handler.build_offsets[2]
            if hasattr(self.gui, 'raw_z_slider'):
                unit = self.gui.current_unit
                scaling_factor = 10000 if unit in ['IN', 'CM'] else 1000 if unit == 'MM' else 10
                z_val = self.helpers.convert_from_cm(self.raw_material['translation'][2], unit)
                self.gui.raw_z_slider.blockSignals(True)
                self.gui.raw_z_slider.setValue(int(round(z_val * scaling_factor)))
                self.gui.raw_z_slider.blockSignals(False)
                self.gui.raw_z_entry.setText(f"{z_val:.4f}" if unit == 'IN' else f"{z_val:.2f}")
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def find_lowest_point(self):
        if not self.raw_material:
            return 0.0

        wireframe_type = self.raw_material.get('wireframe_type', 'rectangular')
        q = self.raw_material.get('quaternion', [1.0, 0.0, 0.0, 0.0])
        w, x, y, z = q
        q_conj = [w, -x, -y, -z]

        if wireframe_type == 'stl':
            vertices = self.raw_material['model'].vectors.reshape(-1, 3)
            transformed_vertices = []
            for vertex in vertices:
                v = [0, vertex[0], vertex[1], vertex[2]]
                temp = self.helpers.quaternion_multiply(q, v)
                rotated_v = self.helpers.quaternion_multiply(temp, q_conj)
                transformed_vertices.append([rotated_v[1], rotated_v[2], rotated_v[3]])
            return np.min([v[2] for v in transformed_vertices])
        elif wireframe_type == 'rectangular':
            length, width, height = self.raw_material['dimensions']
            centroid = [length / 2.0, width / 2.0, height / 2.0]
            corners = [
                (-centroid[0], -centroid[1], -centroid[2]),
                (centroid[0], -centroid[1], -centroid[2]),
                (centroid[0], centroid[1], -centroid[2]),
                (-centroid[0], centroid[1], -centroid[2]),
                (-centroid[0], -centroid[1], centroid[2]),
                (centroid[0], -centroid[1], centroid[2]),
                (centroid[0], centroid[1], centroid[2]),
                (-centroid[0], centroid[1], centroid[2])
            ]
            transformed_corners = []
            for corner in corners:
                v = [0, corner[0], corner[1], corner[2]]
                temp = self.helpers.quaternion_multiply(q, v)
                rotated_v = self.helpers.quaternion_multiply(temp, q_conj)
                transformed_corners.append([rotated_v[1], rotated_v[2], rotated_v[3]])
            return np.min([c[2] for c in transformed_corners])
        elif wireframe_type == 'cylinder':
            diameter, height, _ = self.raw_material['dimensions']
            radius = diameter / 2.0
            points = [
                (radius, 0, 0), (-radius, 0, 0), (0, radius, 0), (0, -radius, 0),
                (radius, 0, height), (-radius, 0, height), (0, radius, height), (0, -radius, height)
            ]
            transformed_points = []
            for point in points:
                v = [0, point[0], point[1], point[2]]
                temp = self.helpers.quaternion_multiply(q, v)
                rotated_v = self.helpers.quaternion_multiply(temp, q_conj)
                transformed_points.append([rotated_v[1], rotated_v[2], rotated_v[3]])
            return np.min([p[2] for p in transformed_points])
        return 0.0

    def update_raw_material_sliders(self):
        if self.raw_material:
            x_val = self.helpers.convert_from_cm(self.raw_material['translation'][0], self.gui.current_unit)
            y_val = self.helpers.convert_from_cm(self.raw_material['translation'][1], self.gui.current_unit)
            z_val = self.helpers.convert_from_cm(self.raw_material['translation'][2], self.gui.current_unit)
            if hasattr(self.gui, 'raw_x_slider'):
                self.gui.raw_x_slider.blockSignals(True)
            if hasattr(self.gui, 'raw_y_slider'):
                self.gui.raw_y_slider.blockSignals(True)
            if hasattr(self.gui, 'raw_z_slider'):
                self.gui.raw_z_slider.blockSignals(True)
            if hasattr(self.gui, 'raw_x_slider'):
                clamped_x = max(self.gui.raw_x_slider.minimum(), min(self.gui.raw_x_slider.maximum(), x_val))
                self.gui.raw_x_slider.setValue(int(round(clamped_x)))
            if hasattr(self.gui, 'raw_y_slider'):
                clamped_y = max(self.gui.raw_y_slider.minimum(), min(self.gui.raw_y_slider.maximum(), y_val))
                self.gui.raw_y_slider.setValue(int(round(clamped_y)))
            if hasattr(self.gui, 'raw_z_slider'):
                clamped_z = max(self.gui.raw_z_slider.minimum(), min(self.gui.raw_z_slider.maximum(), z_val))
                self.gui.raw_z_slider.setValue(int(round(clamped_z)))
            if hasattr(self.gui, 'raw_x_slider'):
                self.gui.raw_x_slider.blockSignals(False)
            if hasattr(self.gui, 'raw_y_slider'):
                self.gui.raw_y_slider.blockSignals(False)
            if hasattr(self.gui, 'raw_z_slider'):
                self.gui.raw_z_slider.blockSignals(False)
            if hasattr(self.gui, 'raw_x_entry'):
                self.gui.raw_x_entry.setText(f"{x_val:.6f}" if self.gui.current_unit == 'IN' else f"{x_val:.6f}")
            if hasattr(self.gui, 'raw_y_entry'):
                self.gui.raw_y_entry.setText(f"{y_val:.6f}" if self.gui.current_unit == 'IN' else f"{y_val:.6f}")
            if hasattr(self.gui, 'raw_z_entry'):
                self.gui.raw_z_entry.setText(f"{z_val:.6f}" if self.gui.current_unit == 'IN' else f"{z_val:.6f}")
            if self.gui.rotation_unit == 'DEG':
                if 'quaternion' in self.raw_material:
                    self.raw_material['rotation'] = self.helpers.euler_from_quaternion(self.raw_material['quaternion'])
                rx_deg = self.raw_material['rotation'][0]
                ry_deg = self.raw_material['rotation'][1]
                rz_deg = self.raw_material['rotation'][2]
                if hasattr(self.gui, 'raw_rx_slider'):
                    self.gui.raw_rx_slider.blockSignals(True)
                    clamped_rx = max(self.gui.raw_rx_slider.minimum(), min(self.gui.raw_rx_slider.maximum(), rx_deg*1000))
                    self.gui.raw_rx_slider.setValue(int(round(clamped_rx)))
                    self.gui.raw_rx_slider.blockSignals(False)
                if hasattr(self.gui, 'raw_ry_slider'):
                    self.gui.raw_ry_slider.blockSignals(True)
                    clamped_ry = max(self.gui.raw_ry_slider.minimum(), min(self.gui.raw_ry_slider.maximum(), ry_deg*1000))
                    self.gui.raw_ry_slider.setValue(int(round(clamped_ry)))
                    self.gui.raw_ry_slider.blockSignals(False)
                if hasattr(self.gui, 'raw_rz_slider'):
                    self.gui.raw_rz_slider.blockSignals(True)
                    clamped_rz = max(self.gui.raw_rz_slider.minimum(), min(self.gui.raw_rz_slider.maximum(), rz_deg*1000))
                    self.gui.raw_rz_slider.setValue(int(round(clamped_rz)))
                    self.gui.raw_rz_slider.blockSignals(False)
                if hasattr(self.gui, 'raw_rx_entry'):
                    self.gui.raw_rx_entry.setText(f"{rx_deg:.6f}")
                if hasattr(self.gui, 'raw_ry_entry'):
                    self.gui.raw_ry_entry.setText(f"{ry_deg:.6f}")
                if hasattr(self.gui, 'raw_rz_entry'):
                    self.gui.raw_rz_entry.setText(f"{rz_deg:.6f}")
            else:
                if 'quaternion' in self.raw_material:
                    self.raw_material['rotation'] = self.helpers.euler_from_quaternion(self.raw_material['quaternion'])
                rx_rad = np.radians(self.raw_material['rotation'][0])
                ry_rad = np.radians(self.raw_material['rotation'][1])
                rz_rad = np.radians(self.raw_material['rotation'][2])
                if hasattr(self.gui, 'raw_rx_slider'):
                    self.gui.raw_rx_slider.blockSignals(True)
                    self.gui.raw_rx_slider.setValue(int(round(rx_rad * 1000000)))
                    self.gui.raw_rx_slider.blockSignals(False)
                if hasattr(self.gui, 'raw_ry_slider'):
                    self.gui.raw_ry_slider.blockSignals(True)
                    self.gui.raw_ry_slider.setValue(int(round(ry_rad * 1000000)))
                    self.gui.raw_ry_slider.blockSignals(False)
                if hasattr(self.gui, 'raw_rz_slider'):
                    self.gui.raw_rz_slider.blockSignals(True)
                    self.gui.raw_rz_slider.setValue(int(round(rz_rad * 1000000)))
                    self.gui.raw_rz_slider.blockSignals(False)
                if hasattr(self.gui, 'raw_rx_entry'):
                    self.gui.raw_rx_entry.setText(f"{rx_rad:.6f}")
                if hasattr(self.gui, 'raw_ry_entry'):
                    self.gui.raw_ry_entry.setText(f"{ry_rad:.6f}")
                if hasattr(self.gui, 'raw_rz_entry'):
                    self.gui.raw_rz_entry.setText(f"{rz_rad:.6f}")

    def update_initial_ui_values(self):
        # Set initial values for sliders and text entries after GUI is initialized
        if hasattr(self.gui, 'raw_x_slider'):
            self.gui.raw_x_slider.setValue(0)
        if hasattr(self.gui, 'raw_y_slider'):
            self.gui.raw_y_slider.setValue(0)
        if hasattr(self.gui, 'raw_z_slider'):
            self.gui.raw_z_slider.setValue(0)
        if hasattr(self.gui, 'raw_rx_slider'):
            self.gui.raw_rx_slider.setValue(0)
        if hasattr(self.gui, 'raw_ry_slider'):
            self.gui.raw_ry_slider.setValue(0)
        if hasattr(self.gui, 'raw_rz_slider'):
            self.gui.raw_rz_slider.setValue(0)
        if hasattr(self.gui, 'raw_x_entry'):
            self.gui.raw_x_entry.setText("0.0")
        if hasattr(self.gui, 'raw_y_entry'):
            self.gui.raw_y_entry.setText("0.0")
        if hasattr(self.gui, 'raw_z_entry'):
            self.gui.raw_z_entry.setText("0.0")
        if hasattr(self.gui, 'raw_rx_entry'):
            self.gui.raw_rx_entry.setText("0.0")
        if hasattr(self.gui, 'raw_ry_entry'):
            self.gui.raw_ry_entry.setText("0.0")
        if hasattr(self.gui, 'raw_rz_entry'):
            self.gui.raw_rz_entry.setText("0.0")
        if hasattr(self.gui, 'material_length'):
            self.gui.material_length.setValue(10.0)
        if hasattr(self.gui, 'material_width'):
            self.gui.material_width.setValue(20.0)
        if hasattr(self.gui, 'material_height'):
            self.gui.material_height.setValue(10.0)

    def create_deferred_wireframe(self):
        if not self.raw_material or 'wireframe_pending' not in self.raw_material or not self.raw_material['wireframe_pending']:
            return
        
        if self.raw_material['wireframe_list']:
            glDeleteLists(self.raw_material['wireframe_list'], 1)
            self.raw_material['wireframe_list'] = None
        
        wireframe_type = self.raw_material.get('wireframe_type', 'rectangular')
        if wireframe_type == 'rectangular':
            length, width, height = self.raw_material['dimensions']
            centroid = [length / 2.0, width / 2.0, height / 2.0]
            self.raw_material['centroid'] = centroid
            
            self.raw_material['wireframe_list'] = glGenLists(1)
            glNewList(self.raw_material['wireframe_list'], GL_COMPILE)
            glColor3f(0.7, 0.0, 0.7)
            glLineWidth(1.0)
            glBegin(GL_LINES)
            corners = [
                (-centroid[0], -centroid[1], -centroid[2]),
                (centroid[0], -centroid[1], -centroid[2]),
                (centroid[0], centroid[1], -centroid[2]),
                (-centroid[0], centroid[1], -centroid[2]),
                (-centroid[0], -centroid[1], centroid[2]),
                (centroid[0], -centroid[1], centroid[2]),
                (centroid[0], centroid[1], centroid[2]),
                (-centroid[0], centroid[1], centroid[2])
            ]
            edges = [
                (0, 1), (1, 2), (2, 3), (3, 0),
                (4, 5), (5, 6), (6, 7), (7, 4),
                (0, 4), (1, 5), (2, 6), (3, 7)
            ]
            for edge in edges:
                glVertex3fv(corners[edge[0]])
                glVertex3fv(corners[edge[1]])
            glEnd()
            glEndList()
        elif wireframe_type == 'cylinder':
            diameter, height, _ = self.raw_material['dimensions']
            radius = diameter / 2.0
            segments = 36
            self.raw_material['centroid'] = [0.0, 0.0, height / 2.0]

            self.raw_material['wireframe_list'] = glGenLists(1)
            glNewList(self.raw_material['wireframe_list'], GL_COMPILE)
            glColor3f(0.7, 0.0, 0.7)
            glLineWidth(1.0)
            glBegin(GL_LINES)
            for i in range(segments):
                angle1 = 2 * np.pi * i / segments
                angle2 = 2 * np.pi * (i + 1) / segments
                x1, y1 = radius * np.cos(angle1), radius * np.sin(angle1)
                x2, y2 = radius * np.cos(angle2), radius * np.sin(angle2)
                glVertex3f(x1, y1, 0)
                glVertex3f(x2, y2, 0)
                glVertex3f(x1, y1, height)
                glVertex3f(x2, y2, height)
                glVertex3f(x1, y1, 0)
                glVertex3f(x1, y1, height)
            glEnd()
            glEndList()
        elif wireframe_type == 'stl':
            boundary_edges = self.raw_material.get('boundary_edges', [])
            wireframe_list = glGenLists(1)
            glNewList(wireframe_list, GL_COMPILE)
            glColor3f(0.7, 0.0, 0.7)
            glLineWidth(1.0)
            glBegin(GL_LINES)
            for edge in boundary_edges:
                glVertex3fv(edge[0])
                glVertex3fv(edge[1])
            glEnd()
            glEndList()
            self.raw_material['wireframe_list'] = wireframe_list
        
        self.raw_material['wireframe_pending'] = False

    def update_raw_material_rotation(self, axis, value):
        """Update rotation around a specific local axis using incremental rotation."""
        if self.raw_material:
            # Get the current Euler angle for the specified axis without wrapping
            if axis == 'x':
                current_value = self.raw_material['rotation'][0]
                self.raw_material['rotation'][0] = value
            elif axis == 'y':
                current_value = self.raw_material['rotation'][1]
                self.raw_material['rotation'][1] = value
            elif axis == 'z':
                current_value = self.raw_material['rotation'][2]
                self.raw_material['rotation'][2] = value
            else:
                return
            
            # Calculate the delta rotation (difference between new and old value)
            delta_value = value - current_value
            
            # Create a quaternion for the delta rotation around the specified local axis
            if axis == 'x':
                delta_quat = self.helpers.quaternion_from_euler(delta_value, 0, 0)
            elif axis == 'y':
                delta_quat = self.helpers.quaternion_from_euler(0, delta_value, 0)
            elif axis == 'z':
                delta_quat = self.helpers.quaternion_from_euler(0, 0, delta_value)
            
            # Get the current quaternion
            current_quat = self.raw_material['quaternion']
            
            # Apply the delta rotation to the current quaternion (local axis rotation)
            self.raw_material['quaternion'] = self.helpers.quaternion_multiply(current_quat, delta_quat)
            
            # Do not update Euler angles here to avoid feedback loops
            # UI updates are handled separately in update_raw_material_sliders if needed
            
            if hasattr(self.gui, 'stl_viewer') and self.gui.stl_viewer:
                self.gui.stl_viewer.update()

    def add_sliders(self, layout):
        slider_layout = QHBoxLayout()
        layout.addLayout(slider_layout)
        
        translation_layout = QVBoxLayout()
        slider_layout.addLayout(translation_layout)
        translation_label = QLabel('Translation')
        translation_label.setAlignment(Qt.AlignCenter)
        translation_layout.addWidget(translation_label)
        translation_sliders_layout = QHBoxLayout()
        translation_layout.addLayout(translation_sliders_layout)
        
        x_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(x_translation_layout)
        self.gui.raw_x_slider = QSlider(Qt.Vertical)
        self.gui.raw_x_slider.setRange(-300000, 300000)
        self.gui.raw_x_slider.valueChanged.connect(self.update_raw_x_translation)
        x_translation_layout.addWidget(QLabel('X'))
        x_translation_layout.addWidget(self.gui.raw_x_slider)
        self.gui.raw_x_entry = QLineEdit()
        self.gui.raw_x_entry.setFixedWidth(100)
        self.gui.raw_x_entry.setPlaceholderText('0.0')
        self.gui.raw_x_entry.setAlignment(Qt.AlignCenter)
        self.gui.raw_x_entry.returnPressed.connect(self.update_raw_x_translation_from_entry)
        x_translation_layout.addWidget(self.gui.raw_x_entry)
        
        y_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(y_translation_layout)
        self.gui.raw_y_slider = QSlider(Qt.Vertical)
        self.gui.raw_y_slider.setRange(-300000, 300000)
        self.gui.raw_y_slider.valueChanged.connect(self.update_raw_y_translation)
        y_translation_layout.addWidget(QLabel('Y'))
        y_translation_layout.addWidget(self.gui.raw_y_slider)
        self.gui.raw_y_entry = QLineEdit()
        self.gui.raw_y_entry.setFixedWidth(100)
        self.gui.raw_y_entry.setPlaceholderText('0.0')
        self.gui.raw_y_entry.setAlignment(Qt.AlignCenter)
        self.gui.raw_y_entry.returnPressed.connect(self.update_raw_y_translation_from_entry)
        y_translation_layout.addWidget(self.gui.raw_y_entry)
        
        z_translation_layout = QVBoxLayout()
        translation_sliders_layout.addLayout(z_translation_layout)
        self.gui.raw_z_slider = QSlider(Qt.Vertical)
        self.gui.raw_z_slider.setRange(-300000, 300000)
        self.gui.raw_z_slider.valueChanged.connect(self.update_raw_z_translation)
        z_translation_layout.addWidget(QLabel('Z'))
        z_translation_layout.addWidget(self.gui.raw_z_slider)
        self.gui.raw_z_entry = QLineEdit()
        self.gui.raw_z_entry.setFixedWidth(100)
        self.gui.raw_z_entry.setPlaceholderText('0.0')
        self.gui.raw_z_entry.setAlignment(Qt.AlignCenter)
        self.gui.raw_z_entry.returnPressed.connect(self.update_raw_z_translation_from_entry)
        z_translation_layout.addWidget(self.gui.raw_z_entry)
        
        rotation_layout = QVBoxLayout()
        slider_layout.addLayout(rotation_layout)
        rotation_label = QLabel('Rotation')
        rotation_label.setAlignment(Qt.AlignCenter)
        rotation_layout.addWidget(rotation_label)
        
        self.rotation_type_combo = QComboBox()
        self.rotation_type_combo.addItems(['Euler', 'Quaternion'])
        self.rotation_type_combo.currentTextChanged.connect(self.change_raw_material_rotation_type)
        rotation_layout.addWidget(self.rotation_type_combo)
        
        rotation_sliders_layout = QHBoxLayout()
        rotation_layout.addLayout(rotation_sliders_layout)
        
        x_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(x_rotation_layout)
        self.gui.raw_rx_slider = QSlider(Qt.Vertical)
        self.gui.raw_rx_slider.setRange(-180000, 180000)
        self.gui.raw_rx_slider.valueChanged.connect(self.update_raw_rx_rotation)
        x_rotation_layout.addWidget(QLabel('X'))
        x_rotation_layout.addWidget(self.gui.raw_rx_slider)
        self.gui.raw_rx_entry = QLineEdit()
        self.gui.raw_rx_entry.setFixedWidth(100)  # Widened to match translation entries
        self.gui.raw_rx_entry.setPlaceholderText('0.0')
        self.gui.raw_rx_entry.setAlignment(Qt.AlignCenter)
        self.gui.raw_rx_entry.returnPressed.connect(self.update_raw_rx_rotation_from_entry)
        x_rotation_layout.addWidget(self.gui.raw_rx_entry)
        
        y_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(y_rotation_layout)
        self.gui.raw_ry_slider = QSlider(Qt.Vertical)
        self.gui.raw_ry_slider.setRange(-180000, 180000)
        self.gui.raw_ry_slider.valueChanged.connect(self.update_raw_ry_rotation)
        y_rotation_layout.addWidget(QLabel('Y'))
        y_rotation_layout.addWidget(self.gui.raw_ry_slider)
        self.gui.raw_ry_entry = QLineEdit()
        self.gui.raw_ry_entry.setFixedWidth(100)  # Widened to match translation entries
        self.gui.raw_ry_entry.setPlaceholderText('0.0')
        self.gui.raw_ry_entry.setAlignment(Qt.AlignCenter)
        self.gui.raw_ry_entry.returnPressed.connect(self.update_raw_ry_rotation_from_entry)
        y_rotation_layout.addWidget(self.gui.raw_ry_entry)
        
        z_rotation_layout = QVBoxLayout()
        rotation_sliders_layout.addLayout(z_rotation_layout)
        self.gui.raw_rz_slider = QSlider(Qt.Vertical)
        self.gui.raw_rz_slider.setRange(-180000, 180000)
        self.gui.raw_rz_slider.valueChanged.connect(self.update_raw_rz_rotation)
        z_rotation_layout.addWidget(QLabel('Z'))
        z_rotation_layout.addWidget(self.gui.raw_rz_slider)
        self.gui.raw_rz_entry = QLineEdit()
        self.gui.raw_rz_entry.setFixedWidth(100)  # Widened to match translation entries
        self.gui.raw_rz_entry.setPlaceholderText('0.0')
        self.gui.raw_rz_entry.setAlignment(Qt.AlignCenter)
        self.gui.raw_rz_entry.returnPressed.connect(self.update_raw_rz_rotation_from_entry)
        z_rotation_layout.addWidget(self.gui.raw_rz_entry)

    def update_raw_x_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed(): value = np.round(value/scaling_factor)*scaling_factor
        if self.raw_material:
            if not self.gui.raw_x_slider.signalsBlocked():
                self.raw_material['translation'][0] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                x_val = value
                self.gui.raw_x_entry.setText(f"{x_val/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{x_val/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{x_val/scaling_factor:.1f}")
                self.gui.stl_viewer.update()

    def update_raw_y_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed(): value = np.round(value/scaling_factor)*scaling_factor
        if self.raw_material:
            if not self.gui.raw_y_slider.signalsBlocked():
                self.raw_material['translation'][1] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                y_val = value
                self.gui.raw_y_entry.setText(f"{y_val/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{y_val/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{y_val/scaling_factor:.1f}")
                self.gui.stl_viewer.update()

    def update_raw_z_translation(self, value):
        scaling_factor = 10000.0 if self.gui.current_unit in ['IN', 'CM'] else 1000.0 if self.gui.current_unit == 'MM' else 10.0
        if self.gui.is_mouse_pressed(): value = np.round(value/scaling_factor)*scaling_factor
        if self.raw_material:
            if not self.gui.raw_z_slider.signalsBlocked():
                self.raw_material['translation'][2] = self.helpers.convert_to_cm(value/scaling_factor, self.gui.current_unit)
                z_val = value
                self.gui.raw_z_entry.setText(f"{z_val/scaling_factor:.4f}" if self.gui.current_unit == 'IN' or self.gui.current_unit == 'CM' else f"{z_val/scaling_factor:.3f}" if self.gui.current_unit == 'MM' else f"{z_val/scaling_factor:.1f}")
                self.gui.stl_viewer.update()

    def update_raw_x_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.gui.raw_x_entry.text())
            self.raw_material['translation'][0] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.raw_x_slider.blockSignals(True)
            self.gui.raw_x_slider.setValue(int(round(max(self.gui.raw_x_slider.minimum(), min(self.gui.raw_x_slider.maximum(), value*scaling_factor)))))
            self.gui.raw_x_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for raw material X translation")

    def update_raw_y_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.gui.raw_y_entry.text())
            self.raw_material['translation'][1] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.raw_y_slider.blockSignals(True)
            self.gui.raw_y_slider.setValue(int(round(max(self.gui.raw_y_slider.minimum(), min(self.gui.raw_y_slider.maximum(), value*scaling_factor)))))
            self.gui.raw_y_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for raw material Y translation")

    def update_raw_z_translation_from_entry(self):
        scaling_factor = 10000 if self.gui.current_unit in ['IN', 'CM'] else 1000 if self.gui.current_unit == 'MM' else 10
        try:
            value = float(self.gui.raw_z_entry.text())
            self.raw_material['translation'][2] = self.helpers.convert_to_cm(value, self.gui.current_unit)
            self.gui.raw_z_slider.blockSignals(True)
            self.gui.raw_z_slider.setValue(int(round(max(self.gui.raw_z_slider.minimum(), min(self.gui.raw_z_slider.maximum(), value*scaling_factor)))))
            self.gui.raw_z_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for raw material Z translation")

    def update_raw_rx_rotation(self, value):
        if self.gui.is_mouse_pressed():  value = np.round(value/1000.0)*1000.0
        if self.raw_material:
            if self.gui.rotation_unit == 'DEG':
                self.update_raw_material_rotation('x', value/1000.0)
                self.gui.raw_rx_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_raw_material_rotation('x', np.degrees(value / 1000000.0))
                self.gui.raw_rx_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_raw_ry_rotation(self, value):
        if self.gui.is_mouse_pressed(): value = np.round(value/1000.0)*1000.0
        
        if self.raw_material:
            if self.gui.rotation_unit == 'DEG':
                self.update_raw_material_rotation('y', value/1000.0)
                self.gui.raw_ry_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_raw_material_rotation('y', np.degrees(value / 1000000.0))
                self.gui.raw_ry_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_raw_rz_rotation(self, value):
        if self.gui.is_mouse_pressed(): value = np.round(value/1000.0)*1000.0
        
        if self.raw_material:
            if self.gui.rotation_unit == 'DEG':
                self.update_raw_material_rotation('z', value/1000.0)
                self.gui.raw_rz_entry.setText(f"{value/1000.0:.3f}")
            else:
                self.update_raw_material_rotation('z', np.degrees(value / 1000000.0))
                self.gui.raw_rz_entry.setText(f"{value / 1000000.0:.6f}")
            self.gui.stl_viewer.update()

    def update_raw_rx_rotation_from_entry(self):
        try:
            value = float(self.gui.raw_rx_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_raw_material_rotation('x', value)
                self.gui.raw_rx_slider.blockSignals(True)
                clamped_value = max(self.gui.raw_rx_slider.minimum(), min(self.gui.raw_rx_slider.maximum(), value*1000))
                self.gui.raw_rx_slider.setValue(int(round(clamped_value)))
                self.gui.raw_rx_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_raw_material_rotation('x', deg_value)
                self.gui.raw_rx_slider.blockSignals(True)
                clamped_value = max(self.gui.raw_rx_slider.minimum(), min(self.gui.raw_rx_slider.maximum(), value*1000000))
                self.gui.raw_rx_slider.setValue(int(round(clamped_value)))
                self.gui.raw_rx_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for raw material X rotation")

    def update_raw_ry_rotation_from_entry(self):
        try:
            value = float(self.gui.raw_ry_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_raw_material_rotation('y', value)
                self.gui.raw_ry_slider.blockSignals(True)
                clamped_value = max(self.gui.raw_ry_slider.minimum(), min(self.gui.raw_ry_slider.maximum(), value*1000))
                self.gui.raw_ry_slider.setValue(int(round(clamped_value)))
                self.gui.raw_ry_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_raw_material_rotation('y', deg_value)
                self.gui.raw_ry_slider.blockSignals(True)
                clamped_value = max(self.gui.raw_ry_slider.minimum(), min(self.gui.raw_ry_slider.maximum(), value*1000000))
                self.gui.raw_ry_slider.setValue(int(round(clamped_value)))
                self.gui.raw_ry_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for raw material Y rotation")

    def update_raw_rz_rotation_from_entry(self):
        try:
            value = float(self.gui.raw_rz_entry.text())
            if self.gui.rotation_unit == 'DEG':
                self.update_raw_material_rotation('z', value)
                self.gui.raw_rz_slider.blockSignals(True)
                clamped_value = max(self.gui.raw_rz_slider.minimum(), min(self.gui.raw_rz_slider.maximum(), value*1000))
                self.gui.raw_rz_slider.setValue(int(round(clamped_value)))
                self.gui.raw_rz_slider.blockSignals(False)
            else:
                deg_value = np.degrees(value)
                deg_value = ((deg_value + 180) % 360) - 180
                self.update_raw_material_rotation('z', deg_value)
                self.gui.raw_rz_slider.blockSignals(True)
                clamped_value = max(self.gui.raw_rz_slider.minimum(), min(self.gui.raw_rz_slider.maximum(), value*1000000))
                self.gui.raw_rz_slider.setValue(int(round(clamped_value)))
                self.gui.raw_rz_slider.blockSignals(False)
            self.gui.stl_viewer.update()
        except ValueError:
            print("Invalid input for raw material Z rotation")

    def change_raw_material_rotation_type(self, mode):
        if self.raw_material:
            if mode == 'Euler':
                # Convert current quaternion to Euler and update sliders
                self.raw_material['rotation'] = self.helpers.euler_from_quaternion(self.raw_material['quaternion'])
                self.update_raw_material_sliders()  # Updates sliders to reflect current orientation
            elif mode == 'Quaternion':
                # Convert current Euler angles to quaternion to maintain orientation
                self.raw_material['quaternion'] = self.helpers.quaternion_from_euler(self.raw_material['rotation'][0], self.raw_material['rotation'][1], self.raw_material['rotation'][2])
            self.gui.stl_viewer.update()

    def get_transformed_raw_material_mesh(self):
        raw_mesh = None
        if self.raw_material['wireframe_type'] == 'stl':
            raw_model = self.raw_material['model']
            raw_vertices = raw_model.vectors.reshape(-1, 3)
            raw_faces = np.arange(len(raw_model.vectors) * 3).reshape(len(raw_model.vectors), 3)
            raw_mesh = trimesh.Trimesh(vertices=raw_vertices, faces=raw_faces, process=True)
            if not raw_mesh.is_watertight:
                raw_mesh.fill_holes()
            centroid = self.raw_material['centroid']
            full_transform = np.eye(4)
            centroid_matrix = np.eye(4)
            centroid_matrix[:3, 3] = -centroid
            full_transform = np.dot(full_transform, centroid_matrix)
            translation_matrix = np.eye(4)
            translation_matrix[:3, 3] = self.raw_material['translation']
            full_transform = np.dot(full_transform, translation_matrix)
            rotation_type = self.rotation_type_combo.currentText()
            if rotation_type == 'Euler':
                angles = self.raw_material['rotation']
                rotation_matrix = R.from_euler('zyx', angles, degrees=True).as_matrix()
            else:
                q = self.raw_material['quaternion']
                rotation = R.from_quat(q, scalar_first=True)
                rotation_matrix = rotation.as_matrix()
            rotation_matrix_4x4 = np.eye(4)
            rotation_matrix_4x4[:3, :3] = rotation_matrix
            full_transform = np.dot(full_transform, rotation_matrix_4x4)
            inv_centroid_matrix = np.eye(4)
            inv_centroid_matrix[:3, 3] = centroid
            full_transform = np.dot(full_transform, inv_centroid_matrix)
            if 'scale' in self.raw_material:
                scale_matrix = np.eye(4)
                scale_matrix[0, 0] = self.raw_material['scale']
                scale_matrix[1, 1] = self.raw_material['scale']
                scale_matrix[2, 2] = self.raw_material['scale']
                full_transform = np.dot(full_transform, scale_matrix)
            raw_mesh.apply_transform(full_transform)
        elif self.raw_material.get('wireframe_type') == 'cylinder':
            diameter, height, _ = self.raw_material['dimensions']
            radius = diameter / 2.0
            raw_mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=360000)
            full_transform = np.eye(4)
            translation_matrix = np.eye(4)
            translation_matrix[:3, 3] = self.raw_material['translation']
            full_transform = np.dot(full_transform, translation_matrix)
            rotation_type = self.rotation_type_combo.currentText()
            if rotation_type == 'Euler':
                angles = self.raw_material['rotation']
                if self.gui.rotation_unit == 'RAD':
                    angles = np.degrees(angles)
                rotation_matrix = R.from_euler('xyz', angles, degrees=True).as_matrix()
            else:
                q = self.raw_material['quaternion']
                rotation_matrix = R.from_quat(q, scalar_first=True).as_matrix()
                
            rotation_matrix_4x4 = np.eye(4)
            rotation_matrix_4x4[:3, :3] = rotation_matrix
            full_transform = np.dot(full_transform, rotation_matrix_4x4)
            raw_mesh.apply_transform(full_transform)
        else:
            dimensions = self.raw_material['dimensions']
            raw_mesh = trimesh.creation.box(extents=dimensions)
            #print("Raw mesh dimensions:", dimensions)
            #print("Checking that the mesh is valid")
            #if self.gui.planning_handler.mesh_is_valid(raw_mesh):
            #    print("Mesh is valid")
            #else:
            #    print("Mesh is not valid")
            #    return None, None
            full_transform = np.eye(4)
            translation_matrix = np.eye(4)
            translation_matrix[:3, 3] = self.raw_material['translation']
            full_transform = np.dot(full_transform, translation_matrix)
            rotation_type = self.rotation_type_combo.currentText()
            if rotation_type == 'Euler':
                angles = self.raw_material['rotation']
                if self.gui.rotation_unit == 'RAD':
                    angles = np.degrees(angles)
                rotation_matrix = R.from_euler('xyz', angles, degrees=True).as_matrix()
            else:
                q = self.raw_material['quaternion']
                rotation_matrix = R.from_quat(q, scalar_first=True).as_matrix()
                
            rotation_matrix_4x4 = np.eye(4)
            rotation_matrix_4x4[:3, :3] = rotation_matrix
            full_transform = np.dot(full_transform, rotation_matrix_4x4)
            raw_mesh.apply_transform(full_transform)
        
        return raw_mesh, full_transform